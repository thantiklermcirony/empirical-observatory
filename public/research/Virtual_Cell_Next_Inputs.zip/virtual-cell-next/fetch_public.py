"""Bounded public download with normal TLS and no authentication."""
import argparse
import hashlib
import json
import urllib.request
from datetime import datetime, timezone
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("url")
    parser.add_argument("name")
    parser.add_argument("--cap", type=int, default=5_000_000)
    args = parser.parse_args()
    if not 0 < args.cap <= 250_000_000 or Path(args.name).name != args.name:
        parser.error("A filename and a cap of at most 250 MB are required")
    folder = Path(__file__).resolve().parent
    path = folder / args.name
    result = {"url": args.url, "time_utc": datetime.now(timezone.utc).isoformat(), "cap_bytes": args.cap}
    try:
        if path.exists():
            raise ValueError("Destination exists; preserving it")
        req = urllib.request.Request(args.url, headers={"User-Agent": "PublicScienceDataAudit/0.2"})
        with urllib.request.urlopen(req, timeout=30) as response:
            result.update(status=response.status, final_url=response.url, headers=dict(response.headers))
            declared = response.headers.get("Content-Length")
            if declared and int(declared) > args.cap:
                raise ValueError("Declared size exceeds cap")
            data = response.read(args.cap + 1)
            if len(data) > args.cap:
                raise ValueError("Actual response exceeds cap")
        path.write_bytes(data)
        result.update(success=True, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    except Exception as exc:
        result.update(success=False, error=repr(exc))
    path.with_name(path.name + ".fetch.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0 if result["success"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
