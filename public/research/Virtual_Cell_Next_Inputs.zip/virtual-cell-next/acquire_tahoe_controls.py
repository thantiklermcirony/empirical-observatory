"""Acquire only the pinned public Tahoe DMSO control table, at most 250 MB.

Requires the small publisher tree, README and README fetch manifest obtained by
fetch_public.py. Does not obtain perturbation responses, embeddings or models.
"""
import hashlib
import json
import urllib.request
from datetime import datetime, timezone
from pathlib import Path


def main():
    folder = Path(__file__).resolve().parent
    tree = json.loads((folder / "tahoe-drug-tree.json").read_text(encoding="utf-8"))
    card = (folder / "tahoe-drug-README.md").read_text(encoding="utf-8")
    card_fetch = json.loads((folder / "tahoe-drug-README.md.fetch.json").read_text(encoding="utf-8"))
    assert "license: cc0-1.0" in card, "Publisher data license is not the expected CC0-1.0"
    headers = {k.lower(): v for k, v in card_fetch["headers"].items()}
    revision = headers.get("x-repo-commit")
    assert revision and len(revision) == 40 and all(c in "0123456789abcdef" for c in revision), "Missing pinned repository revision"
    target_name = "zeroshot/control_expression.parquet"
    matches = [x for x in tree if x.get("path") == target_name]
    assert len(matches) == 1, "Expected one publisher file entry"
    item = matches[0]
    expected_size = item["size"]
    expected_sha256 = item["lfs"]["oid"]
    assert 0 < expected_size <= 250_000_000
    assert len(expected_sha256) == 64
    url = f"https://huggingface.co/datasets/tahoebio/tahoe-de-rhaister/resolve/{revision}/{target_name}"
    path = folder / "tahoe-control_expression.parquet"
    partial = path.with_suffix(".parquet.part")
    report = {"created_at_utc": datetime.now(timezone.utc).isoformat(), "url": url,
              "publisher_revision": revision, "publisher_path": target_name,
              "publisher_license": "CC0-1.0", "expected_bytes": expected_size,
              "expected_sha256": expected_sha256, "max_bytes": 250_000_000}
    try:
        if path.exists():
            h = hashlib.file_digest(path.open("rb"), "sha256").hexdigest()
            assert path.stat().st_size == expected_size and h == expected_sha256
            report.update(success=True, reused=True, bytes=path.stat().st_size, sha256=h)
        else:
            assert not partial.exists(), "Preserving existing partial file"
            request = urllib.request.Request(url, headers={"User-Agent": "PublicScienceDataAudit/0.2"})
            with urllib.request.urlopen(request, timeout=30) as response:
                assert response.status == 200, "Unexpected response"
                declared = response.headers.get("Content-Length")
                if declared:
                    assert int(declared) == expected_size, "Publisher size mismatch"
                total = 0
                sha = hashlib.sha256()
                with partial.open("xb") as output:
                    while True:
                        block = response.read(min(1_048_576, expected_size - total + 1))
                        if not block:
                            break
                        total += len(block)
                        assert total <= expected_size, "Response exceeded verified publisher size"
                        output.write(block)
                        sha.update(block)
                assert total == expected_size
                assert sha.hexdigest() == expected_sha256
                partial.rename(path)
                report.update(success=True, reused=False, bytes=total, sha256=sha.hexdigest())
    except Exception as exc:
        report.update(success=False, error=repr(exc))
    (folder / "tahoe-controls-download.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if report["success"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
