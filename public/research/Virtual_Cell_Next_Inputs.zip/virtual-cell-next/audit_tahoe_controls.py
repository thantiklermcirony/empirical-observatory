"""Audit the released DMSO table only. No model, PCA or response data access."""
import hashlib
import json
import platform
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pyarrow
import pyarrow.parquet as pq


def main():
    started = time.perf_counter()
    folder = Path(__file__).resolve().parent
    source = folder / "tahoe-control_expression.parquet"
    manifest = json.loads((folder / "tahoe-controls-download.json").read_text())
    with source.open("rb") as stream:
        source_sha = hashlib.file_digest(stream, "sha256").hexdigest()
    assert source_sha == manifest["expected_sha256"]
    assert source.stat().st_size == manifest["expected_bytes"]
    parquet = pq.ParquetFile(source)
    groups = []
    seen = set()
    feature_ids = None
    full_feature_sha = None
    plate1 = []
    global_nonfinite = global_negative = global_zero = 0
    complete = True
    for row_group in range(parquet.num_row_groups):
        frame = parquet.read_row_group(row_group).to_pandas()
        for (cell_line, plate), sub in frame.groupby(["cell_line", "plate"], sort=True):
            key = (str(cell_line), int(plate))
            assert key not in seen, "Context/plate crosses row groups; audit must be adapted before claiming complete checks"
            seen.add(key)
            names = sub.feature.astype(str).tolist()
            assert len(names) == len(set(names)), "Duplicate feature keys"
            order = np.argsort(np.array(names), kind="stable")
            sorted_names = [names[i] for i in order]
            gene_sha = hashlib.sha256(json.dumps(sorted_names, separators=(",", ":")).encode()).hexdigest()
            if feature_ids is None:
                feature_ids = sorted_names
                full_feature_sha = gene_sha
            complete &= gene_sha == full_feature_sha
            expression = sub.ref_mean.to_numpy(dtype=np.float64)[order]
            finite = np.isfinite(expression)
            nonfinite = int((~finite).sum())
            negative = int((expression[finite] < 0).sum())
            zero = int((expression == 0).sum())
            global_nonfinite += nonfinite
            global_negative += negative
            global_zero += zero
            metadata = {}
            for name in ("ref_lib_mean", "ref_lib_median", "ref_n_cells"):
                vals = sub[name].unique()
                assert len(vals) == 1 and np.isfinite(vals[0]), f"Nonconstant or nonfinite {name}"
                metadata[name] = float(vals[0]) if name != "ref_n_cells" else int(vals[0])
            assert metadata["ref_n_cells"] > 0
            entry = {"cell_line": key[0], "plate": key[1], "feature_count": len(names),
                     "feature_sha256": gene_sha, "nonfinite": nonfinite, "negative": negative,
                     "zero": zero, "sum_ref_mean": float(expression.sum()),
                     "min_ref_mean": float(expression.min()), "max_ref_mean": float(expression.max()), **metadata}
            entry["sum_ref_mean_over_ref_lib_mean"] = entry["sum_ref_mean"] / metadata["ref_lib_mean"]
            groups.append(entry)
            if int(plate) == 1:
                plate1.append((str(cell_line), expression.astype(np.float32), metadata))
    cells = sorted({x[0] for x in seen})
    plates = sorted({x[1] for x in seen})
    assert len(groups) * len(feature_ids) == parquet.metadata.num_rows
    assert complete, "Context-specific feature axes; audit must be adapted"
    plate1.sort(key=lambda x: x[0])
    assert len(plate1) == len(cells)
    np.savez_compressed(folder / "controls-plate1.npz", cell_lines=np.array([x[0] for x in plate1]),
                        features=np.array(feature_ids), ref_mean=np.stack([x[1] for x in plate1]),
                        ref_n_cells=np.array([x[2]["ref_n_cells"] for x in plate1]),
                        ref_lib_mean=np.array([x[2]["ref_lib_mean"] for x in plate1]))
    identity = lambda x: hashlib.sha256(("EA-VC-Tahoe-v1|" + x).encode()).hexdigest()
    ordered = sorted(cells, key=identity)
    folds = {str(i): ordered[i::5] for i in range(5)}
    freeze = {"version": 1, "frozen_at_utc": datetime.now(timezone.utc).isoformat(),
              "response_values_read": False, "assignment": "sort SHA256(EA-VC-Tahoe-v1|cellosaurus-id), round robin into five folds",
              "cell_folds": folds, "plate": 1,
              "response_shard": {"url": f"https://huggingface.co/datasets/tahoebio/tahoe-de-rhaister/resolve/{manifest['publisher_revision']}/cell_eval/plate_plate1.parquet",
                                  "bytes": 65704666, "sha256": "496a7727899fd16a590e535f6a3007f3ded6f120ad2aa10edc2f5a30ea924c16"},
              "scope": "Whole-cell-line response holdout; target plate-matched DMSO controls allowed. Chemical perturbation, separate from Nadig CRISPRi.",
              "normalization_gate": "Preserve ref_mean as released; its sum is not ref_lib_mean. No raw-count or CP10K conversion asserted. Resolve source preprocessing before combining absolute endpoints.",
              "outcome_axis_gate": "Inspect shard schema only; if preselected, call it fixed publisher panel. Do not read response values before exact model/abstention equations and tuning plan are frozen.",
              "is_external_preregistration": False}
    (folder / "FROZEN_INPUT_SELECTION.json").write_text(json.dumps(freeze, indent=2) + "\n")
    (folder / "control-context-audit.json").write_text(json.dumps(groups, indent=2) + "\n")
    report = {"created_at_utc": datetime.now(timezone.utc).isoformat(), "source": manifest,
              "file_sha256_verified": source_sha, "rows": parquet.metadata.num_rows,
              "row_groups": parquet.num_row_groups, "columns": str(parquet.schema_arrow),
              "cell_lines": cells, "plates": plates, "context_plate_count": len(groups),
              "features": len(feature_ids), "feature_sha256": full_feature_sha,
              "same_feature_axis_all_context_plates": complete,
              "duplicate_context_plate_feature_keys": 0, "nonfinite_ref_mean": global_nonfinite,
              "negative_ref_mean": global_negative, "zero_ref_mean": global_zero,
              "complete_cell_line_by_plate_grid": len(groups) == len(cells)*len(plates),
              "ref_n_cells_range": [min(x['ref_n_cells'] for x in groups), max(x['ref_n_cells'] for x in groups)],
              "sum_ref_mean_over_library_range": [min(x['sum_ref_mean_over_ref_lib_mean'] for x in groups), max(x['sum_ref_mean_over_ref_lib_mean'] for x in groups)],
              "preprocessing_identified": False, "raw_integer_count_claim": False,
              "individual_control_cells_available": False, "within_cell_covariance_identifiable": False,
              "models_fit": 0, "response_values_read": False,
              "python": platform.python_version(), "numpy": np.__version__, "pyarrow": pyarrow.__version__,
              "elapsed_seconds": time.perf_counter() - started}
    for name in ("controls-plate1.npz", "FROZEN_INPUT_SELECTION.json", "control-context-audit.json"):
        p = folder / name
        report.setdefault("outputs", []).append({"name": name, "bytes": p.stat().st_size,
                                                "sha256": hashlib.sha256(p.read_bytes()).hexdigest()})
    (folder / "CONTROL_AUDIT.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
