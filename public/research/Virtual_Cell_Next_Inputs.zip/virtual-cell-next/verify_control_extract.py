"""Independent direct-column check of the compact control extract and split."""
import hashlib
import json
from pathlib import Path

import numpy as np
import pyarrow.parquet as pq


def main():
    root = Path(__file__).resolve().parent
    data = np.load(root / "controls-plate1.npz", allow_pickle=False)
    frozen = json.loads((root / "FROZEN_INPUT_SELECTION.json").read_text())
    checks = []
    features = data["features"].tolist()
    cells = data["cell_lines"].tolist()
    listed = [cell for group in frozen["cell_folds"].values() for cell in group]
    checks.append({"check": "all 50 context IDs assigned once", "pass": len(set(listed)) == len(listed) == 50 and set(listed) == set(cells)})
    checks.append({"check": "all five folds contain ten contexts", "pass": all(len(x) == 10 for x in frozen["cell_folds"].values())})
    checks.append({"check": "all 62710 unique features retained", "pass": len(features) == len(set(features)) == 62710})
    checks.append({"check": "all extracted values finite and nonnegative", "pass": bool(np.isfinite(data["ref_mean"]).all() and (data["ref_mean"] >= 0).all())})
    for cell in (cells[0], cells[len(cells)//2], cells[-1]):
        frame = pq.read_table(root / "tahoe-control_expression.parquet",
                              columns=["cell_line", "plate", "feature", "ref_mean"],
                              filters=[("plate", "=", 1), ("cell_line", "=", cell)]).to_pandas()
        exact = frame.set_index("feature").loc[features, "ref_mean"].to_numpy()
        checks.append({"check": f"direct source comparison: {cell}, all features", "pass": bool(np.array_equal(exact, data["ref_mean"][cells.index(cell)]))})
    result = {"all_passed": all(x["pass"] for x in checks), "checks": checks,
              "response_values_read": False, "models_fit": 0,
              "frozen_selection_sha256": hashlib.sha256((root / "FROZEN_INPUT_SELECTION.json").read_bytes()).hexdigest()}
    (root / "CONTROL_EXTRACT_VERIFICATION.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0 if result["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
