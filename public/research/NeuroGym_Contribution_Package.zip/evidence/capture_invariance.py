"""Capture a seeded sample for byte-exact comparison before and after a cue fix."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from neurogym.envs.native.contextdecisionmaking import ContextDecisionMaking
from neurogym.utils import TruncExp

parser = argparse.ArgumentParser()
parser.add_argument('output', type=Path)
args = parser.parse_args()
records = []
for explicit in (False, True):
    for modality in (0, 1):
        for ring in (2, 4, 8):
            env = ContextDecisionMaking(
                dt=20, sigma=1, use_expl_context=explicit,
                impl_context_modality=modality, dim_ring=ring,
                timing={'fixation': 100, 'stimulus': 750,
                        'delay': TruncExp(600, 300, 3000), 'decision': 100},
            )
            env.seed(29)
            for trial_number in range(20):
                trial = env.new_trial()
                digest = lambda a: hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()
                records.append({
                    'explicit': explicit, 'modality': modality, 'ring': ring,
                    'trial_number': trial_number, 'trial': {k: int(v) for k, v in trial.items()},
                    'shape': list(env.ob.shape), 'period_starts': dict(env.start_ind),
                    'period_ends': dict(env.end_ind), 'non_fixation_sha256': digest(env.ob[:, 1:]),
                    'target_sha256': digest(env.gt),
                    'fixation_sha256': digest(env.ob[:, 0]),
                    'fixation_values': {p: np.unique(env.view_ob(p)[:, 0]).tolist()
                                        for p in ('fixation', 'stimulus', 'delay', 'decision')},
                })
            env.close()
args.output.write_text(json.dumps(records, indent=2) + '\n')
print(f'Captured {len(records)} noisy seeded trials in {args.output}')
