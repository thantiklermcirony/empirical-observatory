"""Read-only NeuroGym #279 diagnostic using the actual installed package.

No training, model calls, environment monkey-patching or private step calls.
The script records generated trial observations and a public-step rollout of a
small observation-driven policy. Run from this research directory with -B.
"""

import argparse
from datetime import datetime, timezone
from importlib.metadata import version
import hashlib
import inspect
import json
from pathlib import Path
import platform

import gymnasium
import neurogym
from neurogym.envs.native.contextdecisionmaking import ContextDecisionMaking
from neurogym.utils import TruncExp
import numpy as np


def make_env(explicit, modality):
    env = ContextDecisionMaking(
        dt=100,
        use_expl_context=explicit,
        impl_context_modality=modality,
        dim_ring=2,
        sigma=0,
        timing={"fixation": 100, "stimulus": 200, "delay": TruncExp(600, 100, 800), "decision": 200},
    )
    env.seed(17)
    return env


TRIAL = {"ground_truth": 1, "other_choice": 2, "coh_1": 50, "coh_2": 50}


def trial_aliasing(explicit, modality):
    env = make_env(explicit, modality)
    snapshots = {}
    for _ in range(64):
        env.new_trial(**TRIAL, context=modality)
        delay = int(env.end_t["delay"] - env.start_t["delay"])
        snapshots.setdefault(delay, {
            "ob": env.ob.copy(),
            "gt": env.gt.copy(),
            "decision_index": int(env.start_ind["decision"]),
            "fixation_by_period": {
                period: np.unique(env.view_ob(period)[:, 0]).tolist()
                for period in ("fixation", "stimulus", "delay", "decision")
            },
        })
    assert len(snapshots) >= 2, "Need two sampled delays under the same configured distribution"
    short_delay, long_delay = sorted(snapshots)[:2]
    short, long = snapshots[short_delay], snapshots[long_delay]
    boundary = short["decision_index"]
    assert short["gt"][boundary] == 1 and long["gt"][boundary] == 0
    assert np.array_equal(short["ob"][:boundary], long["ob"][:boundary])
    result = {
        "explicit_context": explicit,
        "modality": modality,
        "sampled_delays_ms": sorted(snapshots),
        "compared_delays_ms": [short_delay, long_delay],
        "boundary_ms": boundary * 100,
        "same_observation_history_before_boundary": True,
        "same_observation_at_boundary": bool(np.array_equal(short["ob"][boundary], long["ob"][boundary])),
        "short_trial_observation": short["ob"][boundary].tolist(),
        "long_trial_observation": long["ob"][boundary].tolist(),
        "different_supervised_targets": [int(short["gt"][boundary]), int(long["gt"][boundary])],
        "last_delay_observation": short["ob"][boundary - 1].tolist(),
        "first_decision_observation": short["ob"][boundary].tolist(),
        "delay_to_decision_observation_equal": bool(np.array_equal(short["ob"][boundary - 1], short["ob"][boundary])),
        "last_delay_and_first_decision_targets": [int(short["gt"][boundary - 1]), int(short["gt"][boundary])],
        "short_trial_fixation_by_period": short["fixation_by_period"],
    }
    env.close()
    return result


def observation_policy_rollout(explicit, modality):
    env = make_env(explicit, modality)
    env.new_trial(**TRIAL, context=modality)
    # new_trial provides an exact controlled trial; its first stored observation
    # initializes the policy. Subsequent observations come only from env.step.
    observation = env.ob[0].copy()
    remembered_choice = None
    premature = []
    rewards = []
    steps = []
    for _ in range(64):
        context = int(np.argmax(observation[5:7])) if explicit else modality
        sensory = observation[1 + 2 * context: 3 + 2 * context]
        if np.any(sensory):
            remembered_choice = int(np.argmax(sensory)) + 1
        action = 0 if observation[0] > 0 or remembered_choice is None else remembered_choice
        # Phase/time and gt are used only for recording, never choosing action.
        if action and not env.in_period("decision"):
            premature.append(int(env.t))
        current_time = int(env.t)
        phase = next(period for period in ("fixation", "stimulus", "delay", "decision") if env.in_period(period))
        visible_fixation = float(observation[0])
        observation, reward, _, _, info = env.step(action)
        rewards.append(float(reward))
        steps.append({"action_time_ms": current_time, "phase_for_audit_only": phase, "action": action,
                      "visible_fixation": visible_fixation,
                      "reward": float(reward), "target_for_audit_only": int(info["gt"])})
        if info["new_trial"]:
            result = {
                "explicit_context": explicit,
                "modality": modality,
                "policy_information": "Current observation plus remembered argmax of the relevant visible stimulus; no clock, phase, gt or sampled delay.",
                "premature_choice_times_ms": premature,
                "rewards": rewards,
                "steps": steps,
                "total_reward": float(sum(rewards)),
                "reported_performance": float(info["performance"]),
            }
            env.close()
            return result
    raise AssertionError("Bounded diagnostic rollout did not finish")


parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, default=Path(__file__).with_name('reproduction-279.json'))
options = parser.parse_args()
source = Path(inspect.getsourcefile(ContextDecisionMaking)).resolve()
payload = {
    "created_at_utc": datetime.now(timezone.utc).isoformat(),
    "runtime": {"python": platform.python_version(), "neurogym": neurogym.__version__, "numpy": np.__version__, "gymnasium": gymnasium.__version__, "matplotlib": version('matplotlib'), "torch": version('torch')},
    "source_file": str(source),
    "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "trial_diagnostics": [trial_aliasing(explicit, modality) for explicit in (False, True) for modality in (0, 1)],
    "observation_policy_rollouts": [observation_policy_rollout(explicit, modality) for explicit in (False, True) for modality in (0, 1)],
    "scope": "Finite observation/protocol diagnostic, not an RNN learning result or reproduction of the complete Mante experiment.",
}
output = options.output
output.write_text(json.dumps(payload, indent=2, allow_nan=False) + "\n", encoding="utf-8")
print(json.dumps({'output': str(output), 'runtime': payload['runtime'],
                  'aliased_pairs': sum(case['same_observation_at_boundary'] for case in payload['trial_diagnostics']),
                  'premature_actions': [len(case['premature_choice_times_ms']) for case in payload['observation_policy_rollouts']],
                  'rewards': [case['total_reward'] for case in payload['observation_policy_rollouts']]}))
