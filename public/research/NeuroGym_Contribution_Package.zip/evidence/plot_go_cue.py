"""Plot the recorded public-step traces, without synthesizing observations."""
import json
from pathlib import Path

import matplotlib.pyplot as plt

root = Path(__file__).resolve().parent
out = root.parents[2] / 'outputs'
out.mkdir(exist_ok=True)
baseline = json.loads((root / 'reproduction-baseline.json').read_text())
candidate = json.loads((root / 'reproduction-candidate.json').read_text())

plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 11,
                     'text.color': '#eaf0ff', 'axes.labelcolor': '#c7d3ed',
                     'xtick.color': '#c7d3ed', 'ytick.color': '#c7d3ed',
                     'savefig.facecolor': '#0b1020'})
fig, axes = plt.subplots(2, 1, figsize=(10.5, 6.8), sharex=True)
fig.patch.set_facecolor('#0b1020')
for ax, payload, title in zip(axes, (baseline, candidate),
                             ('ORIGINAL / No decision cue', 'CANDIDATE / Visible decision cue'), strict=True):
    trace = payload['observation_policy_rollouts'][0]
    steps = trace['steps']
    times = [row['action_time_ms'] for row in steps]
    decision = next(row['action_time_ms'] for row in steps if row['phase_for_audit_only'] == 'decision')
    ax.set_facecolor('#111a2c')
    ax.step(times, [row['visible_fixation'] for row in steps], where='post',
            label='Wait signal (1 = wait)', color='#5ae4e8', linewidth=2.4)
    ax.step(times, [row['action'] for row in steps], where='post', marker='o', linestyle='--',
            label='Agent action (1 = respond)', color='#ffb570', markersize=6, linewidth=1.5)
    ax.axvline(decision, color='#b7c2d9', linestyle=':', linewidth=1.4)
    ax.text(decision - 8, 1.15, 'Decision opens', ha='right', fontsize=10)
    ax.set_title(title, loc='left', fontsize=13, fontweight='bold', pad=12)
    ax.text(1, 1.065, f"{len(trace['premature_choice_times_ms'])} early responses  |  reward {trace['total_reward']:.0f}",
            transform=ax.transAxes, ha='right', fontsize=10, color='#b7c2d9')
    ax.set_yticks([0, 1])
    ax.set_ylim(-0.18, 1.32)
    ax.set_xlim(-15, times[-1] + 20)
    ax.grid(axis='x', color='#28364c', alpha=0.8)
    for spine in ax.spines.values():
        spine.set_color('#344361')
axes[0].legend(loc='center', bbox_to_anchor=(0.65, 0.5), framealpha=1,
               facecolor='#111a2c', edgecolor='#344361', labelcolor='#eaf0ff', fontsize=10)
axes[-1].set_xlabel('Time within the recorded trial (ms)')
fig.suptitle('Can the agent see when it should act?', x=0.13, y=0.98,
             ha='left', fontsize=18, fontweight='bold')
fig.text(0.13, 0.045, 'Same observation-driven policy; actual NeuroGym step traces.\n'
         'The cue enables correct timing. Early responses remain unpenalized by the existing rewards.',
         color='#b7c2d9', fontsize=10)
fig.subplots_adjust(left=0.13, right=0.97, top=0.86, bottom=0.17, hspace=0.45)
fig.savefig(out / 'NeuroGym_Go_Cue.png', dpi=180)
fig.savefig(out / 'NeuroGym_Go_Cue.svg')
print(out / 'NeuroGym_Go_Cue.png')
