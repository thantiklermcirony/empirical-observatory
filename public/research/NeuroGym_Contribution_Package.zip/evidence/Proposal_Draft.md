# Proposed contribution: make ContextDecisionMaking's decision onset observable

Draft for review, not posted upstream.

The reported missing go cue in [#279](https://github.com/neurogym/neurogym/issues/279)
is reproducible at current main `a32cfa759ced1edbf3d1d7b207260e45a8f8c2d9`.
With zero stimulus noise, fixed stimulus/context conditions and delays sampled
from one seeded `TruncExp` distribution, two trials have identical visible
histories through the shorter trial's decision onset but different supervised
targets. This occurs in both explicit/implicit modes and both modalities.

A small policy using only the current observation and remembered relevant
stimulus choice also receives full reward despite four premature responses.
That demonstrates why reward success can coexist with the missing cue; it does
not establish what the example notebook's trained LSTM learned.

The candidate keeps the existing fixation channel high during fixation,
stimulus and delay, then drops it at decision onset. It adds no dimensions and
does not alter the reward defaults or penalize previously ignored early actions.
Focused regressions cover the observation boundary, variable delays and task
variants. A separate seeded comparison checks that sensory/context values,
targets, trial draws and timings are unchanged.

PR #206 introduced the initial-period-only fixation assignment; #285 changes
the example notebook rather than this environment. Because correcting the cue
changes the inputs seen by existing policies, maintainers should decide whether
this is an in-place bug correction or needs an explicit compatibility/version
choice. This proposal does not change `TrialEnv`, reset semantics or optional
dependency imports.

The intended contribution is a reproducible counterexample, a narrow candidate
repair and regression protection. It does not claim a new learning algorithm,
better trained-model accuracy or a reproduction of the complete Mante task.

Validation now complete: 20 cue cases fail on pristine main while 12 preservation controls pass; all 32 pass on the candidate. Full pytest: 132 passed, with the optional SB3 activation path enabled. Repository lint, formatting and mypy (103 source files) pass; wheel and source distribution build. The separate 240-trial noisy comparison preserves every non-fixation observation byte, target, trial draw and sampled timing. Local candidate commit: `279e434a62a82fd7ef2765f00976aad41fa6fd57`.
