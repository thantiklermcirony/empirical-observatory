# Reproduce the NeuroGym go-cue diagnostic

The recorded execution used Python 3.12.14 on Windows. These shell commands give
the sequence for a fresh environment; the included environment-inventory.txt
records actual installed versions, including tools and other pre-existing
scientific packages. It is an inventory, not a minimal dependency specification.

```sh
git clone https://github.com/neurogym/neurogym.git
cd neurogym
git checkout a32cfa759ced1edbf3d1d7b207260e45a8f8c2d9
python -m venv .venv
# Activate .venv using the command for your platform.
python -m pip install torch==2.14.0 --index-url https://download.pytorch.org/whl/cpu
python -m pip install -e ".[rl]" pytest==9.1.1
python /path/to/evidence/reproduce_279.py --output before.json
python -m pytest /path/to/evidence/test_independent_go_cue.py -q
# Expected on the original: 20 failures, 12 passes.
git apply /path/to/NeuroGym_Go_Cue.patch
python /path/to/evidence/reproduce_279.py --output after.json
python -m pytest tests -q
# Recorded candidate result: 132 passed.
```

Use a fresh environment object for each controlled rollout. `new_trial` does not
reset a previously stepped object's clock. The scripts use public `seed`, which
also seeds callable timing distributions. They do not substitute random reset
samples for actual observations, stub imports, or invoke private step methods.

Run capture_invariance.py before and after applying the patch to regenerate the
240-trial preservation records. Compare observations except fixation, trial draws,
targets and timing. Diagnostic rewards and targets belong to the action just
taken; a returned step observation is for the next action.

For developer checks, install the repository's dev tools. The successful run used
Ruff 0.11.13, mypy 2.3.1, scipy-stubs 1.17.1.5 and optype 0.17.1 (the latter two
support the configured Python 3.11 typing target), then ran `ruff check`,
`ruff format --check`, `mypy neurogym tests` and `python -m build --no-isolation`.
This package is a local candidate, not a released NeuroGym build.
