# Virtual Cell / Flight 02 reproduction

The context-informed candidate missed its frozen success gate. Read virtual-cell-flight02/README.md for the complete result and limitations.

This compact package contains frozen executable code, controls and input identities, all pair errors/retained sets, prediction manifests, and independent reviews. It omits the 65.7 MB public response shard and five original prediction archives (77.1 MB). Download the response with the supplied hash-checking script. Original prediction archives are available in the GitHub results directory:
https://github.com/thantiklermcirony/empirical-observatory/tree/main/research/virtual-cell-flight02/results

After extracting, from this package root using Python 3.12+:

    python -m pip install -r virtual-cell-flight02/experiment/requirements.txt
    python -m unittest discover -s virtual-cell-flight02/experiment -p 'test_*.py' -v
    python virtual-cell-flight02/download_response.py
    python virtual-cell-flight02/experiment/run.py --execute-real-data --freeze-manifest virtual-cell-flight02/experiment/FROZEN_EXECUTION.json --response virtual-cell-flight02/data-gate/plate_plate1.parquet --controls virtual-cell-next/controls-plate1.npz --selection virtual-cell-next/FROZEN_INPUT_SELECTION.json --preflight virtual-cell-flight02/data-gate/SCHEMA_PREFLIGHT.json --output virtual-cell-flight02/reproduced-results

Set OPENBLAS_NUM_THREADS=1, OMP_NUM_THREADS=1 and MKL_NUM_THREADS=1 before Python for bounded CPU use. The original five-fold analysis took about 28.2 seconds on the recorded environment, before final evidence export; this is not a cross-hardware speed guarantee. No GPU or paid API is used.

The real-data command refuses to overwrite existing results. It reproduces predictions and scoring into a new directory. Timestamped/compressed files may differ bytewise; compare numeric results using stated tolerances and inspect generated hashes. To audit the original evidence exactly, download the five original NPZs into virtual-cell-flight02/results, then run virtual-cell-flight02/independent-review/actual-results/audit_actual.py. Preserve the included original audit before rerunning that script, which writes its own audit records.

Publisher source data: tahoebio/tahoe-de-rhaister revision c7963cf334bec0683225d41c9586d900ca6303a2, publisher CC0. Only released DMSO means are included here. Normalization provenance, upstream gene selection, missing pairs and shared measurement noise remain limits. The source repository LICENSE governs this implementation.
