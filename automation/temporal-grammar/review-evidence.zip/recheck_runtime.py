"""Bounded recheck of the five observed failures; preserve initial evidence."""
from pathlib import Path
from copy import deepcopy
from fractions import Fraction as F
import hashlib,json,os,shutil,sys,tempfile,unittest
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent;OUT=HERE/'executable-v2-complete'
OUT.mkdir(exist_ok=False);SNAP=OUT/'runtime';SNAP.mkdir()
NAMES=['grammar.py','configure.py','io_utils.py','worker.py','run.py','examples.py','test_grammar.py','test_integration.py']
for name in NAMES:shutil.copy2(ROOT/'runtime'/name,SNAP/name)
initial={name:hashlib.sha256((SNAP/name).read_bytes()).hexdigest() for name in NAMES}
sys.path.insert(0,str(SNAP));tempfile.tempdir=str(OUT)
for name in ['MATH','QUANTUM','REFERENCE']:os.environ['OBSERVATORY_'+name+'_ROOT']=str(ROOT/'adapter-review'/name.lower())
import configure,examples,grammar,run,io_utils,test_grammar,test_integration
config=configure.configure(ROOT/'adapter-review/math',ROOT/'adapter-review/quantum',ROOT/'adapter-review/reference')
io_utils.write_json(OUT/'config.json',config)
rows=[]
def row(name,**details):
    rows.append(dict(name=name,passed=True,**details));io_utils.write_json(OUT/'receipt.json',dict(rows=rows,source_sha256=initial))
    print(name,json.dumps(details),flush=True)
def execute(name,q,previous=None,cfg=None):return run.execute(q,cfg or config,OUT/name,previous)
def no_calls(name,q,previous=None):
    r=execute(name,q,previous);assert not r['execution']['jobs'];assert all(x['value'] is None for x in r['results']);return r
def codes(r):return sorted({i['code'] for x in r['results'] for i in x['issues']})
def reject(name,q,previous=None):
    try:execute(name,q,previous)
    except ValueError as exc:
        assert not (OUT/name).exists();return str(exc)
    raise AssertionError('Expected atomic rejection: '+name)

suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromModule(test_grammar),unittest.defaultTestLoader.loadTestsFromModule(test_integration)])
with (OUT/'supplied-tests.log').open('w',encoding='utf-8') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
assert result.wasSuccessful();row('supplied_tests',tests=result.testsRun)
ab=execute('ab',examples.actions());ba=execute('ba',examples.actions(True))
assert F(ab['results'][-1]['value'])==F(7,26) and F(ba['results'][-1]['value'])==F(11,25)
row('real_order_controls',ab=ab['results'][-1]['value'],ba=ba['results'][-1]['value'])

# Replay original failed record unchanged, then isolate the lineage check in the new supported notation.
q=io_utils.read_json(HERE/'executable-v1/state-lineage-bypass/input.json');r=no_calls('original-lineage',q)
q=examples.actions();q['operations'][1]['inputs']['state']='x';r=execute('lineage',q)
assert r['results'][0]['status']=='established_in_scope'
assert r['results'][1]['value'] is None and r['results'][1]['status']=='unresolved'
assert [j['step_id'] for j in r['execution']['jobs']]==['step0']
assert 'state_lineage_mismatch' in codes(r);row('state_lineage_fixed',issues=codes(r),valid_prefix_retained=True)

normal=execute('resource',examples.resource());normal_bytes=io_utils.canonical(normal)
corrected=execute('corrected',examples.resource(True),normal)
assert corrected['results'][0]['value']['ceiling_interval_mM']==['6051/10000','127/200']
assert normal['results'][0]['value']['ceiling_interval_mM']==['5541/10000','283/500']
assert normal['results'][0]['value']['target_excluded'] and not corrected['results'][0]['value']['target_excluded']
assert corrected['contrast']['revision_binding']['kind']=='validated_quantity_replacement'
assert io_utils.canonical(normal)==normal_bytes
row('resource_correction_control',before=normal['results'][0]['value'],after=corrected['results'][0]['value'])

rejections=[]
q=examples.resource(True);q['provenance']['correction']['replaces']='nonexistent-preparation:missing-signal'
rejections.append(reject('bad-replaces',q,normal))
q=examples.resource(True);q['provenance']['correction']['replaces']='revision1:unknown'
rejections.append(reject('missing-quantity',q,normal))
q=examples.resource(True);q['observer']['preparation_id']='another-preparation'
for item in q['quantities'][:3]:item['preparation_id']='another-preparation'
rejections.append(reject('correction-new-prep',q,normal))
q=examples.resource(True);q['quantities'][1]['value']=['0.97','1']
rejections.append(reject('unnamed-change',q,normal))
rejections.append(reject('correction-without-previous',examples.resource(True)))
row('correction_reference_fixed',atomic_rejections=rejections)

q=examples.resource();q['identity']['revision']=2;q['observer']['preparation_id']='different-preparation'
for item in q['quantities'][:3]:item['preparation_id']='different-preparation'
r=execute('prep-update',q,normal)
assert r['contrast']['revision_binding']['kind']=='revision_comparison'
assert r['contrast']['revision_changes'][0]['transition']=='support_changed'
q=examples.actions();q['mechanism']={};q['operations']=q['operations'][:1];q['quantities'][0]['value']='0';q['quantities'][1]['value']='0'
before=execute('model-before',q);q2=deepcopy(q);q2['identity']['revision']=2;q2['operations'][0]['verb']='contract';q2['operations'][0]['inputs']['parameter']='c'
after=execute('model-after',q2,before)
assert before['results'][0]['value']==after['results'][0]['value']=='0'
assert after['contrast']['revision_changes'][0]['transition']=='support_changed'
row('equal_number_support_fixed',preparation_transition=r['contrast']['revision_changes'],model_transition=after['contrast']['revision_changes'])

# Changed parent premise propagates even when an absorbing numeric value is unchanged.
q=examples.actions();q['quantities'][2]['value']='0';p0=execute('premise-before',q)
q['identity']['revision']=2;next(p for p in q['premises'] if p['id']=='DECLARED-PROJECTIVE')['status']='derived'
p1=execute('premise-after',q,p0)
assert p0['results'][-1]['value']==p1['results'][-1]['value']=='0'
assert all(x['transition']=='support_changed' for x in p1['contrast']['revision_changes'])
row('transitive_support_fixed',transitions=p1['contrast']['revision_changes'])

q=io_utils.read_json(HERE/'executable-v1/contradictory-structured-mechanism/input.json');r=no_calls('structured-conflict',q)
assert {'unsupported_mechanism','unsupported_constraints'}<=set(codes(r))
q=examples.actions();q['mechanism']['models']['step1']='math.projective.action';late=no_calls('late-model-mismatch',q)
assert 'mechanism_mismatch' in codes(late)
row('structured_model_conflict_fixed',original_codes=codes(r),later_step_codes=codes(late))

for label,observer_time,input_time in [('both',True,True),('observer',True,False),('input',False,True)]:
    q=examples.quantum(ROOT/'adapter-review/quantum')
    if observer_time:q['observer']['time']={'value':'100','unit':'model_time'}
    if input_time:q['quantities'][0]['time']={'value':'0','unit':'model_time'}
    r=no_calls('quantum-time-'+label,q)
    assert {'observation_time_not_supported','input_time_not_supported'}&set(codes(r))
row('quantum_time_fixed',variants=3)
q=examples.quantum(ROOT/'adapter-review/quantum');r=execute('quantum-normal',q)
assert r['results'][0]['status']=='established_in_scope'
y=next(x for x in r['results'][0]['value']['conclusions'] if x['id']=='Q-REFERENCE-YIELDS')['value']
assert abs(y[0]['final']['yield_s']-.75)<1e-12 and abs(y[1]['final']['yield_s']-.25)<1e-12
row('quantum_control',yield_s=[x['final']['yield_s'] for x in y])

# Re-run the 14 previous no-dispatch cases with the currently admitted mechanism descriptor.
count=0
for folder in sorted((HERE/'executable-v1').glob('negative-*')):
    q=io_utils.read_json(folder/'input.json');q['mechanism']=examples.resource()['mechanism']
    no_calls('repeat-'+folder.name,q);count+=1
# Original command-injection schema rejection produced no saved directory.
q=examples.resource();q['operations'][0]['command']=['cmd','/c','never'];reject('command-field',q);count+=1
assert count==14;row('negative_gate_controls',cases=count)

# Verify support snapshots do not alias either inputs or previous results.
q=examples.actions();input_before=io_utils.canonical(q);r=execute('immutability',q)
assert io_utils.canonical(q)==input_before
record_before=io_utils.canonical(r);q['premises'][0]['status']='missing';q['quantities'][0]['value']='0'
assert io_utils.canonical(r)==record_before;run.check_receipt(r);run.check_receipt(normal)
assert io_utils.canonical(normal)==normal_bytes;row('receipt_input_immutability',passed_checks=4)
changed=deepcopy(normal);changed['results'][0]['value']['target_excluded']=False
reject('mutated-receipt',examples.resource(True),changed);reject('stale-revision',examples.resource(),normal)
row('mutation_and_stale_controls',atomic_rejections=2)

# Preserve exact source-byte mutation/selective hold control using owned copies only.
dep=OUT/'geometry-copy';shutil.copytree(ROOT/'adapter-review/math/inputs/companion/vendor',dep/'inputs/companion/vendor')
altered=deepcopy(config);altered['source_roots']['geometry']=str(dep)
source=dep/'inputs/companion/vendor/geometry.py';source.write_bytes(source.read_bytes()+b'\n# independent mutation\n')
r=execute('source-resource',examples.resource(),cfg=altered);unrelated=execute('source-math',examples.actions(),cfg=altered)
assert r['results'][0]['status']=='execution_error' and not r['execution']['jobs'][0]['executed']
assert unrelated['results'][-1]['value']=='7/26'
row('selective_actual_source_change',resource='blocked_before_worker',math='7/26')

final={name:hashlib.sha256((ROOT/'runtime'/name).read_bytes()).hexdigest() for name in NAMES}
assert initial==final;row('freeze_unchanged',files=len(initial))
