# Temporal routing spine: initial independent executable review

**Historical initial finding record.** The corrected bytes subsequently passed independent recheck; see [FINAL_REVIEW.md](C:/Users/madma/Documents/Codex/2026-09-09/ca/work/temporal-grammar-integration/review/FINAL_REVIEW.md). The original findings and first-run evidence below are retained unchanged.

12 September 2026. **Hold acceptance of temporal composition/correction semantics pending the five bounded fixes below.** Actual fixed adapter dispatch and the numerical positive controls work. This is a local engineering review, not a theorem, discovery, empirical-admission or hosted-service assessment.

I read the source review, adapter review and all eight runtime files before execution. Runtime files were copied unchanged into `review/executable-v1/runtime/`; inputs, outputs, test logs and the mutated dependency copy stayed under `review/executable-v1/`. The parent runtime's eight file hashes were unchanged at the end of the probe. Exact hashes and observations are in [probes.json](C:/Users/madma/Documents/Codex/2026-09-09/ca/work/temporal-grammar-integration/review/executable-v1/probes.json). The reproducible audit script is [probe_runtime.py](C:/Users/madma/Documents/Codex/2026-09-09/ca/work/temporal-grammar-integration/review/probe_runtime.py); it intentionally refuses to overwrite its first evidence directory.

## Findings requiring correction

### 1. Execution order does not enforce physical state lineage

[grammar.py:215](C:/Users/madma/Documents/Codex/2026-09-09/ca/work/temporal-grammar-integration/review/executable-v1/runtime/grammar.py:215) adds the preceding physical operation to `depends_on`, but accepts any compatible original state quantity as the next action's input. This enforces scheduling without enforcing the chronological state-map composition defined by the manuscript.

Reproducer: start with `examples.actions()` and set `operations[1].inputs.state = 'x'`. It returns `complete_in_declared_scope`, prints the scientific word `align, contract`, and records step1 depending on step0, yet returns **1/8**. For the declared x=1/4, u=1/3 and c=1/2, A(x)=(x+u)/(1+xu)=7/13; B(A(x))=**7/26**. The actual 1/8 is B(x), silently bypassing A's state output. The native arithmetic itself is correct for that different input.

Minimum fix: for a state-consuming physical word, require the admitted current state reference to follow the preceding compatible physical state's output. An explicit registered reset/branch would be a separate operation; do not infer one. Independently evaluated actions may remain allowed under a clearly different plan meaning. Test both legal AB/BA and bypass of the immediate/earlier state.

### 2. Equal numerical outputs hide changed scientific support

[run.py:32](C:/Users/madma/Documents/Codex/2026-09-09/ca/work/temporal-grammar-integration/review/executable-v1/runtime/run.py:32) determines `unchanged` from value and status alone. Changing the capability, premises, preparation, units or dependency support can therefore leave the revision transition `unchanged`.

Two real reproductions: (a) evaluate projective x=0,u=0, then replace it with contraction x=0,c=1/2 at the same step ID; both values are 0 but capability and required premise differ, and the transition is `unchanged`; (b) copy the resource values into an entirely different preparation at revision2 and change each contextual quantity's preparation to match; the result again says `unchanged`.

Minimum fix: compare a deterministic support identity covering capability/version/source, actual input bindings and context, premise statuses, and parent support. Keep numerical equality separate from scientific-result currency. Exclude timestamps/output-path noise from support identity. Propagate the changed support to descendants even when their final number coincides.

### 3. Named correction references are not validated

[run.py:48](C:/Users/madma/Documents/Codex/2026-09-09/ca/work/temporal-grammar-integration/review/executable-v1/runtime/run.py:48) checks only intact previous receipt, same inquiry ID and next integer revision. Setting the corrected resource's `provenance.correction.replaces` to `nonexistent-preparation:missing-signal` is accepted and copied into a completed receipt. It does not point to a previous quantity.

Minimum fix: when a record explicitly declares a correction, resolve its replacement against the previous revision/quantity and require compatible quantity meaning, unit-map, preparation and physical time. Reject a bogus or ambiguous replacement before dispatch. Plain version comparisons may remain separate and must be labelled as such. This review does **not** require building an authenticated event bus or claiming the companion's full durable/idempotent delivery semantics this turn.

### 4. Contradictory structured mechanism/constraints remain in a completed report

[run.py:63](C:/Users/madma/Documents/Codex/2026-09-09/ca/work/temporal-grammar-integration/review/executable-v1/runtime/run.py:63) copies the inquiry, while the worker executes the fixed registered formula. The compiler does not bind/check the inquiry's `mechanism` or `constraints`, yet [run.py:120](C:/Users/madma/Documents/Codex/2026-09-09/ca/work/temporal-grammar-integration/review/executable-v1/runtime/run.py:120) describes success as `complete_in_declared_scope`.

Reproducer: change `examples.actions().mechanism.align` to `x-u` and set `constraints.output_must_be_negative=true`. The report retains those structured declarations but computes projective alignment **7/13**, rather than x-u=−1/12, and reports completion. The disclaimer says original **prose** is not interpreted; these are structured scientific fields.

Minimum fix: bind the admitted mechanism/constraints to the chosen capability, or explicitly retain submitted unsupported declarations as unresolved/uninterpreted context while returning a separately identified effective model. A conflicting scientific assertion must not be silently represented as the model that ran. No free-form expression parser is needed; exact known descriptors or clear rejection are sufficient.

### 5. Explicit unsupported quantum time context passes admission

The quantum protocol port is noncontextual in [configure.py:48](C:/Users/madma/Documents/Codex/2026-09-09/ca/work/temporal-grammar-integration/review/executable-v1/runtime/configure.py:48). [grammar.py:245](C:/Users/madma/Documents/Codex/2026-09-09/ca/work/temporal-grammar-integration/review/executable-v1/runtime/grammar.py:245) checks explicit input time only for contextual ports. The worker reconstructs the trusted reference request and replaces only its protocol ([worker.py:115](C:/Users/madma/Documents/Codex/2026-09-09/ca/work/temporal-grammar-integration/review/executable-v1/runtime/worker.py:115)).

Reproducer: take `examples.quantum(...)`, set `observer.time={value:'100',unit:'model_time'}` and the protocol quantity's `time={value:'0',unit:'model_time'}`. The protocol still runs its native 0-to-40 horizon and the report retains the 100/0 context with `complete_in_declared_scope`. There is no declared meaning for the extra time or map to the native clock.

Minimum fix: reject unsupported explicit context for this whole-protocol capability, or bind it to an explicit registered start/horizon convention. Do not infer physical time or equate receipt chronology with propagation. The normal protocol without these unsupported timestamps should continue to work.

## Checks that passed and should be retained

- **36 unchanged supplied tests pass.** Their integration tests were rebound only to the existing reviewed dependency root; temp output stayed in this review directory. No shared test source was edited.
- Independently evaluated real AB/BA calls give **7/26 versus 11/25** using exact Fractions and actual pinned algebra workers, with transitive premises retained.
- **14 independent negative admission cases** produce no worker call: wrong role/meaning/shape, a rate presented as stock, absent value, wrong/missing preparation, wrong physical time/clock, intervention relabelling, requested trajectory, missing volume, unknown verb/path and operation command injection.
- Actual resource dispatch gives `[5541/10000,283/500]` mM; the corrected values give `[6051/10000,127/200]` mM and change target exclusion from true to false. These remain synthetic necessary ceilings, not attainability.
- Unrehashed receipt content mutation and stale revision are rejected. That is local integrity checking, not proof of authenticated measurement provenance.
- An **actual byte mutation of an owned geometry source**, retaining the original pin, prevents the resource worker from executing and yields `execution_error`; unrelated mathematical AB still gives 7/26. This checks selective source enforcement rather than merely altering an expected hash.
- The actual quantum adapter runs the accepted reference and preserves its unresolved redox-map conclusion. No optical candidate or cross-domain physical claim was executed.

The receipt contains 13 observation groups, including the supplied test summary and source-freeze check; not all are passing acceptance tests. The five findings above are intentionally preserved as observed failures. The ordinary safe examples working does not discharge these adversarial failures.

## Bounded correction acceptance

Recheck the exact five failing inputs, then the existing positive/negative controls once. Require blocked/unresolved incompatible requests or accurate revised-support semantics; do not erase the original receipts or reinterpret the failed inputs as new successful examples. Keep the current distinction between a local structured execution spine and a future durable/hosted service. Domain numerical campaigns and new scientific features are outside this review.
