"""Execute a typed ordered inquiry through configured existing local engines."""
import argparse
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
import subprocess
import sys

from grammar import compile_inquiry
from io_utils import check_sources, digest, file_hash, read_json, write_json


def check_receipt(record):
    unsigned = deepcopy(record)
    expected = unsigned['execution'].pop('receipt_sha256')
    if digest(unsigned) != expected:
        raise ValueError('Changed recorded inquiry')


def changes(previous, current):
    if previous is None:
        return []
    check_receipt(previous)
    if previous['identity']['id'] != current['identity']['id'] or current['identity']['revision'] != previous['identity']['revision'] + 1:
        raise ValueError('Correction requires the same inquiry and next revision')
    old = {r['id']: r for r in previous['results']}
    new = {r['id']: r for r in current['results']}
    result = []
    for key, before in old.items():
        after = new.get(key)
        withdrawn = before['status'] == 'established_in_scope' and (after is None or after['status'] != 'established_in_scope')
        revised = after is None or before.get('value') != after.get('value') or before['status'] != after['status']
        result.append({'result_id': key, 'previous_revision': previous['identity']['revision'],
                       'current_revision': current['identity']['revision'],
                       'transition': 'withdrawn' if withdrawn else 'revised' if revised else 'unchanged',
                       'previous_receipt_sha256': previous['execution']['receipt_sha256']})
    return result


def execute(inquiry, config, outdir, previous=None):
    if len(__import__('io_utils').canonical(inquiry)) > 65536:
        raise ValueError('Inquiry exceeds 64 KB')
    if len(inquiry['operations']) > 32 or len(inquiry['quantities']) > 128:
        raise ValueError('Local inquiry step or quantity budget exceeded')
    compiler_catalogue = {'capabilities': [{k: v for k, v in cap.items() if k != 'source_groups'} for cap in config['capabilities']]}
    plan = compile_inquiry(inquiry, compiler_catalogue)
    if previous is not None:
        check_receipt(previous)
        if previous['identity']['id'] != inquiry['identity']['id'] or inquiry['identity']['revision'] != previous['identity']['revision'] + 1:
            raise ValueError('Correction requires the same inquiry and next revision')
    if config['python_sha256'] != file_hash(sys.executable):
        raise ValueError('Configured Python runtime changed')
    check_sources(config, ['runtime'])
    folder = Path(outdir).resolve()
    folder.mkdir(parents=True, exist_ok=False)
    write_json(folder / 'input.json', inquiry)
    write_json(folder / 'plan.json', plan)
    # Configuration is operator-owned; it is never supplied by a question.
    write_json(folder / 'worker-config.json', config)
    quantities = {q['id']: q for q in inquiry['quantities']}
    capabilities = {c['id']: c for c in config['capabilities']}
    outputs = {}
    report = deepcopy(inquiry)
    results = []
    jobs = []
    for index, step in enumerate(plan['steps']):
        result = {'id': step['id'], 'status': 'unresolved', 'value': None,
                  'depends_on': step['depends_on'], 'premise_ids': step['premise_ids'],
                  'issues': deepcopy(step['issues']), 'unit': (step['output_contract'] or {}).get('unit'),
                  'result_kind': 'hypothesis_or_analogy'}
        if step['status'] == 'ready' and any(dep not in outputs for dep in step['depends_on']):
            result['issues'].append({'code': 'dependency_unavailable', 'message': 'A required earlier result did not execute successfully.'})
        elif step['status'] == 'ready':
            spec = capabilities[step['capability_id']]
            result.update(result_kind=spec['result_kind'], scope=spec['scope'], capability_id=spec['id'])
            bindings = {}
            for port, reference in step['bindings'].items():
                bindings[port] = deepcopy(quantities[reference] if isinstance(reference, str) else outputs[reference['step']])
            job = {'inquiry_id': inquiry['identity']['id'], 'revision': inquiry['identity']['revision'],
                   'step_id': step['id'], 'capability_id': spec['id'], 'bindings': bindings,
                   'context': {'jurisdiction': inquiry['system']['jurisdiction'],
                               'preparation_id': inquiry['observer']['preparation_id'],
                               'clock': inquiry['observer']['clock'], 'time': inquiry['observer'].get('time')},
                   'premise_ids': step['premise_ids'], 'depends_on': step['depends_on']}
            job_path = folder / f'job-{index}.json'
            output_path = folder / f'worker-{index}.json'
            write_json(job_path, job)
            argv = [sys.executable, '-X', 'utf8', '-B', str(Path(__file__).with_name('worker.py')),
                    '--config', str(folder / 'worker-config.json'), '--job', str(job_path), '--out', str(output_path)]
            receipt = {'step_id': step['id'], 'capability_id': spec['id'], 'job_sha256': digest(job),
                       'input_ports': sorted(bindings), 'argv': argv, 'executed': False}
            try:
                check_sources(config, ['runtime', *spec['source_groups']])
                completed = subprocess.run(argv, shell=False, capture_output=True, text=True, encoding='utf-8', timeout=75)
                receipt.update(executed=True, exit_code=completed.returncode,
                               stderr=completed.stderr[:2000], stdout_sha256=digest(completed.stdout))
                if completed.returncode != 0:
                    raise ValueError('Capability worker rejected or failed the request: ' + completed.stderr[:500])
                native = read_json(output_path, limit=2000000)
                if native['job_sha256'] != digest(job) or native['capability_id'] != spec['id']:
                    raise ValueError('Worker returned a different job binding')
                check_sources(config, ['runtime', *spec['source_groups']])
                result.update(status='established_in_scope', value=native['value'],
                              native_artifact=output_path.name, native_sha256=file_hash(output_path),
                              interpretation=native['interpretation'])
                outputs[step['id']] = {**deepcopy(spec['output']), 'id': step['id'], 'value': native['value'],
                                       'preparation_id': inquiry['observer']['preparation_id'],
                                       'time': inquiry['observer'].get('time')}
            except (OSError, ValueError, KeyError, subprocess.TimeoutExpired) as error:
                result.update(status='execution_error', value=None)
                result['issues'].append({'code': 'execution_or_source_failure', 'message': str(error)[:1000]})
            jobs.append(receipt)
        results.append(result)
    report['results'] = results
    report['execution'] = {**deepcopy(inquiry['execution']), 'router': 'temporal-grammar-spine/0.1',
        'mode': 'local controlled execution; no hosted service or authenticated admission',
        'input_sha256': digest(inquiry), 'configuration_sha256': digest(config),
        'scientific_word': plan['word'], 'plan': plan, 'jobs': jobs,
        'interpretation_scope': 'Only this structured plan is computed; original prose is not independently interpreted.',
        'status': 'complete_in_declared_scope' if results and all(r['status'] == 'established_in_scope' for r in results) else 'partial_or_gap',
        'created_at': datetime.now(timezone.utc).isoformat()}
    report['contrast'] = {**deepcopy(inquiry['contrast']), 'revision_changes': changes(previous, report)}
    report['next_question'] = {'origin': 'compiler_missing_obligations', 'requests': [
        {'step_id': r['id'], 'issues': r['issues']} for r in results if r['status'] != 'established_in_scope']}
    report['execution']['receipt_sha256'] = digest(report)
    write_json(folder / 'inquiry.json', report)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input')
    parser.add_argument('--config', required=True)
    parser.add_argument('--out', required=True)
    parser.add_argument('--previous')
    args = parser.parse_args()
    try:
        result = execute(read_json(args.input), read_json(args.config), args.out,
                         read_json(args.previous, 2000000) if args.previous else None)
        print(result['execution']['status'])
    except (ValueError, OSError, KeyError) as error:
        print(str(error), file=sys.stderr)
        raise SystemExit(2)
