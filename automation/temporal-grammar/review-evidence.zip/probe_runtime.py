"""Independent bounded routing audit; all execution and mutations stay in owned copies."""
from pathlib import Path
from copy import deepcopy
from fractions import Fraction as F
import hashlib, json, shutil, sys, tempfile, unittest

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
OUT=HERE/'executable-v1'
OUT.mkdir(exist_ok=False)
SNAP=OUT/'runtime'
shutil.copytree(ROOT/'runtime',SNAP)
source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'runtime').glob('*.py')}
sys.path.insert(0,str(SNAP))
import configure, examples, grammar, run, io_utils
config=configure.configure(ROOT/'adapter-review/math',ROOT/'adapter-review/quantum',ROOT/'adapter-review/reference')
io_utils.write_json(OUT/'config.json',config)
catalogue={'capabilities':[{k:v for k,v in c.items() if k!='source_groups'} for c in config['capabilities']]}
tempfile.tempdir=str(OUT)
rows=[]
def save(name, **details):
    rows.append(dict(name=name,**details))
    io_utils.write_json(OUT/'probes.json',dict(rows=rows,source_sha256=source_hashes))
    print(name, json.dumps(details,ensure_ascii=False),flush=True)
def execute(name,q,previous=None,configuration=None):
    return run.execute(q,configuration or config,OUT/name,previous)
def rejected_no_calls(name,q):
    try:
        r=execute(name,q)
        assert not r['execution']['jobs'] and all(x['value'] is None for x in r['results'])
        return 'gap'
    except ValueError:
        return 'rejected'

# Run unchanged supplied tests while rebinding their dependency root to reviewed copies.
import test_grammar, test_integration
test_integration.ROOT=ROOT
suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromModule(test_grammar),unittest.defaultTestLoader.loadTestsFromModule(test_integration)])
with (OUT/'supplied-tests.log').open('w',encoding='utf-8') as stream:
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
save('supplied_tests',tests=result.testsRun,passed=result.wasSuccessful(),failures=len(result.failures),errors=len(result.errors))

ab=execute('ab',examples.actions())
ba=execute('ba',examples.actions(True))
project=lambda x,u:(x+u)/(1+x*u)
expected_ab=F(1,2)*project(F(1,4),F(1,3))
expected_ba=project(F(1,2)*F(1,4),F(1,3))
assert F(ab['results'][-1]['value'])==expected_ab and F(ba['results'][-1]['value'])==expected_ba
save('independent_order_controls',ab=str(expected_ab),ba=str(expected_ba),actual_jobs=[len(ab['execution']['jobs']),len(ba['execution']['jobs'])])

negative=[]
for label,field,value in [('wrong_role','role','trajectory'),('wrong_meaning','meaning','optical_intensity'),('rate','unit','uM/s'),('no_value','value',None),('shape','shape','trajectory')]:
    q=examples.resource();q['quantities'][2][field]=value
    negative.append([label,rejected_no_calls('negative-'+label,q)])
for label,change in [
    ('preparation',lambda q:q['quantities'][2].update(preparation_id='other')),
    ('physical_time',lambda q:q['quantities'][2].update(time={'value':'5','unit':'min'})),
    ('recording_clock',lambda q:q['observer']['clock'].update(kind='recording')),
    ('no_context',lambda q:q['quantities'][2].pop('preparation_id')),
    ('intervention',lambda q:q['operations'][0].update(kind='action')),
    ('requested_trajectory',lambda q:q['operations'][0].update(requested_output={'meaning':'achieved_extent','role':'trajectory','unit':'mM','shape':'object'})),
    ('missing_volume',lambda q:next(p for p in q['premises'] if p['id']=='BIO-VOLUME').update(status='missing')),
    ('unknown_verb',lambda q:q['operations'][0].update(verb='../../worker.py')),
    ('command_injection',lambda q:q['operations'][0].update(command=['cmd','/c','never']))
]:
    q=examples.resource();change(q);negative.append([label,rejected_no_calls('negative-'+label,q)])
save('semantic_no_dispatch',cases=negative,count=len(negative))

# Serial execution is not state composition if the second action bypasses its predecessor.
q=examples.actions();q['operations'][1]['inputs']['state']='x'
r=execute('state-lineage-bypass',q)
save('state_lineage_bypass',status=r['execution']['status'],word=r['execution']['scientific_word'],second_dependencies=r['results'][1]['depends_on'],actual=r['results'][1]['value'],composed_expected=str(expected_ab),independent_original_state_value='1/8')

normal=execute('resource',examples.resource())
corrected=execute('resource-corrected',examples.resource(True),normal)
assert normal['results'][0]['value']['ceiling_interval_mM']==['5541/10000','283/500']
assert corrected['results'][0]['value']['ceiling_interval_mM']==['6051/10000','127/200']
save('resource_control',before=normal['results'][0]['value'],after=corrected['results'][0]['value'],transition=corrected['contrast']['revision_changes'])

q=examples.resource(True);q['provenance']['correction']['replaces']='nonexistent-preparation:missing-signal'
r=execute('bad-correction-reference',q,normal)
save('unknown_correction_reference',status=r['execution']['status'],correction=r['provenance']['correction'],transition=r['contrast']['revision_changes'])
q=examples.resource();q['identity']['revision']=2;q['observer']['preparation_id']='different-preparation'
for item in q['quantities'][:3]:item['preparation_id']='different-preparation'
r=execute('changed-preparation',q,normal)
save('preparation_change_same_value',status=r['execution']['status'],transition=r['contrast']['revision_changes'],before_preparation=normal['observer']['preparation_id'],after_preparation=r['observer']['preparation_id'])

# Models with equal numeric output are different support, even when step IDs agree.
q=examples.actions();q['operations']=q['operations'][:1];q['quantities'][0]['value']='0';q['quantities'][1]['value']='0'
before=execute('model-before',q)
q2=deepcopy(q);q2['identity']['revision']=2;q2['operations'][0]['verb']='contract';q2['operations'][0]['inputs']['parameter']='c'
after=execute('model-after',q2,before)
save('changed_capability_same_value',before=before['results'][0],after=after['results'][0],transition=after['contrast']['revision_changes'])

q=examples.actions();q['mechanism']['align']='x-u';q['constraints']={'output_must_be_negative':True}
r=execute('contradictory-structured-mechanism',q)
save('retained_unchecked_mechanism',status=r['execution']['status'],mechanism=r['mechanism'],constraints=r['constraints'],actual=r['results'][0]['value'],native_expression=io_utils.read_json(OUT/'contradictory-structured-mechanism/worker-0.json')['native']['steps'][0]['result_scope'])

# Check existing stale/mutation rejection without rehashing caller-supplied records.
errors=[]
for label,old,new in [('mutation',deepcopy(normal),examples.resource(True)),('stale',normal,examples.resource())]:
    if label=='mutation':old['results'][0]['value']['target_excluded']=False
    try:execute('reject-'+label,new,old)
    except ValueError as exc:errors.append([label,str(exc)])
assert len(errors)==2
save('receipt_mutation_and_revision',rejected=errors)

# Real source-byte changes only in an owned dependency copy, with stale pins retained.
dep=OUT/'geometry-copy';shutil.copytree(ROOT/'adapter-review/math/inputs/companion/vendor',dep/'inputs/companion/vendor')
altered=deepcopy(config);altered['source_roots']['geometry']=str(dep)
source=dep/'inputs/companion/vendor/geometry.py';source.write_bytes(source.read_bytes()+b'\n# independent source mutation\n')
r=execute('changed-source-resource',examples.resource(),configuration=altered)
assert r['results'][0]['status']=='execution_error' and not r['execution']['jobs'][0]['executed']
unrelated=execute('changed-source-math',examples.actions(),configuration=altered)
assert unrelated['results'][-1]['value']=='7/26'
save('actual_source_change_selective',resource_status=r['results'][0]['status'],resource_worker_invoked=r['execution']['jobs'][0]['executed'],unrelated_math_value=unrelated['results'][-1]['value'])

# Model_time quantity carrying an explicit different time is currently noncontextual.
q=examples.quantum(ROOT/'adapter-review/quantum');q['observer']['time']={'value':'100','unit':'model_time'}
q['quantities'][0]['time']={'value':'0','unit':'model_time'}
r=execute('quantum-time-context',q)
save('quantum_explicit_time_context',status=r['execution']['status'],observer=r['observer'],protocol_context=q['quantities'][0]['time'],actual_protocol_clock=q['quantities'][0]['value']['clock'])

after_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'runtime').glob('*.py')}
save('freeze_unchanged',same=source_hashes==after_hashes)
