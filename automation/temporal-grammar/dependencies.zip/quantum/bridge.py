"""Quantum-domain mapping to the existing fourteen-field inquiry, not a dispatcher."""
import argparse
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
FIELDS = set('identity question system observer quantities operations constraints mechanism premises execution results contrast next_question provenance'.split())
REF = 'quantum.reference.evolve@0.1.1'
OPT = 'quantum.optical.replay@0.1.0'
GAP = 'quantum.redox.applicability@0.1.0'

class Rejected(ValueError): pass

def read(path):
    def unique(items):
        value = {}
        for k, v in items:
            if k in value: raise Rejected('Duplicate JSON key: '+k)
            value[k] = v
        return value
    return json.loads(Path(path).read_text(encoding='utf-8'), object_pairs_hook=unique,
                      parse_constant=lambda x: (_ for _ in ()).throw(Rejected('Nonfinite JSON')))

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while chunk := stream.read(2**20): h.update(chunk)
    return h.hexdigest()

def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False)+'\n', encoding='utf-8')

def local_sources():
    return {p.name: sha(p) for p in sorted(ROOT.glob('*.py'))} | {
        name: sha(ROOT/name) for name in ('capabilities.json', 'pins.json')}

def equal(actual, expected, label):
    # JSON numeric equality must not let True impersonate 1.
    if digest(actual) != digest(expected): raise Rejected('Incompatible '+label)

def validate(request):
    if not isinstance(request, dict) or set(request) != FIELDS:
        raise Rejected('Use the unchanged fourteen inquiry fields')
    identity = request['identity']
    if not isinstance(identity, dict) or not isinstance(identity.get('id'), str) or not identity['id']:
        raise Rejected('Inquiry identity is required')
    if type(identity.get('revision')) is not int or identity['revision'] < 1:
        raise Rejected('Positive integer inquiry revision required')
    if not isinstance(request['question'], dict) or not isinstance(request['question'].get('original'), str):
        raise Rejected('Original question is required')
    op = request['operations']
    if not isinstance(op, dict) or set(op) != {'capability_id', 'input'}:
        raise Rejected('Operation needs capability_id and native input')
    if op['capability_id'] not in (REF, OPT, GAP): raise Rejected('Unknown capability')
    capability = read(ROOT/'capabilities.json')['operations'][op['capability_id']]
    equal(request['quantities']['units'], capability['units'], 'units; no implicit conversion')
    equal(request['observer'], capability['observer'], 'preparation/time/calibration/uncertainty contract')
    equal(request['premises'], capability['transfer_premises'], 'transfer premises; request cannot self-admit a map')
    if request['results'] != {}: raise Rejected('Inbound results must be empty')
    if op['capability_id'] == GAP:
        equal(op['input'], {'target_extent_mM': 0.60, 'resource_model': 'reviewed companion synthetic resource inquiry'}, 'bounded resource scenario')
    elif not isinstance(op['input'], dict): raise Rejected('Native input must be an object')
    if op['capability_id'] == REF:
        clock = op['input'].get('clock')
        if not isinstance(clock, dict) or clock.get('units') != 'model_time': raise Rejected('A model_time clock object is required; physical seconds are not admitted')
    return capability

def check_dependency(kind, folder):
    if folder is None: raise Rejected('Configured '+kind+' dependency is unavailable')
    folder = Path(folder).resolve()
    spec = read(ROOT/'pins.json')[kind]
    for relative, expected in spec['files'].items():
        p = (folder/relative).resolve()
        if not p.is_relative_to(folder) or not p.is_file() or sha(p) != expected:
            raise Rejected('Changed or missing '+kind+' dependency: '+relative)
    # Prevent a newly added module from entering the trusted import tree.
    code_root = folder/spec['code_root']
    actual = {p.relative_to(folder).as_posix() for p in code_root.rglob('*.py')}
    expected = {k for k in spec['files'] if k.endswith('.py')}
    if actual != expected: raise Rejected('Unexpected '+kind+' Python source set')
    return folder

def environment(kind, folder):
    env = dict(os.environ)
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    env['PYTHONPATH'] = str(folder/'src') if kind == 'reference' else ''
    env['PYTHONNOUSERSITE'] = '1'
    return env

def command(kind, folder, action, native_input, artifact):
    start = [sys.executable, '-X', 'utf8', '-B']
    start += ['-m', 'observatory_quantum'] if kind == 'reference' else [str(folder/'run.py')]
    return start+[action, str(native_input)]+(['--output', str(artifact)] if action == 'run' else [str(artifact)])

def call(argv, kind, folder, cwd):
    p = subprocess.run(argv, cwd=cwd, env=environment(kind, folder), capture_output=True,
                       text=True, encoding='utf-8', timeout=60, shell=False)
    log = {'argv': argv, 'exit_code': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}
    if p.returncode: raise Rejected('Pinned engine failed: '+json.dumps(log))
    return log

def conclusion(id, kind, status, value, units, blockers, scope, dependencies):
    return {'id': id, 'result_kind': kind, 'status': status, 'value': value, 'units': units,
            'uncertainty': {'status': 'not_supplied', 'interval': None}, 'blocked_by': blockers,
            'scope': scope, 'depends_on': dependencies}

def execute(request, outdir, reference_root=None, optical_root=None, review_candidate=False):
    capability = validate(request)
    target = Path(outdir).resolve()
    if target.exists(): raise Rejected('Output directory must be fresh')
    target.parent.mkdir(parents=True, exist_ok=True)
    op = request['operations']['capability_id']
    record = deepcopy(request)
    record['identity']['producing_task'] = '01a09299-2945-7961-8d7c-56e8f6fb3783'
    record['identity']['adapter_version'] = '0.1.0'
    record['identity']['created_at'] = datetime.now(timezone.utc).isoformat()
    record['execution'] = {'adapter': 'quantum capability mapping 0.1.0', 'adapter_status': 'candidate; independent review pending',
                           'source_sha256': local_sources(), 'input_sha256': digest(request),
                           'engine_invoked': False, 'commands': [], 'artifacts': {},
                           'central_admission_granted': False}
    record['mechanism'] = capability['mechanism']
    record['system'] = {'boundary': capability['state_space']}
    record['quantities'] = {'units': capability['units']}
    record['constraints'] = capability['limits']
    record['provenance'] = {'request': request['provenance'], 'capability': capability,
                             'locality': 'local domain adapter; not a deployed central runner'}
    missing = [x['id'] for x in capability['transfer_premises']]
    with tempfile.TemporaryDirectory(prefix='quantum-adapter-', dir=target.parent) as staging_name:
        staging = Path(staging_name).resolve()
        if not staging.is_relative_to(target.parent): raise Rejected('Invalid staging path')
        write(staging/'request.json', request)
        if op == GAP:
            results = [conclusion('Q-REDOX-MAP', 'hypothesis_or_analogy', 'unresolved', None, None, missing,
                'No admitted quantum-to-redox observation map. This does not block the independent resource/geometry calculation.', missing)]
        elif op == OPT and not review_candidate:
            results = [conclusion('Q-OPTICAL-REVIEW', 'empirical_comparison', 'unresolved', None, None,
                ['P-OPTICAL-INDEPENDENT-REVIEW'], 'Candidate operation was not invoked; optical source analysis awaits independent acceptance.',
                ['P-OPTICAL-INDEPENDENT-REVIEW'])]
        else:
            kind = 'reference' if op == REF else 'optical'
            folder = check_dependency(kind, reference_root if kind == 'reference' else optical_root)
            write(staging/'native-input.json', request['operations']['input'])
            for action in ('run', 'verify'):
                argv = command(kind, folder, action, staging/'native-input.json', staging/'native-inquiry.json')
                record['execution']['commands'].append(call(argv, kind, folder, staging))
            check_dependency(kind, folder)
            native = read(staging/'native-inquiry.json')
            if set(native) != FIELDS: raise Rejected('Native inquiry violates fourteen-field boundary')
            record['execution'].update({'engine_invoked': True, 'dependency': kind,
                'native_receipt': native['execution']['receipt_sha256'], 'mode': 'accepted_reference_engine' if kind == 'reference' else 'candidate_review_only'})
            if kind == 'reference':
                state = native['results']
                results = [conclusion('Q-REFERENCE-YIELDS', state['result_kind'], state['status'],
                    [{'preparation': r['preparation'], 'final': r['final']} for r in state['runs']] if state['runs'] else None,
                    'dimensionless fractions of initial ensemble', state['blocked_by'], state['scope'], state['premise_dependencies'])]
                results.append(conclusion('Q-REFERENCE-CONTRAST', 'model_prediction', state['status'],
                    native['contrast'].get('yield_s_changes'), 'dimensionless', state['blocked_by'],
                    'Changed operation in the same reference model; no physical likelihood', state['premise_dependencies']))
                results.append(conclusion('Q-REDOX-MAP', 'hypothesis_or_analogy', 'unresolved', None, None, missing,
                    'Reference yield is not a redox flux or concentration.', missing))
            else:
                results = []
                for r in native['results']['conclusions']:
                    result = conclusion(r['id'], 'formal_under_premises' if r['kind'] == 'formal_under_premises' else 'empirical_comparison',
                        r['status'], r['value'], native['quantities'], r['blocked_by'], r['scope'], r['depends_on'])
                    result['producer_kind'] = r['kind']
                    result['central_admission'] = 'held_candidate'
                    results.append(result)
                # Copy observation features from the pinned producer in a fixed child command.
                # No fitting/likelihood semantics are added by this normalization.
                argv = [sys.executable, '-X', 'utf8', '-B', str(ROOT/'feature_worker.py'), str(folder),
                        str(staging/'native-inquiry.json'), str(staging/'features.json')]
                record['execution']['commands'].append(call(argv, kind, folder, staging))
                check_dependency(kind, folder)
                record['execution']['feature_scope'] = 'source-backed descriptors with unresolved uncertainty and experimental units'
            for filename in ('native-input.json', 'native-inquiry.json', 'features.json'):
                p = staging/filename
                if p.exists(): record['execution']['artifacts'][filename] = sha(p)
        record['results'] = {'conclusions': results, 'operation_admission': capability['admission']}
        record['premises'] = (native['premises'] if record['execution']['engine_invoked'] else []) + deepcopy(capability['transfer_premises'])
        record['next_question'] = {'origin': 'domain-authored', 'requests': capability['missing_contract']}
        record['execution']['receipt_sha256'] = digest(record)
        write(staging/'inquiry.json', record)
        staging.rename(target)
    return record

def verify(request, outdir, reference_root=None, optical_root=None):
    validate(request)
    folder = Path(outdir).resolve()
    record = read(folder/'inquiry.json')
    unsigned = deepcopy(record); receipt = unsigned['execution'].pop('receipt_sha256')
    artifact_names = set(record['execution']['artifacts'])
    if not artifact_names <= {'native-input.json', 'native-inquiry.json', 'features.json'}:
        raise Rejected('Unexpected artifact name')
    checks = {'fourteen_fields': set(record) == FIELDS, 'content_intact': digest(unsigned) == receipt,
              'input_current': digest(request) == record['execution']['input_sha256'],
              'request_artifact_current': digest(read(folder/'request.json')) == digest(request),
              'adapter_current': local_sources() == record['execution']['source_sha256'],
              'artifacts_current': all(sha(folder/name) == h for name, h in record['execution']['artifacts'].items())}
    if not all(checks.values()): return checks
    if record['execution']['engine_invoked']:
        kind = record['execution']['dependency']
        dependency = check_dependency(kind, reference_root if kind == 'reference' else optical_root)
        log = call(command(kind, dependency, 'verify', folder/'native-input.json', folder/'native-inquiry.json'), kind, dependency, folder)
        checks['native_current'] = log['exit_code'] == 0
    return checks

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('action', choices=['run', 'verify']); p.add_argument('request'); p.add_argument('--outdir', required=True)
    p.add_argument('--reference-root'); p.add_argument('--optical-root')
    p.add_argument('--review-candidate', action='store_true', help='Execute held optical producer solely for local review; never grants admission')
    args = p.parse_args()
    try:
        request = read(args.request)
        if args.action == 'run':
            r = execute(request, args.outdir, args.reference_root, args.optical_root, args.review_candidate)
            print(json.dumps({'status': 'written', 'receipt': r['execution']['receipt_sha256'], 'engine_invoked': r['execution']['engine_invoked']}))
            return 0
        checks = verify(request, args.outdir, args.reference_root, args.optical_root)
        print(json.dumps(checks)); return 0 if all(checks.values()) else 1
    except (ValueError, OSError, KeyError, TypeError, OverflowError, subprocess.SubprocessError) as error:
        print(json.dumps({'status': 'execution_error', 'error': str(error)})); return 2

if __name__ == '__main__': raise SystemExit(main())
