"""Fixed reviewed-producer feature invocation; invoked only by the domain adapter."""
import json
from pathlib import Path
import sys

folder, source, output = map(Path, sys.argv[1:])
sys.path.insert(0, str(folder))
from common import read, write
from features import packet
write(output, packet(read(source)))
