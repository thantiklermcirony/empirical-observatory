"""Declarative, local inquiry execution; no domain-specific dispatch or code eval.

The manifest supplies the scientific interpretation, assumptions and proof plan.
This kernel checks the supported arithmetic operations and their dependencies.
It does not verify cited theorems, infer mechanisms or establish empirical truth.
"""
import argparse
from copy import deepcopy
from datetime import datetime, timezone
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import re

from algebra import (Compiler, Expression, Rational, domain_report, interval,
                     merge_guards, valid_identifier, LOADED_SOURCE_SHA256)

VERSION = 'integrated-inquiry-0.2'
LOADED_CODE_HASHES = {
    'engine.py':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'algebra.py':LOADED_SOURCE_SHA256,
}


def check_loaded_sources():
    current = {name:hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()
               for name in LOADED_CODE_HASHES}
    if current != LOADED_CODE_HASHES:
        raise ValueError('Source changed since import; start a fresh process')


def number(value):
    """Bound exact input size before Fraction can expand an exponent."""
    if type(value) is int:
        if abs(value).bit_length() > 512:
            raise ValueError('Numeric input budget exceeded')
    elif isinstance(value, str):
        if len(value) > 160 or not re.fullmatch(
            r'[+-]?(?:[0-9]+(?:/[+-]?[0-9]+)?|[0-9]*\.[0-9]+)', value
        ):
            raise ValueError('Use a short exact integer, fraction or decimal')
    else:
        raise ValueError('Numeric inputs must be exact integers or strings')
    result = F(value)
    if max(abs(result.numerator).bit_length(), result.denominator.bit_length()) > 512:
        raise ValueError('Numeric input budget exceeded')
    return result


def names(value, label):
    if not isinstance(value, list) or any(not isinstance(x, str) for x in value):
        raise ValueError(label + ' must be a list of IDs')
    if len(set(value)) != len(value):
        raise ValueError(label + ' contains duplicate IDs')
    return value


def restrict_fixed_coordinates(ratio, boxes):
    """Restrict a rational form to singleton coordinates of the declared box."""
    fixed = {k:number(v[0]) for k,v in boxes.items() if number(v[0]) == number(v[1])}
    def substitute(polynomial):
        result = {}
        for monomial, coefficient in polynomial.items():
            remaining = []
            for name, exponent in monomial:
                if name in fixed:
                    coefficient *= fixed[name] ** exponent
                else:
                    remaining.append((name, exponent))
            key = tuple(remaining)
            result[key] = result.get(key, F(0)) + coefficient
        return result
    return Rational(substitute(ratio.n), substitute(ratio.d))


def execute(manifest, missing=()):
    check_loaded_sources()
    if not isinstance(manifest, dict) or manifest.get('version') != 1 or not isinstance(manifest.get('steps'), list):
        raise ValueError('Unsupported inquiry format')
    if len(manifest['steps']) > 100:
        raise ValueError('Step budget exceeded')
    symbols = manifest['symbols']
    if not isinstance(symbols, dict):
        raise ValueError('Symbols must be a map')
    if len(symbols) > 40:
        raise ValueError('Symbol budget exceeded')
    compiler = Compiler(symbols, manifest.get('functions', {}))
    symbols = compiler.symbols
    boxes = {k:v['interval'] for k,v in symbols.items()}
    for name, definition in symbols.items():
        if not valid_identifier(name):
            raise ValueError('Invalid symbol name')
        if len(definition['interval']) != 2 or number(definition['interval'][0]) > number(definition['interval'][1]):
            raise ValueError('Invalid declared interval')
    missing = tuple(missing)
    assumptions = deepcopy(manifest.get('premises', {}))
    for key in missing:
        if key not in assumptions:
            raise ValueError('Unknown removed premise: ' + key)
        assumptions[key]['status'] = 'missing'
    if any(x.get('status') not in ('assumed', 'missing', 'imported_theorem') for x in assumptions.values()):
        raise ValueError('Premise status must preserve declared versus established distinction')
    ids = [x['id'] for x in manifest['steps']]
    if len(ids) != len(set(ids)) or set(ids) & set(symbols) or any(not valid_identifier(x) for x in ids):
        raise ValueError('Invalid or colliding step IDs')
    completed = {}
    questions = {}
    reports = []
    for step in manifest['steps']:
        declared_premises = names(step.get('premises', []), 'Premises')
        declared_after = names(step.get('after', []), 'Dependencies')
        out = {'id':step['id'], 'operation':step['operation'], 'interpretation':step.get('interpretation'),
               'interpretation_origin':'authored_manifest', 'premises':list(declared_premises),
               'declared_premises':list(declared_premises), 'declared_after':list(declared_after),
               'after':list(declared_after), 'rule_refs':step.get('rule_refs', []),
               'rule_reference_status':'unverified_citation_only'}
        try:
            inferred = compiler.references(step['expression'], set(ids))
            if step['operation'] == 'identity':
                inferred |= compiler.references(step['equals'], set(ids))
        except (ValueError, SyntaxError, KeyError, TypeError, RecursionError) as error:
            out.update(status='invalid', error=str(error))
            completed[step['id']] = out
            reports.append(out)
            continue
        out['inferred_after'] = sorted(inferred)
        out['after'] = sorted(set(declared_after) | inferred)
        if any(k not in assumptions for k in out['premises']):
            raise ValueError('Unknown premise dependency')
        if any(k not in completed for k in out['after']):
            raise ValueError('Dependency must be an earlier step')
        out['premises'] = sorted(set(declared_premises).union(
            *(set(completed[k]['premises']) for k in out['after'])))
        missing_here = [k for k in out['premises'] if assumptions[k]['status'] == 'missing']
        failed = [k for k in out['after'] if completed[k]['status'] != 'verified']
        if missing_here or failed:
            out.update(status='blocked', missing_premises=missing_here, blocked_by=failed)
            for k in missing_here:
                questions[k] = {'premise':k, 'question':assumptions[k]['question'], 'origin':'missing_declared_obligation'}
            for k in failed:
                questions['step:'+k] = {'step':k, 'question':'Resolve the failed or unresolved dependency before using this consequence.', 'origin':'dependency_failure'}
        else:
            try:
                op = step['operation']
                if op not in ('differentiate', 'identity', 'evaluate', 'sign'):
                    raise ValueError('Unsupported operation')
                expression = compiler.compile(step['expression'])
                if op == 'differentiate':
                    wrt = step['with_respect_to']
                    if wrt not in symbols:
                        raise ValueError('Differentiation requires a declared independent variable')
                    expression = expression.derivative(wrt, symbols[wrt].get('units', {}))
                    out.update(result=expression.ratio.text(), units=expression.units)
                elif op == 'identity':
                    right = compiler.compile(step['equals'])
                    left_zero = not expression.ratio.n and not expression.units
                    right_zero = not right.ratio.n and not right.units
                    if expression.units != right.units and not (left_zero or right_zero):
                        raise ValueError('Dimension mismatch in identity')
                    global_equal = expression.ratio.equal(right.ratio)
                    out.update(algebraic_identity_before_fixed_bindings=global_equal,
                               left=expression.ratio.text(), right=right.ratio.text(),
                               equality_scope='throughout_declared_box_on_common_domain')
                    expression = Expression(expression.ratio,
                                            right.units if left_zero else expression.units,
                                            merge_guards(expression.guards, right.guards))
                    out['units'] = expression.units
                    # A global rational nonidentity is not a counterexample on
                    # a singleton coordinate or an unestablished common domain.
                    identity_domain = domain_report(expression, boxes)
                    if identity_domain['status'] == 'established_on_declared_box':
                        equal = restrict_fixed_coordinates(expression.ratio, boxes).equal(
                            restrict_fixed_coordinates(right.ratio, boxes))
                        out['equal'] = equal
                        if not equal:
                            out.update(status='refuted',
                                       refutation_scope='not_equal_throughout_declared_box')
                    else:
                        out['equal'] = None
                        out['status'] = 'unresolved'
                elif op == 'evaluate':
                    values = {k:number(v) for k,v in step['values'].items()}
                    if any(k not in symbols for k in values):
                        raise ValueError('Unknown value binding')
                    if any(not F(boxes[k][0]) <= v <= F(boxes[k][1]) for k,v in values.items()):
                        raise ValueError('Value outside declared interval')
                    # Evaluate every original guard before evaluating a simplified expression.
                    for guard in expression.guards:
                        if guard.value(values) == 0:
                            raise ValueError('Original expression undefined at supplied values')
                    evaluated = expression.ratio.value(values)
                    out.update(value=str(evaluated), units=expression.units,
                               value_bindings={k:str(v) for k,v in values.items()},
                               result_scope='supplied_point',
                               expression_box_domain=domain_report(expression, boxes))
                    # An evaluated result is a number with units, not the original
                    # symbolic function evaluated afresh at a later point.
                    expression = Expression(Rational.constant(evaluated), expression.units, [])
                else:
                    value = interval(expression.ratio, boxes)
                    out['enclosure'] = None if value is None else list(map(str, value))
                    relation = step['relation']
                    if relation not in ('positive', 'negative', 'nonnegative', 'nonpositive'):
                        raise ValueError('Unsupported sign relation')
                    accepted = value is not None and {'positive':value[0]>0, 'negative':value[1]<0,
                        'nonnegative':value[0]>=0, 'nonpositive':value[1]<=0}[relation]
                    out['requested_relation'] = relation
                    if not accepted:
                        out['status'] = 'unresolved'
                        questions['step:'+step['id']] = {'step':step['id'], 'question':step.get('question_on_unresolved', 'Tighten the parameter bounds or use a stronger certified analysis.'), 'origin':'conservative_interval_inconclusive'}
                domain = ({'status':'established_at_supplied_point', 'conditions':[]}
                          if op == 'evaluate' else domain_report(expression, boxes))
                out['domain'] = domain
                if op != 'evaluate' and domain['status'] != 'established_on_declared_box':
                    if out.get('status') != 'refuted':
                        out['status'] = 'unresolved'
                    questions['domain:'+step['id']] = {'step':step['id'], 'question':'Establish nonzero denominators: '+'; '.join(domain['conditions']), 'origin':'domain_obligation'}
                out.setdefault('status', 'verified')
                out['claim_type'] = 'checked_calculation_under_declared_premises'
                if out['status'] == 'verified':
                    compiler.results[step['id']] = expression
            except (ValueError, KeyError, SyntaxError, ZeroDivisionError, TypeError, RecursionError) as error:
                out.update(status='invalid', error=str(error))
        completed[step['id']] = out
        reports.append(out)
    check_loaded_sources()
    code_hashes = dict(LOADED_CODE_HASHES)
    input_bytes = json.dumps({'manifest':manifest, 'removed_premises':sorted(missing)},
                            sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode()
    input_hash = hashlib.sha256(input_bytes).hexdigest()
    fingerprint = hashlib.sha256(json.dumps({'input_sha256':input_hash, 'code':code_hashes},
                                            sort_keys=True).encode()).hexdigest()
    return {'engine':VERSION, 'inquiry':manifest['id'], 'question':manifest['question'],
        'execution_provenance':{'input_sha256':input_hash, 'code_sha256':code_hashes,
                                'fingerprint':fingerprint, 'removed_premises':sorted(missing)},
        'entities':manifest.get('entities', []), 'premises':assumptions,
        'steps':reports, 'next_questions':list(questions.values()),
        'status_counts':{s:sum(x['status']==s for x in reports) for s in ('verified','refuted','blocked','unresolved','invalid')},
        'limits':['Proof plan and scientific interpretations are authored inputs.',
                  'Step-reference dependencies are inferred; scientific premises remain authored obligations.',
                  'Rule references are unverified citations, not trusted theorem-handler bindings.',
                  'Imported theorems and scientific premises are not independently proved by this kernel.',
                  'Interval results concern the supplied parameter boxes; inconclusive does not mean false.',
                  'No empirical data, general language understanding, autonomous model invention or new scientific law is established.']}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('manifest', type=Path)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--missing', action='append', default=[])
    args = parser.parse_args()
    raw = args.manifest.read_bytes()
    if len(raw) > 200_000:
        raise ValueError('Manifest exceeds 200 KB')
    result = execute(json.loads(raw), args.missing)
    result.update(manifest_sha256=hashlib.sha256(raw).hexdigest(), executed_at=datetime.now(timezone.utc).isoformat())
    args.out.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'inquiry':result['inquiry'], **result['status_counts'], 'questions':len(result['next_questions'])}))


if __name__ == '__main__':
    main()
