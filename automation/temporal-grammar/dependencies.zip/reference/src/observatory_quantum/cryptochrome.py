"""Frozen publisher-workbook importer; summary curves are not replicate data."""
from datetime import datetime, timezone
import hashlib
import math
from pathlib import Path

from .inquiry import digest
from .model import AdmissionError

WORKBOOK_SHA256 = "61fd63ece3fab0034b08b8b125fa0164f76ed7106c08b91beb158980ce2850f3"
WORKBOOK_URL = "https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41586-021-03618-9/MediaObjects/41586_2021_3618_MOESM4_ESM.xlsx"
CAPTION_URL = "https://www.nature.com/articles/s41586-021-03618-9/figures/2"
SUPPLEMENT_URL = "https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41586-021-03618-9/MediaObjects/41586_2021_3618_MOESM1_ESM.pdf"
LAYOUT = {
    "Fig2ab": [(1, "ErCry4 WT pH7", 9), (4, "ErCry4 WT pH8", 9),
               (7, "ErCry4 WDF pH7", 10), (10, "AtCry1 WT pH7", 9)],
    "Fig2c": [(1, "ErCry4 10.4 s", 450), (4, "ErCry4 0.78 s", 450),
              (7, "GgCry4", 450), (10, "ClCry4", 450)],
    "Fig2d": [(1, "ErCry4", 8), (4, "GgCry4", 8), (7, "ClCry4", 8)],
}


def import_curves(path):
    from openpyxl import load_workbook
    from openpyxl.utils import get_column_letter
    source = Path(path)
    checksum = hashlib.sha256(source.read_bytes()).hexdigest()
    if checksum != WORKBOOK_SHA256:
        raise AdmissionError("Workbook differs from the frozen publisher source; re-audit layout/units before admission")
    series = []
    workbook = load_workbook(source, read_only=True, data_only=False)
    cached = load_workbook(source, read_only=True, data_only=True)
    try:
        if set(workbook.sheetnames) != set(LAYOUT):
            raise AdmissionError("Publisher workbook sheet layout changed")
        for name, columns in LAYOUT.items():
            rows = list(workbook[name].iter_rows())
            cached_rows = list(cached[name].iter_rows(values_only=True))
            for column, label, expected in columns:
                if rows[0][column-1].value != label:
                    raise AdmissionError(f"Unexpected label at {name}, column {column}")
                points = []
                for row_number, row in enumerate(rows[1:], start=1):
                    x_cell, y_cell = row[column-1:column+1]
                    x, y = cached_rows[row_number][column-1:column+1]
                    if x is None and y is None:
                        continue
                    if any(type(v) not in (int, float) or not math.isfinite(v) for v in (x, y)):
                        raise AdmissionError(f"Non-numeric or unpaired data at {name}!{x_cell.coordinate}")
                    points.append({"x": x, "y_raw": y,
                                   "source_cells": [x_cell.coordinate, y_cell.coordinate],
                                   "source_formulas": [c.value if c.data_type == "f" else None for c in (x_cell, y_cell)],
                                   "source_number_formats": [x_cell.number_format, y_cell.number_format]})
                if len(points) != expected:
                    raise AdmissionError(f"Unexpected point count in {name}: {label}")
                series.append({"id": f"{name}-col{column}", "label": label, "sheet": name,
                               "source_range": f"{get_column_letter(column)}2:{get_column_letter(column+1)}{len(rows)}",
                               "points": points, "point_count": len(points),
                               "x_quantity": {"Fig2ab": "magnetic field", "Fig2c": "probe wavelength", "Fig2d": "measurement delay"}[name],
                               "x_units": {"Fig2ab": "mT", "Fig2c": "nm", "Fig2d": "unresolved in workbook; do not assume seconds"}[name],
                               "y_quantity": "signed magnetic-field effect on optical absorbance",
                               "y_units": "publisher raw numeric scale; no unit conversion applied",
                               "y_scale_status": "unresolved workbook-to-figure display convention",
                               "replicate_ids": None, "standard_errors": None})
    finally:
        workbook.close()
        cached.close()
    context = {
        "source": SUPPLEMENT_URL, "location": "printed page 5 / PDF page 6, Figure 2 statistics",
        "experimental_unit": "Reported curves use one protein sample per condition; repeated measurements are not independently prepared proteins.",
        "ab_measurements_per_reported_curve": {"ErCry4 WT pH7": 50, "ErCry4 WT pH8": 20, "ErCry4 WDF pH7": 50, "AtCry1 WT pH7": 50},
        "c_measurements_per_reported_spectrum": {"ErCry4": 10, "GgCry4": 15, "ClCry4": 17},
        "d_measurements_per_point_reported_summary": {"ErCry4": "176 +/- 12", "GgCry4": "48 +/- 13", "ClCry4": "146 +/- 2"},
        "qualification": "Supplement reports additional independently prepared reproducibility checks; their individual records and pointwise uncertainty are absent from this workbook.",
    }
    return {"schema_version": "quantum-optical-summary/0.1", "created_at": datetime.now(timezone.utc).isoformat(),
            "provenance": {"source_url": WORKBOOK_URL, "source_sha256": checksum,
                           "caption_url": CAPTION_URL, "source_file_bytes": source.stat().st_size,
                           "parser_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                           "formula_policy": "Use frozen publisher cached numeric values; retain formulas without evaluating or recalculating them.",
                           "reuse": "Publisher data retain their own rights; no MIT relicensing inferred from public download."},
            "series": series, "series_sha256": digest(series), "sampling_context": context,
            "admission": {"raw_curve_reproduction": "admitted", "physical_unit_conversion": "unresolved",
                          "biological_independent_validation": "not_admitted", "binomial_shot_likelihood": "not_admitted",
                          "quantum_to_cell_flux": "not_admitted",
                          "missing": ["pointwise SEM or original measurements", "record-to-preparation IDs", "calibrated optical-to-species map", "verified workbook display scaling and delay units"],
                          "reason": "Signed optical summaries are not categorical quantum-shot counts or independent biological replicates."}}
