"""Emit the coordinator's 14-field inquiry envelope from executed inputs."""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform

from . import __version__
from .model import REQUIRED_PREMISES, validate
from .solver import NUMERICAL_TOLERANCE, simulate

SOURCE_URL = "https://qutip.readthedocs.io/en/stable/guide/dynamics/dynamics-master.html"
PREMISES = {
    "P-H": "The stated constant Hamiltonian defines the admitted S/T mixing and detuning.",
    "P-E": "A time-homogeneous Lindblad dephasing generator defines the environment in this model.",
    "P-R": "Irreversible S and T product sinks with the specified positive rates define the reaction readout.",
    "P-I": "The supplied Bloch vectors define the prepared ensemble, with initially empty product sinks.",
}


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     ensure_ascii=False, allow_nan=False).encode("utf-8")).hexdigest()


def source_hashes():
    return {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(Path(__file__).parent.glob("*.py"))}


def runtime(compare_qutip):
    dependencies = {name: importlib.metadata.version(name) for name in ("numpy", "scipy")}
    if compare_qutip:
        dependencies["qutip"] = importlib.metadata.version("qutip")
    return {"adapter": __version__, "python": platform.python_version(),
            "platform": platform.platform(), "dependencies": dependencies,
            "qutip_requested": bool(compare_qutip)}


def fingerprint(config, environment):
    return digest({"input": config, "source": source_hashes(), "runtime": environment})


def seal(record):
    record["execution"].pop("receipt_sha256", None)
    record["execution"]["receipt_sha256"] = digest(record)
    return record


def verify_receipt(config, record):
    """Detect stale input/code/runtime and changed receipt contents.

    A hash is not an authenticated signature or a proof of scientific truth.
    """
    config = validate(config)
    unsigned = deepcopy(record)
    receipt = unsigned["execution"].pop("receipt_sha256", None)
    environment = runtime(record["execution"]["runtime"]["qutip_requested"])
    return {"content_intact": receipt == digest(unsigned),
            "input_current": record["execution"]["input_sha256"] == digest(config),
            "code_current": record["provenance"]["code_sha256"] == source_hashes(),
            "runtime_current": record["execution"]["runtime"] == environment,
            "fingerprint_current": record["execution"]["run_fingerprint"] == fingerprint(config, environment)}


def execute(config, compare_qutip=False):
    config = validate(config)
    environment = runtime(compare_qutip)
    run_hash = fingerprint(config, environment)
    missing = [key for key in REQUIRED_PREMISES if config["premises"][key] != "assumed"]
    changed = {**config["model"], config["contrast"]["parameter"]: config["contrast"]["value"]}
    record = {
        "identity": {"id": f"quantum-reaction-{run_hash[:16]}", "version": __version__,
                     "producing_task": "01a09299-2945-7961-8d7c-56e8f6fb3783",
                     "created_at": datetime.now(timezone.utc).isoformat(),
                     "parent": "reduced-spin-yield-001"},
        "question": {"original": "Develop the quantum aspect of the Observatory into a serious scientific tool.",
                     "target": "How do preparation, coherent mixing, environment and reaction operations change product yields?",
                     "scope": "A dimensionless four-level open-system reference mechanism",
                     "user": "research developer", "output": "trajectories, operation contrast, checks and transfer obligations"},
        "system": {"entities": ["S", "T", "product_S", "product_T", "dephasing environment"],
                   "state_space": "complex Hermitian positive 4x4 density matrix",
                   "boundary": "prepared pair and irreversible product sinks; environment is phenomenological",
                   "coupling": "dephasing, coherent mixing and recombination",
                   "restriction": "one effective T level; no nuclear spins, three-component triplet manifold, hyperfine or spatial structure"},
        "observer": {"preparation": config["preparations"], "clock": config["clock"],
                     "measurements": ["S/T populations", "survival", "product populations"],
                     "observation_map": "expectation values of the specified basis projectors",
                     "backaction": "no intermediate measurement; all reaction outcomes retained",
                     "unit": "one constructed prepared ensemble per condition; no empirical replicates",
                     "noise": "none specified; this is a deterministic ensemble prediction",
                     "memory": "full density trajectory retained internally; population and coherence readouts exported"},
        "quantities": {"parameters": config["model"], "parameter_units": "inverse model_time with hbar=1",
                       "time": config["clock"], "coherence_st": "[real, imaginary] of unnormalized survival-block rho_ST",
                       "populations_and_yields": "dimensionless fractions of initial prepared ensemble",
                       "yield_domain": [0, 1], "physical_flux": "not defined without independent dimensional and observation calibration"},
        "operations": {"generator": "simultaneous time-homogeneous dynamics, not sequential split operations",
                       "propagation": "rho(t)=exp(t L) rho(0), vectorized column-major",
                       "composition": "the specified semigroup composes by elapsed model_time",
                       "contrast": config["contrast"], "conditioning": "none; trace-preserving full state includes all sinks"},
        "constraints": {"full_trace": 1, "positive_semidefinite": True,
                        "mass_balance": "survival + yield_s + yield_t = 1",
                        "product_yields": "nondecreasing; survival nonincreasing",
                        "input_domain": "strictly admitted by quantum-reaction/0.1",
                        "numerical_tolerance": NUMERICAL_TOLERANCE},
        "mechanism": {"equation": "d rho/dt = -i[H,rho] + sum(C rho C† - {C†C,rho}/2)",
                      "hamiltonian": "H_ST=(omega sigma_x + detuning sigma_z)/2; zero on sinks",
                      "collapse_operators": ["sqrt(gamma/2) diag(1,-1,0,0)", "sqrt(k_s)|product_S><S|", "sqrt(k_t)|product_T><T|"],
                      "calibration": "authored dimensionless fixture, not fitted biological parameters",
                      "alternatives": ["changed dephasing", "changed mixing or detuning", "unequal reaction rates", "missing preparation premise"],
                      "source": SOURCE_URL},
        "premises": [{"id": key, "statement": statement, "status": config["premises"][key],
                      "source": "explicit input model assumption", "scope": "reference mechanism only"}
                     for key, statement in PREMISES.items()] + [
                         {"id": "P-BIO", "status": "missing", "statement": "Independent evidence maps this state, clock, rates and measurement to a named biological system.", "scope": "physical and biological transfer"}],
        "execution": {"solver": "SciPy matrix exponential with semigroup subdivision check",
                      "independent_backend": "QuTiP adaptive mesolve" if compare_qutip else "not requested",
                      "runtime": environment, "input_sha256": digest(config), "run_fingerprint": run_hash,
                      "input": config, "premise_dependencies": list(REQUIRED_PREMISES),
                      "command_template": "python -m observatory_quantum run INPUT.json --output INQUIRY.json" + (" --qutip" if compare_qutip else ""),
                      "tolerances": {"acceptance": NUMERICAL_TOLERANCE, "qutip_rtol": 1e-10, "qutip_atol": 1e-12},
                      "numerical_check_scope": "sampled states and independent integrations; neither formal proof nor empirical validation"},
        "results": {"result_kind": "model_prediction", "status": "unresolved" if missing else "established_in_scope",
                    "scope": "specified reference model only", "premise_dependencies": list(REQUIRED_PREMISES),
                    "blocked_by": missing, "runs": [],
                    "biological_transfer": {"result_kind": "hypothesis_or_analogy", "status": "unresolved",
                                            "blocked_by": ["P-BIO"], "physical_flux_admitted": False}},
        "contrast": {"changed_operation": config["contrast"], "model": changed, "runs": [],
                     "premise_failure": "Removing any required model premise blocks its base and intervention descendants; missing P-BIO blocks only biological transfer."},
        "next_question": {"origin": "authored", "question": "Which independently supported preparation, spin Hamiltonian, environment, reaction channels and optical calibration would justify a biological instance?"},
        "provenance": {"evidence": "constructed model calculation; no empirical data",
                       "code_sha256": source_hashes(), "model_sha256": digest(config["model"]),
                       "citations": [{"url": SOURCE_URL, "location": "Lindblad master equation and mesolve sections", "scope": "standard equation form; this reduced mechanism is authored"}],
                       "theorem_use": "No source theorem selects or derives this Hamiltonian or the quantum state space. A checked scalar conditioning identity does not certify a general composition theorem.",
                       "revision": "isolated quantum development package; not deployed",
                       "license": "new adapter source supplied for the user's MIT Observatory project; external data licensing is separate"},
    }
    if not missing:
        record["results"]["runs"] = [simulate(config["model"], state, config["clock"], compare_qutip) for state in config["preparations"]]
        record["contrast"]["runs"] = [simulate(changed, state, config["clock"], compare_qutip) for state in config["preparations"]]
        record["contrast"]["yield_s_changes"] = [
            {"preparation_id": base["preparation"]["id"], "base": base["final"]["yield_s"],
             "changed": contrast["final"]["yield_s"], "difference": contrast["final"]["yield_s"] - base["final"]["yield_s"]}
            for base, contrast in zip(record["results"]["runs"], record["contrast"]["runs"])]
    return seal(record)
