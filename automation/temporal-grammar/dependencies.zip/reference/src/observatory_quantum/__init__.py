"""A domain adapter, not a universal inference engine."""

__version__ = "0.1.1"
