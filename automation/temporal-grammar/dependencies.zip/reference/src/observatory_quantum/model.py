"""Strict admission for the dimensionless four-level reference mechanism."""
from copy import deepcopy
import json
import math
import re

PARAMETERS = {"omega", "detuning", "gamma", "k_s", "k_t"}
REQUIRED_PREMISES = ("P-H", "P-E", "P-R", "P-I")


class AdmissionError(ValueError):
    """Input is outside this adapter's declared domain."""


def exact_keys(value, keys, location):
    if not isinstance(value, dict) or set(value) != set(keys):
        raise AdmissionError(f"{location} must contain exactly {sorted(keys)}")


def real(value, location, minimum=-1e4, maximum=1e4):
    # isfinite converts integers to double; huge valid JSON integers can overflow.
    # Bound arbitrary-precision integers before any conversion.
    if type(value) not in (int, float) or (type(value) is float and not math.isfinite(value)):
        raise AdmissionError(f"{location} must be a finite real number (not a boolean)")
    if not minimum <= value <= maximum:
        raise AdmissionError(f"{location} must lie in [{minimum}, {maximum}]")
    return float(value)


def validate_model(model):
    exact_keys(model, PARAMETERS, "model")
    for name, value in model.items():
        low = 1e-6 if name in ("k_s", "k_t") else 0 if name == "gamma" else -1e4
        real(value, f"model.{name}", low)


def validate(config):
    exact_keys(config, {"schema_version", "model", "clock", "preparations", "contrast", "premises"}, "input")
    if config["schema_version"] != "quantum-reaction/0.1":
        raise AdmissionError("Unsupported input schema_version")
    validate_model(config["model"])
    clock = config["clock"]
    exact_keys(clock, {"units", "end", "points"}, "clock")
    if clock["units"] != "model_time":
        raise AdmissionError("v0.1 admits dimensionless model_time only; a physical clock needs calibration")
    real(clock["end"], "clock.end", 1e-6, 1e4)
    if type(clock["points"]) is not int or not 2 <= clock["points"] <= 2001:
        raise AdmissionError("clock.points must be an integer from 2 to 2001")
    preparations = config["preparations"]
    if not isinstance(preparations, list) or not 1 <= len(preparations) <= 8:
        raise AdmissionError("preparations must contain 1 to 8 states")
    ids = set()
    for state in preparations:
        exact_keys(state, {"id", "bloch"}, "preparation")
        sid = state["id"]
        if not isinstance(sid, str) or re.fullmatch(r"[a-zA-Z0-9_-]{1,48}", sid) is None or sid in ids:
            raise AdmissionError("Preparation IDs must be unique, short alphanumeric identifiers")
        ids.add(sid)
        b = state["bloch"]
        if not isinstance(b, list) or len(b) != 3:
            raise AdmissionError("bloch must be [x, y, z]")
        for v in b:
            real(v, "bloch coordinate", -1, 1)
        if math.fsum(v*v for v in b) > 1 + 1e-14:
            raise AdmissionError("Initial Bloch vector lies outside the positive-state ball")
    exact_keys(config["premises"], REQUIRED_PREMISES, "premises")
    if any(type(s) is not str or s not in {"assumed", "missing", "rejected"} for s in config["premises"].values()):
        raise AdmissionError("Reference premises can be assumed, missing or rejected; empirical support needs a separate evidence record")
    contrast = config["contrast"]
    exact_keys(contrast, {"parameter", "value"}, "contrast")
    if type(contrast["parameter"]) is not str or contrast["parameter"] not in PARAMETERS:
        raise AdmissionError("contrast.parameter is not an admitted model parameter")
    changed = {**config["model"], contrast["parameter"]: contrast["value"]}
    validate_model(changed)
    if changed == config["model"]:
        raise AdmissionError("Contrast must change an operation parameter")
    for model in (config["model"], changed):
        if clock["end"] * sum(abs(v) for v in model.values()) > 1e6:
            raise AdmissionError("Model duration exceeds the v0.1 compute budget")
    return deepcopy(config)


def load_input(path):
    def unique_pairs(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise AdmissionError(f"Duplicate JSON key: {key}")
            result[key] = value
        return result
    with open(path, encoding="utf-8") as handle:
        return validate(json.load(handle, object_pairs_hook=unique_pairs))
