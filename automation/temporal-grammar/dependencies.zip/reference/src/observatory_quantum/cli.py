import argparse
import json
from pathlib import Path
import sys

from .inquiry import execute, verify_receipt
from .model import AdmissionError, load_input
from .solver import NumericalFailure


def write_json(path, value):
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def main(argv=None):
    parser = argparse.ArgumentParser(description="Run or verify a premise-aware quantum reaction inquiry")
    commands = parser.add_subparsers(dest="command", required=True)
    run = commands.add_parser("run")
    run.add_argument("input")
    run.add_argument("--output", required=True)
    run.add_argument("--qutip", action="store_true", help="Require an independent QuTiP trajectory comparison")
    verify = commands.add_parser("verify")
    verify.add_argument("input")
    verify.add_argument("receipt")
    curves = commands.add_parser("import-curves")
    curves.add_argument("workbook")
    curves.add_argument("--output", required=True)
    arguments = parser.parse_args(argv)
    try:
        if arguments.command == "import-curves":
            from .cryptochrome import import_curves
            result = import_curves(arguments.workbook)
            write_json(arguments.output, result)
            print(json.dumps({"status": "imported", "series": len(result["series"]), "output": arguments.output}))
        elif arguments.command == "verify":
            record = json.loads(Path(arguments.receipt).read_text(encoding="utf-8"))
            checks = verify_receipt(load_input(arguments.input), record)
            print(json.dumps(checks, indent=2))
            return 0 if all(checks.values()) else 1
        else:
            result = execute(load_input(arguments.input), compare_qutip=arguments.qutip)
            write_json(arguments.output, result)
            print(json.dumps({"status": result["results"]["status"], "output": arguments.output,
                              "biological_transfer": result["results"]["biological_transfer"]["status"]}))
        return 0
    except (AdmissionError, NumericalFailure, ImportError, OSError, ValueError, KeyError, TypeError, OverflowError) as error:
        category = ("numerical_failure" if isinstance(error, NumericalFailure) else
                    "dependency_missing" if isinstance(error, ImportError) else
                    "io_error" if isinstance(error, OSError) else "invalid_input")
        print(json.dumps({"status": "execution_error", "error_category": category,
                          "error_type": type(error).__name__, "message": str(error)}), file=sys.stderr)
        return 2
