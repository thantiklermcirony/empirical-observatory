"""CPTP four-level Lindblad dynamics with two irreversible reaction sinks.

Basis: |S>, |T>, |product_S>, |product_T>. This is a reduced reference
mechanism: the single T state is not the full physical triplet manifold.
"""
import numpy as np
from scipy.linalg import expm

NUMERICAL_TOLERANCE = 1e-8


class NumericalFailure(RuntimeError):
    pass


def operators(model):
    omega, delta = model["omega"], model["detuning"]
    h = np.zeros((4, 4), dtype=complex)
    h[:2, :2] = [[delta / 2, omega / 2], [omega / 2, -delta / 2]]
    dephase = np.sqrt(model["gamma"] / 2) * np.diag([1, -1, 0, 0]).astype(complex)
    singlet = np.zeros_like(h)
    triplet = np.zeros_like(h)
    singlet[2, 0] = np.sqrt(model["k_s"])
    triplet[3, 1] = np.sqrt(model["k_t"])
    return h, [dephase, singlet, triplet]


def initial_density(bloch):
    x, y, z = bloch
    rho = np.zeros((4, 4), dtype=complex)
    rho[:2, :2] = np.array([[1+z, x-1j*y], [x+1j*y, 1-z]]) / 2
    return rho


def liouvillian(h, collapse):
    """Column-major vectorization; no normalization or positivity repair."""
    ident = np.eye(len(h))
    generator = -1j * (np.kron(ident, h) - np.kron(h.T, ident))
    for c in collapse:
        cc = c.conj().T @ c
        generator += np.kron(c.conj(), c) - (np.kron(ident, cc) + np.kron(cc.T, ident)) / 2
    return generator


def trajectory(model, bloch, end, points, subdivisions=1):
    h, collapse = operators(model)
    generator = liouvillian(h, collapse)
    step = expm(generator * end / ((points - 1) * subdivisions))
    state = initial_density(bloch).reshape(-1, order="F")
    result = [state.reshape(4, 4, order="F").copy()]
    for _ in range(points - 1):
        for _ in range(subdivisions):
            state = step @ state
        result.append(state.reshape(4, 4, order="F").copy())
    return np.asarray(result)


def qutip_trajectory(model, bloch, end, points):
    """Independent operator construction and adaptive ODE integration.

    It shares the specified mechanism and underlying numerical libraries;
    agreement is implementation evidence, never biological validation.
    """
    import qutip as qt
    s, t, ps, pt = [qt.basis(4, index) for index in range(4)]
    h = model["omega"] / 2 * (s*t.dag() + t*s.dag())
    h += model["detuning"] / 2 * (s*s.dag() - t*t.dag())
    collapse = [np.sqrt(model["gamma"]/2) * (s*s.dag() - t*t.dag()),
                np.sqrt(model["k_s"]) * ps*s.dag(),
                np.sqrt(model["k_t"]) * pt*t.dag()]
    x, y, z = bloch
    rho = ((1+z)*s*s.dag() + (1-z)*t*t.dag()
           + (x-1j*y)*s*t.dag() + (x+1j*y)*t*s.dag()) / 2
    solved = qt.mesolve(h, rho, np.linspace(0, end, points), collapse,
                        options={"atol": 1e-12, "rtol": 1e-10, "method": "dop853",
                                 "nsteps": 100000, "store_states": True, "normalize_output": False})
    return np.asarray([state.full() for state in solved.states])


def diagnostics(states):
    adjoint = states.conj().transpose(0, 2, 1)
    diagonal = np.diagonal(states, axis1=1, axis2=2)
    diagnostics = {
        "maximum_trace_error": float(np.max(np.abs(np.trace(states, axis1=1, axis2=2)-1))),
        "maximum_hermiticity_error": float(np.max(np.abs(states-adjoint))),
        "minimum_eigenvalue": float(np.min(np.linalg.eigvalsh((states+adjoint)/2))),
        "maximum_product_decrease": float(max(0, -np.min(np.diff(diagonal[:, 2:].real, axis=0)))),
        "maximum_survival_increase": float(max(0, np.max(np.diff(diagonal[:, :2].real.sum(axis=1))))),
    }
    if (not np.isfinite(states).all()
        or diagnostics["maximum_trace_error"] > NUMERICAL_TOLERANCE
        or diagnostics["maximum_hermiticity_error"] > NUMERICAL_TOLERANCE
        or diagnostics["minimum_eigenvalue"] < -NUMERICAL_TOLERANCE
        or diagnostics["maximum_product_decrease"] > NUMERICAL_TOLERANCE
        or diagnostics["maximum_survival_increase"] > NUMERICAL_TOLERANCE):
        raise NumericalFailure(f"Numerical physical-invariant check failed: {diagnostics}")
    return diagnostics


def simulate(model, preparation, clock, compare_qutip=False):
    args = (model, preparation["bloch"], clock["end"], clock["points"])
    states = trajectory(*args)
    checks = diagnostics(states)
    refined = trajectory(*args, subdivisions=2)
    checks["semigroup_subdivision_max_error"] = float(np.max(np.abs(states-refined)))
    if checks["semigroup_subdivision_max_error"] > NUMERICAL_TOLERANCE:
        raise NumericalFailure("Semigroup subdivision check exceeded tolerance")
    checks["qutip"] = {"status": "not_run"}
    if compare_qutip:
        independent = qutip_trajectory(*args)
        qchecks = diagnostics(independent)
        difference = float(np.max(np.abs(states-independent)))
        checks["qutip"] = {"status": "passed", "maximum_density_difference": difference,
                           "physical_invariants": qchecks}
        if difference > NUMERICAL_TOLERANCE:
            raise NumericalFailure(f"QuTiP comparison exceeded tolerance: {difference}")
    diagonal = np.diagonal(states, axis1=1, axis2=2).real
    rows = []
    for time, state, population in zip(np.linspace(0, clock["end"], clock["points"]), states, diagonal):
        rows.append({"time": float(time), "survival": float(population[:2].sum()),
                     "population_s": float(population[0]), "population_t": float(population[1]),
                     "coherence_st": [float(state[0, 1].real), float(state[0, 1].imag)],
                     "yield_s": float(population[2]), "yield_t": float(population[3])})
    return {"preparation": preparation, "model": model, "trajectory": rows, "checks": checks,
            "final": rows[-1], "yield_units": "fraction of initial prepared ensemble",
            "remaining_possible_yield_increment_bound": rows[-1]["survival"],
            "uncertainty": "Numerical verification only. No empirical confidence interval."}
