---
title: "Finite rescue windows and supply-limited redox commitment in NRF2-active cancer: fold geometry and a discriminating experimental test"
author: "Daniel John Murray"
date: "7 September 2026"
---

Independent researcher. Hypothesis and theory paper with secondary analysis of published data.

# Abstract

NRF2-active cancers can maintain high antioxidant abundance while losing the capacity to survive redox injury after a specified rescue operation. Published studies demonstrate timed rescue, effects of cystine withdrawal, intervention-dependent survival, and spatial ferroptotic propagation. These findings motivate a local saddle-node hypothesis; they do not identify its parameters or establish durable clonogenic rescue. For the deterministic normal form $\dot x=-M(a+x^2)$ at constant calibrated depth $a>0$, passage between fixed sections $x_i=A>0$ and $x_f=-B<0$ is an arctangent interval divided by $M\sqrt a$. Its effective depth-duration exponent lies strictly between $1/2$ and $1$, approaching those limits at shallow and deep forcing within the model. A monotone crossover follows for symmetric sections; asymmetric sections can produce a nonmonotone exponent profile. This constrained finite-section family is the principal prediction. Time-varying depth requires a coordinate-derivative correction, and interrupted treatment must retain recovery dynamics. A five-depth by seven-duration starting design, adjusted by pilot calibration, combines target engagement, a fixed rescue operation and 7--14-day clonogenic follow-up. A stated observation model links deterministic passage to population survival. Fold, cumulative-exposure, fixed-power and smooth-hazard models are compared on held-out forcing depths using the same response likelihood. Reanalysis reproduces the archived Co wave fit, $5.48\,\mu\mathrm{m}\,\mathrm{min}^{-1}$, and a $168\,\mu\mathrm m$ median transmission gap. An audit also corrects a prior misinterpretation of the stacked components in the Wiernicki rescue plot. No existing dataset considered here jointly identifies calibrated depth, finite sections, rescue and durable fate. Failure of the prespecified model within a demonstrably tested regime would reject that operational fold hypothesis.

**Keywords:** NRF2; KEAP1; glutathione; GPX4; ferroptosis; rescue window; saddle-node bifurcation; clonogenic survival.

**Claim discipline.** Published experiments establish timed and state-dependent rescue in their stated systems and endpoints. The finite-section fold law remains a quantitative hypothesis for a specified rescue operation and biological regime. It is not a universal law of ferroptosis or a clinical treatment recommendation.

# 1. Introduction: abundance is not recoverability

A calibrated model of glutathione homeostasis separates oxidative collapse from reductive fade under finite NADPH-linked supply in G6PD deficiency and NRF2-active lung cancer [1]. A complementary bounded-adaptive analysis identifies conditions under which separated repair and toxicity thresholds generate hormesis [2]. The present paper addresses a distinct dynamical question: when has a redox-injured cancer cell lost a state from which a specified intervention can restore durable survival?

KEAP1 loss and NRF2 activation can increase glutathione synthesis and recycling, cystine import through SLC7A11/xCT, detoxification and metabolic support [3--9]. These adaptations explain resistance tendencies but do not define recoverability. High antioxidant abundance can coexist with little reserve when substrate, energy or regeneration flux approaches a limiting capacity. Conversely, lipid oxidation may be detectable while rescue remains possible. The relative importance of these mechanisms is cell-state and pathway dependent.

Ferroptosis was defined as an iron-dependent, non-apoptotic death process and subsequently linked to GPX4 activity [10,11]. Biochemical injury, temporary growth arrest, loss of reproductive survival and terminal membrane failure are different observations. A viability assay during drug exposure cannot by itself determine whether washout or another rescue operation would restore long-term clonogenic survival.

This paper has three purposes. First, it assembles experiments separating injury from the loss of rescue under a stated endpoint. Second, it derives and qualifies the finite-passage mathematics, preserving a constrained exponent family while correcting claims of universal monotonicity and unrestricted phase accumulation. Third, it specifies an experiment capable of rejecting the operational model without requiring a new molecular construct when an established, adequately calibrated system is available.

# 2. Experimental evidence for finite rescue windows

## 2.1 Synchronized GPX4 loss separates injury from subsequent death

Wiernicki et al. used inducible GPX4 knockdown while ferrostatin-1 initially maintained viability [12]. Removing ferrostatin-1 synchronized ferroptosis. Re-addition at 1 h suppressed subsequent progression, whereas addition at 2 h or later failed to provide complete rescue. Lipid and cytosolic oxidation preceded terminal membrane failure. The published Fig. 2f separates death already present when ferrostatin was re-added from additional death by the 8 h readout. These are stacked components, not two independent final-endpoint treatment arms.

The experiment demonstrates a finite window for preventing further acute death in that system. It does not directly establish 7--14-day clonogenic restoration, and re-addition does not reverse death that has already occurred. The paper's reported distinction between 1 h and 2 h is retained with this endpoint restriction. Operational commitment depends on the initial state, rescue intervention, exposure history and fate endpoint; it is not automatically first oxidation, loss of GPX4 activity or membrane rupture.

## 2.2 The microenvironment moves the boundary

Hefetz et al. studied RSL3 pulse-washout and delayed rescue in A375, BeWo and U87 cells [13]. Their experiments compared direct ferrostatin rescue with macrophage-mediated protection and included contact-separation controls. Macrophage protection was confined to an early interval, approximately 2--3 h under the tested conditions, and depended on direct contact. Cell lines exhibited different rescue curves. The measured protection supports a state- and environment-dependent rescue boundary at the study's acute endpoint, rather than a universal time constant or an established clonogenic boundary.

## 2.3 Supply withdrawal establishes susceptibility, not a repletion-window law

Poursaitidis et al. showed that cystine deprivation selectively induced ferroptotic death in susceptible oncogenic states [14]. Protective interventions included pathway inhibition and antioxidant/ferroptosis-directed agents. Their experiments also distinguish cystine support from glutathione abundance: inhibiting glutathione synthesis with BSO depleted the glutathione pool without reproducing the loss of viability caused by cystine withdrawal under the compared conditions, while combined perturbations could act synergistically. Cystine dependence therefore cannot be reduced to a universal glutathione-pool threshold.

This study supports an upstream supply-axis challenge and state-dependent susceptibility. Its published main-figure experiments do not establish the timed cystine-repletion rescue curve previously attributed to it; that specific evidence claim is withdrawn. A deprivation-duration-by-repletion experiment remains a proposed test, and would require its own defined rescue operation, calibrated forcing and durable endpoint.

## 2.4 Rescue route and endpoint matter

Qiu et al. investigated cell-state-dependent interactions between ferroptotic stress, apoptotic machinery and BH3-mimetics [15]. Rescue and subsequent fate depended on the cell line, pretreatment and intervention. A trajectory that is not rescued by drug washout may still be protected by another operation. Pharmacological antioxidant effects can also complicate the interpretation of a nominally pathway-specific rescue. Acute membrane protection and sustained reproductive survival must therefore be measured separately. Throughout this paper, commitment is indexed by a prespecified rescue operation $R$ and endpoint $Y$.

## 2.5 Local tipping can become spatial

Co et al. demonstrated cystine-uptake suppression, redox feedback and bistable behaviour in populations supporting millimetre-scale ferroptotic trigger waves [16]. Under the reported erastin conditions, propagation speed varied from approximately $3.08$ to $5.38\,\mu\mathrm m\,\mathrm{min}^{-1}$; the initiating trigger and the primed medium therefore play distinct roles. Their principal propagation example travelled at approximately $5.48\,\mu\mathrm m\,\mathrm{min}^{-1}$, with three experiments reporting $5.52\pm0.09\,\mu\mathrm m\,\mathrm{min}^{-1}$. These are protocol-specific wave measurements. Roeck et al. found a different setting in which ferroptotic spread depended on plasma-membrane contacts [17]. A single coupling mechanism must not be imposed on both systems. At tissue scale, initiation probability, front speed and transmission range may be more appropriate outputs than isolated-cell passage time.

## 2.6 Ordered NRF2 adaptation separates normal and tumour tissue

Samarin et al. exploited differential NRF2-mediated protection in small-cell lung cancer models [18]. NRF2-pathway activation protected non-cancerous compartments against TXNRD1-targeting treatment and enabled dose escalation in vivo, whereas the tested SCLC cells were poorly protected. This demonstrates context-dependent adaptive protection and motivates explicit treatment history in a redox model. It does not establish that every NRF2-active tumour behaves like SCLC: deficient inducibility in those SCLC models and constitutive NRF2 activation in other cancers must remain distinct biological cases.

**Table 1. What the evidence establishes.**

| Claim | Evidence level | Strict conclusion |
|---|---|---|
| Injury can precede loss of rescue | Direct in named assays | Injury markers can precede failure of a specified intervention to prevent the measured fate. |
| Finite rescue windows occur | Direct in named assays | Delayed intervention can lose efficacy before terminal execution. |
| State, intervention and environment matter | Direct | Rescue curves depend on the system and operation. |
| Cystine/GSH support controls susceptibility | Direct/strong | Supply perturbation moves susceptible systems toward ferroptotic failure. |
| Bistable populations can support trigger waves | Direct in the Co system | Spatial coupling and local feedback can sustain a front. |
| These systems share one local fold | Compatible hypothesis | The normal form has not been empirically identified across them. |
| The finite-section exponent family predicts durable rescue | Open | Requires calibrated depth-duration-rescue data and rival-model comparison. |

![Figure 1. Evidence architecture: assay-specific rescue, supply perturbation, route dependence and spatial propagation motivate a local model but do not establish its scaling law.](assets/figure1_evidence.png)

# 3. Secondary analysis and audit of available datasets

## 3.1 Reproducible descriptive analyses

The secondary analyses concern public source data accompanying Wiernicki et al. [12] and Co et al. [16]. They quantify the motivating phenomena rather than estimate the proposed depth-duration law. The Co front-distance fit uses ordinary least squares with an intercept. The archived table contains 17 time-distance observations from the displayed trajectory; these timepoints are not 17 independent biological replicates. Re-execution gives $5.477717\,\mu\mathrm m\,\mathrm{min}^{-1}$ and $R^2=0.993349$. The fitted intercept is $-164.225\,\mu\mathrm m$; it is a regression intercept and is not interpreted as a negative physical propagation distance.

Binary continuation across 38 cell-free gaps was fitted using a logistic model,

$$P(\text{continuation}\mid g)=\operatorname{logit}^{-1}(\beta_0+\beta_1g),\qquad g_{50}=-\beta_0/\beta_1.$$

Re-execution of the archived derived gap table gives $g_{50}=168.169\,\mu\mathrm m$. A 1,000-resample row bootstrap, seed 20260722, gives a percentile interval of $148.982$--$191.253\,\mu\mathrm m$, rounded to $149$--$191\,\mu\mathrm m$. All 1,000 resamples produced estimates in this execution. This interval is conditional on treating the sampled rows as independent sampling units. If wells share batch-level dependence, a batch-respecting bootstrap or hierarchical model is required; the row interval alone does not establish between-batch precision. The logistic inflection is a descriptive transmission scale, not a mechanistically identified diffusion length or a universal maximum gap.

## 3.2 Correction to the delayed-rescue replot

The previous analysis script read two three-column groups in the Wiernicki Fig. 2f workbook and labelled them as separate endpoint curves. Comparison with the original stacked-bar figure shows that this interpretation is incorrect. The grey group represents death when ferrostatin-1 was re-added; the orange group represents additional death accumulated by 8 h. Total endpoint death is the sum of the matched components. The publisher workbook labels the second group as the change after ferrostatin addition. At re-addition times 0, 1, 2, 3, 4 and 5 h, corrected mean total death by 8 h is 9.33%, 21.90%, 82.35%, 96.34%, 96.68% and 97.99%, respectively (three reported replicate columns). Plotting only the second group as final death creates an artificial decline at late re-addition times. Corrected plots distinguish the two components and their total, and do not label the initial-death group as an untreated endpoint control. The qualitative loss of complete rescue between 1 h and 2 h remains supported by the original experiment; the mislabelled secondary curve is withdrawn.

## 3.3 Negative audit of an attractive exponent

A published RSL3 concentration-by-time CCK-8 matrix had appeared to yield an exponent near $1/2$ at one selected viability threshold [19]. The earlier audit reported threshold-sensitive estimates. Continuous-exposure metabolic viability does not identify irreversible commitment, and nominal RSL3 concentration is not calibrated fold depth. That apparent agreement is therefore not used as validation. The rejected calculation is not treated as a new independent experiment in this revision.

## 3.4 What is still missing

A discriminating test requires multiple calibrated forcing depths, multiple pulse durations, a defined rescue operation and a durable fate endpoint in the same system. Kinetic screens can identify candidate conditions [20], and therapy-resistant and persister states can exhibit GPX4-associated vulnerabilities [21,22]. The datasets considered here do not jointly identify the proposed commitment surface. This is a statement about the audited evidence, not a claim that no unexamined dataset could exist.

![Figure 2. Corrected and reproduced secondary analyses. (A) Wiernicki Fig. 2f: grey and orange bars are mean initial and additional death; black points are paired-replicate totals at 8 h, not independent endpoint treatment arms. (B) The Co trajectory reproduces the wave speed. (C) The gap table gives a descriptive continuation scale; shading is the row-bootstrap interval for that scale. None of these panels tests the depth-duration fold law.](assets/figure2_secondary.png)

**Table 2. Published datasets and their role.**

| Study | Forcing variation and rescue | Fate scope | Use here |
|---|---|---|---|
| Wiernicki [12] | Timed ferrostatin re-addition; no calibrated depth matrix | Acute death at 8 h | Finite acute rescue window; component-label correction |
| Hefetz [13] | Pulse-washout; delayed chemical/macrophage rescue | Acute death measurements | Environmental and route dependence |
| Poursaitidis [14] | Cystine deprivation and protective interventions | Death/viability | Supply-axis susceptibility; distinct cystine/GSH effects |
| Qiu [15] | Alternative interventions and pretreatments | Cell death and survival under studied conditions | Intervention-relative fate and pathway overlap |
| Co [16] | Multiple erastin states; spatial initiation | Propagation and gap continuation | Feedback, bistability and coupling |
| Samarin [18] | Ordered adaptive protection and redox-targeting drugs | In vivo toxicity/response | Normal-tissue versus SCLC adaptation |
| Sui [19] | Concentration-time matrix without rescue surface | Continuous CCK-8 | Rejected as commitment-law validation |
| Conlon [20] | Broad kinetic perturbation screen | Acute kinetic fate | Candidate-system selection |

# 4. Local fold model of recoverable survival

## 4.1 Normal-form assumptions and dimensions

A saddle-node is not implied by every codimension-one loss of stability. The fold hypothesis assumes a smooth deterministic drift with one simple zero eigenvalue at the critical equilibrium, stable remaining modes, nonzero parameter derivative in the critical direction and nonzero quadratic coefficient there. After centre-manifold reduction and a fixed local normalization, the leading drift has the form $M(\mu-x^2)$ [23--30]. Hopf, transcritical, pitchfork, non-smooth and multiple-slow-mode transitions require different hypotheses. Molecular feedback and observed bistability motivate testing a fold; they do not prove these nondegeneracy conditions.

The stochastic working model is

$$dx=M(E)[\mu-x^2]dt+\sigma(E)dW_t.\tag{1}$$

Here $W_t$ is standard Brownian motion and the stochastic equation is interpreted in the Itô sense. Choose a dimensionless normalized coordinate $x$ and dimensionless $\mu$, so $M$ has units of inverse time and $\sigma$ inverse square-root time. A different dimensional convention is possible, but the coordinate and parameter normalization must be stated and held fixed. The deterministic passage results below set $\sigma=0$; they are not exact first-passage results for Eq. (1) at nonzero noise.

For $\mu>0$, the local stable equilibrium is $x_s=\sqrt\mu$ and the unstable equilibrium is $x_u=-\sqrt\mu$. Their merger at $\mu=0$ removes the local surviving branch in the leading normal form. Positive $M$ accelerates return above the fold and passage below it. Increasing mobility is consequently not intrinsically protective: protection can instead act by maintaining a favourable margin. Local escape must be independently linked to the chosen fate before it is called biological commitment.

## 4.2 Redox support and the survival margin

A local projection can be written

$$\mu(t)=\mu_0+\alpha_GG(t)+\alpha_VV(t)+\alpha_NN(t-\tau_N)+\alpha_EE(t)-F(t).\tag{2}$$

$G$ is usable glutathione support, $V$ regeneration capacity, $N$ delayed NRF2-dependent protein support and $\tau_N$ a deployment lag. $F$ is effective forcing in the chosen dimensionless margin units. Each coefficient converts its measured covariate to those units; the variables need not share physical units. The signs and relevance of the terms require calibration. Equation (2) is a first-order local projection, not a globally linear biochemical model or an assumption that independently varying measurements identify independently acting mechanisms. Correlated support terms must not be counted twice without a fitted interpretation.

ATP, NADPH, cystine/cysteine and carbon fluxes cannot be added as unweighted quantities. One optional dimensionless slack index is

$$E(t)=\tanh\!\left[\sum_{k=1}^{K}w_k\frac{J_{k,\mathrm{supply}}(t)-J_{k,\mathrm{demand}}(t)}{J_{k,\mathrm{scale}}}\right],\qquad J_{k,\mathrm{scale}}>0.\tag{3}$$

Supply and demand for each resource $k$ use the same units; the scale shares those units and $w_k$ is dimensionless. Weights and scales must be fixed by an independent calibration or estimated on training data only. Demands may include maintenance, glutathione synthesis, GSSG reduction, lipid-peroxide repair, detoxification and proteostasis, expressed resource by resource. This additive index is an optional local approximation: non-substitutable limiting resources may require separate covariates or a limiting-flux model. The choice of $\tanh$ bounds a coordinate; it is not a physical law of redox supply and is unnecessary for the passage theorem.

Grx1-roGFP2 and hydrogen-peroxide indicators can report components of state [31--33]. They do not directly measure ATP or NADPH supply flux, nor does a single reporter automatically determine $E$, $\mu$ or $M$. A covariate earns such an interpretation through independent calibration and predictive performance.

## 4.3 Exact finite passage at constant depth

Set $\mu=-a<0$ and hold $a$ and $M>0$ constant during a pulse. For $x_f<x_i$, direct separation of $\dot x=-M(a+x^2)$ gives

$$T_c(a;x_i,x_f)=\frac{\arctan(x_i/\sqrt a)-\arctan(x_f/\sqrt a)}{M\sqrt a}.\tag{4}$$

Write the phase interval as

$$C(a;x_i,x_f)=\arctan(x_i/\sqrt a)-\arctan(x_f/\sqrt a).\tag{5}$$

For fixed straddling sections $x_i=A>0$ and $x_f=-B<0$, $C\to\pi$ as $a\downarrow0$. Thus finite fixed sections also approach the $\pi$ coefficient in the shallow limit; infinite physical sections are not required. At finite depth the coefficient depends on $a$, and a universal depth-independent commitment phase cannot be substituted into Eq. (4).

The sections need an operational meaning. For example, suppose a rescue instantaneously changes the margin to a constant $\mu_R>0$ in the same deterministic coordinate and leaves the state continuous. The post-rescue basin of $+\sqrt{\mu_R}$ is $x>-\sqrt{\mu_R}$. Then $x_f=-\sqrt{\mu_R}$ is the basin boundary, while $x_i$ is fixed by a matched pre-pulse state. Equality at the unstable boundary is a limiting threshold rather than robust recovery. More complex rescue operations, hidden adaptation or variable initial states can move these sections and must be modelled or controlled.

Equation (4) is exact for the stated truncated deterministic model. Its biological accuracy is conditional on the higher-order normal-form terms being negligible throughout the sections and forcing range, and on passage mapping to the selected rescue/fate endpoint. A local theorem does not license extrapolation to arbitrarily strong drug exposure.

![Figure 3. Local fold geometry and exact passage between fixed sections. Positive and negative margins have different dynamics; rescue is associated with an independently specified post-rescue basin.](assets/figure3_fold.png)

## 4.4 Exponent bounds, limiting regimes and section asymmetry

Let $u=\sqrt a$, $A=x_i>0$ and $B=-x_f>0$, with $M,A,B$ independent of $a$. Define $p_{\mathrm{eff}}=-d\log T_c/d\log a$. Differentiation gives

$$p_{\mathrm{eff}}(a)=\frac12+\frac{uA/(u^2+A^2)+uB/(u^2+B^2)}{2[\arctan(A/u)+\arctan(B/u)]}.\tag{6}$$

For $q>0$, $0<q/(1+q^2)<\arctan q$: the difference has derivative $2q^2/(1+q^2)^2>0$ and vanishes at zero. Applying this to $q=A/u,B/u$ proves

$$\frac12<p_{\mathrm{eff}}(a)<1,\qquad \lim_{a\downarrow0}p_{\mathrm{eff}}=\frac12,\qquad \lim_{a\to\infty}p_{\mathrm{eff}}=1.$$

The latter limit is a statement about the model. Biologically, the deep-relative-to-sections regime requires $a\gg A^2,B^2$ while the local reduction remains accurate. There $C\sim(A+B)/\sqrt a$ and $T_c\sim(A+B)/(Ma)$. If one section is at zero, the shallow coefficient changes; if both sections remain on the same nonzero side, the near-threshold passage time is finite and the $1/2$ limit need not apply. Straddling is a substantive condition.

Monotonicity is not universal. With $A=100$, $B=1$, Eq. (6) yields $p_{\mathrm{eff}}(1)=0.608686$, $p_{\mathrm{eff}}(10)=0.586447$ and $p_{\mathrm{eff}}(100)=0.563032$ before eventually approaching 1. Both sections can be rescaled into an arbitrarily small local coordinate neighbourhood with the corresponding depth rescaling; their ratio is what matters. This counterexample refutes a mandatory monotone crossover for arbitrary finite sections.

For symmetric sections $A=B=s$, the crossover is strictly increasing. In that case

$$p_{\mathrm{eff}}=\frac12+\frac{q}{2(1+q^2)\arctan q},\qquad q=s/\sqrt a.$$

The derivative of $q/[(1+q^2)\arctan q]$ has numerator $(1-q^2)\arctan q-q<0$, and $q$ decreases with $a$. This proves the restricted monotonicity result. The experimentally testable prediction is therefore the full constrained finite-section family, not a universal monotone path between its limits.

Depth-dependent $M$ adds $d\log M/d\log a$ to the observed exponent; moving sections add further derivatives. These possibilities cannot be fitted arbitrarily to rescue the model after a failed test. They require prespecified independent calibration. Measurements should concentrate near a constrained threshold and include intermediate depths if the crossover itself is to be resolved. Very deep conditions alone cannot sharply distinguish the fold from inverse-first-power exposure models.

![Figure 4. Exact passage and effective exponents for symmetric and asymmetric sections. The exponent remains between one-half and one for fixed positive straddling sections and constant mobility, but asymmetric sections need not produce a monotone curve. All plotted values are model calculations.](assets/figure4_exponents.png)

## 4.5 Time-varying forcing and interrupted treatment

During a smooth interval with $a(t)=-\mu(t)>0$, define $\theta(t)=\arctan[x(t)/\sqrt{a(t)}]$. The deterministic chain rule gives

$$\dot\theta=-M[E(t)]\sqrt{a(t)}-\frac{\dot a(t)}{2a(t)}\sin\theta\cos\theta.\tag{7}$$

Consequently,

$$\theta(t_0)-\theta(t_1)=\int_{t_0}^{t_1}M[E(t)]\sqrt{a(t)}\,dt+\int_{t_0}^{t_1}\frac{\dot a(t)}{2a(t)}\sin\theta\cos\theta\,dt.\tag{8}$$

Only constant depth removes the second integral exactly. Since $|\sin\theta\cos\theta|\le1/2$, its magnitude is at most $\int|\dot a|/(4a)\,dt$. Neglecting it requires a justified small-error regime, for example $|\dot a|\ll M a^{3/2}$ locally together with control of accumulated error. This criterion becomes harder, not easier, near $a=0$. Endpoint phases still depend on the endpoint depths and fixed physical sections.

At depth jumps, $x$ remains continuous but $\theta$ changes because the coordinate scaling changes. At positive-margin recovery intervals the $a>0$ phase coordinate is not used; one integrates the state dynamics and passes the resulting state into the next pulse. Summing $M\sqrt{-\mu}$ only over negative-margin intervals discards recovery and is not a general commitment criterion. For interrupted, rapidly changing or noisy treatment, the primary prediction is direct integration of a prespecified state model with the specified rescue operation. The exact constant-pulse test remains the first experimental stage.

# 5. A discriminating experimental specification

## 5.1 Minimal falsification stage and endpoint

Begin with one established ferroptosis model whose effective perturbation and rescue can be measured reproducibly. An inducible GPX4-loss line provides a genetically defined perturbation, but induction strength, knockdown kinetics and rescue timing still require calibration. A pulse-washout system is acceptable only if drug removal, persistent target engagement and the resulting stress trajectory are characterized. No new construct is required when existing tools meet these conditions. NRF2-active cancer is the principal application; generalization from a convenient calibration line must be tested separately.

Define $S(F,T;R,Y)$ as the probability or plating-efficiency-corrected fraction of cells retaining the prespecified durable endpoint after forcing $F$ for duration $T$ and rescue $R$. A primary operational summary is $T_{50}$ where $S=0.5$ relative to the stated rescue-only/vehicle control. This is a population summary, not automatically the deterministic $T_c$ in Eq. (4). Report non-crossing curves as such rather than forcing a $T_{50}$ estimate outside the observed range.

For clonogenic fate, count colonies relative to the number of cells assigned to the original condition and the relevant control plating efficiency. Do not replate only a fixed number of surviving cells and thereby erase treatment-associated loss. Standardize replating delay, cell density, medium, the duration of rescue exposure and whether the rescue compound is subsequently removed. Include vehicle, rescue-only, washout-only, continuous-exposure and pathway-specific controls. Define the colony criterion and follow-up interval before inspecting outcomes. Seven to fourteen days is a starting interval, to be adjusted to demonstrate reproductive recovery in the chosen line. Rescue maintained during the entire assay measures survival under continued support; it cannot be described as treatment-free restoration.

**Table 3. Starting design, subject to prospective pilot adjustment.**

| Component | Specification | Purpose |
|---|---|---|
| Biological system | One characterized model; matched starting state and culture conditions | Test the local hypothesis before generalization |
| Crossing threshold | Estimate $F_c$ independently or propagate a narrowly justified calibration uncertainty | Avoid threshold/exponent trade-off |
| Forcing | Five calibrated depths as a starting grid, concentrated near threshold with intermediate levels when feasible | Separate shallow scaling from finite-section shape |
| Durations | Seven starting durations spanning substantial rescue and failure | Bracket the response transition |
| Replication | At least three independent biological repeats initially; determine final replication by simulation/pilot variance | Distinguish independent information from technical wells |
| Rescue | One fixed operation with verified target engagement and washout kinetics | Define commitment operationally |
| Durable fate | Preregistered clonogenic or equivalent reproductive endpoint | Separate lasting loss from transient assay suppression |
| Secondary measurements | Lipid oxidation plus a dynamic redox/energetic reporter; exposure and cell-density controls | Check model regime and calibration |
| Allocation | Randomize plate position, condition order and assay batches; blind fate scoring where feasible | Control nuisance structure |

The nominal 35-condition grid is not a power guarantee. Pilot data determine whether the fold neighbourhood, meaningful section crossover and response transition can be sampled before adaptation or noise invalidates the model. Freeze the final design and analysis before the confirmation experiment. An unobserved boundary or crossover is inconclusive when it lies outside feasible sampling; it is not automatically a failed biological law.

## 5.2 Linking single-unit passage to population survival

For deterministic units with a distribution of passage times, $S(F,T)=\Pr(T_c>T)$ only if crossing the specified section corresponds to failure of the specified rescue/fate operation and the relevant baseline survival has been accounted for. Arbitrary depth-dependent heterogeneity can change the shape of $T_{50}(F)$ even when individual trajectories follow Eq. (4).

One deliberately restrictive observation model is a common location family on log passage time,

$$S(a,T)=\left[1+\exp\left\{\frac{\log T-\log T_c(a;A,B,M)}{s}\right\}\right]^{-1},\qquad s>0.\tag{9}$$

Under this additional assumption, $T_{50}(a)=T_c(a;A,B,M)$. The width $s$ is common across depth in the primary model; depth-varying width, nonzero long-duration plateaus and imperfect short-duration rescue require prespecified extensions or rejection of this observation model. Equation (9) is a population link, not a theorem derived from the stochastic normal form. An alternative is to estimate independently constrained heterogeneity or the stochastic first-passage law and fit the entire survival surface.

Fit raw colony counts or unit-level fate through a suitable likelihood with control plating efficiency, biological-repeat effects and overdispersion where needed. Logistic interpolation on log duration can provide descriptive $T_{50}$ values and uncertainty, but those estimates must not be treated as independent, error-free observations in subsequent model comparison.

## 5.3 Model comparison and identifiability

Compare the same response data, rescue definitions, calibration data and observation assumptions across:

1. **Finite-section fold:** Eq. (4), with common $A,B,M$ and independently constrained effective depth mapping; use Eq. (9) or a separately specified first-passage observation model.
2. **Cumulative exposure:** $T_c=K/F$ or a prespecified effective-exposure-area variant, including thresholded exposure when scientifically justified.
3. **Single free power:** $T_c=K(F-F_c)^{-p}$ with one fitted constant exponent and the same threshold calibration.
4. **Smooth hazard or damage accumulation:** a specified finite-parameter model without the constrained arctangent family.

Use held-out forcing depths as the main extrapolation test, with independent repeat/batch holdouts for reproducibility. Randomly splitting technical wells while sharing all depths is a weaker test of functional shape. Preregister prediction scores, acceptable calibration error and a model-selection rule. AICc may be a secondary criterion only for comparable likelihoods, correctly counted fitted parameters and a defensible independent sampling unit; it must not use repeated timepoints as independent replicates. The direction of any reported difference must be stated, for example $\Delta\mathrm{AICc}=\mathrm{AICc}_{\rm rival}-\mathrm{AICc}_{\rm fold}>4$. Where small-sample likelihood assumptions do not support AICc, use the prespecified predictive comparison instead.

The model has an exact normalization symmetry: $x\mapsto cx$, $a\mapsto c^2a$, $A\mapsto cA$, $B\mapsto cB$ and $M\mapsto M/c$ preserve Eq. (4). Consequently passage times alone do not identify the absolute coordinate scale or mobility. The sections are also exchangeable in this formula: $A$ and $B$ cannot be separately labelled as entry and exit from passage-time data alone. Fix the normalization using independent calibration and report identifiable combinations or profile uncertainty. Do not report precision that comes solely from an arbitrary coordinate convention.

## 5.4 Decision rules

Support requires a reproducible rescue-response transition, acceptable exposure and state calibration, and improved held-out prediction by the prespecified finite-section model relative to the relevant rivals. The effective exponent should match the fitted section geometry within the measured regime. Monotone increase is required only for independently justified symmetric sections, not for every finite-section fold.

A well-powered failure of the common-parameter arctangent family within its calibrated deterministic regime rejects that operational fold model. A rival consistently predicting better weakens the claimed distinctive value of the fold. If no transition is found despite a design established to span relevant rescue and failure states, the proposed boundary model fails for that tested scope. Results remain inconclusive when threshold calibration, observation-model adequacy, accessible depth range, duration bracketing or precision prevents discrimination. These categories must be set before seeing confirmation data.

![Figure 5. Prospective test sequence and the observation bridge between unit-level passage and a population rescue surface. Pilot calibration, a frozen confirmation design and held-out-depth prediction are separate stages.](assets/figure5_design.png)

# 6. Measurement and calibration

## 6.1 Return-rate scaling

For constant $\mu>0$ and $M$, linearizing at $x_s=\sqrt\mu$ gives

$$\lambda_{\mathrm{return}}=2M\sqrt\mu.\tag{10}$$

This secondary prediction requires the same local coordinate and a controlled or independently measured mobility. Near a fold, additive noise, drift and finite observation windows can obscure the deterministic return rate. In the Ornstein--Uhlenbeck approximation, stationary variance satisfies $\mathrm{Var}(x)\lambda_{\mathrm{return}}=\sigma^2/2$. That identity holds for any stable linear scalar relaxation with additive white noise; it does not diagnose a fold. Controlled small perturbations and recovery measurements are preferable to interpreting passive variance alone.

## 6.2 Driven susceptibility and the calibration gauge

If an input perturbs the normalized margin by $\delta\mu(t)$ and the measured output is the calibrated coordinate deviation $\xi$, the local response is

$$\dot\xi+\lambda_{\mathrm{return}}\xi=M\delta\mu(t),\qquad H(i\omega)=\frac{M}{\lambda_{\mathrm{return}}+i\omega}.$$

Amplitude and phase across frequencies can estimate the return rate and the input-output gain. They identify $M$ itself only when input-to-margin and coordinate-to-output gains are fixed. Unknown reporter gain and forcing normalization otherwise confound mobility. Repeated non-destructive perturbations can assist calibration before destructive pulses, but perturbation-induced adaptation and phototoxicity require controls. Retain an independently estimated mobility covariate only if it improves prespecified held-out predictions.

## 6.3 Calibrating effective forcing

Nominal drug concentration is not fold depth. Near a calibrated threshold, use $a=\kappa(F_{\mathrm{phys}}-F_{c,\mathrm{phys}})+o(|F_{\mathrm{phys}}-F_{c,\mathrm{phys}}|)$ with $\kappa>0$ in stated units, or normalize effective forcing so $a=F-F_c$. Target engagement may constrain this mapping, but a merely monotone reporter does not determine its metric scale. A nonlinear mapping changes the observed exponent and must be estimated independently or on training data, not chosen to manufacture the expected law.

Cheff et al. reported that RSL3 and ML162 inhibited TXNRD1 and did not directly inhibit recombinant GPX4 under their tested biochemical assay conditions [39]. That result should be read alongside cellular GPX4-associated evidence and assay-specific target-engagement information [11,15]. The hypothesis does not settle the compounds' full target pharmacology. Washout may remove free compound while leaving persistent covalent target inhibition; a nominal pulse therefore need not be a rectangular pulse of $\mu$. Genetic perturbations or validated cellular engagement assays are preferable to equating concentration directly with $a$, and time-dependent forcing should be modelled when measurements require it.

# 7. Heterogeneity and spatial scale

A solid tumour should not be assigned a single global margin. Let $\mathbf r$ denote position, $z$ phenotype and $\eta$ additional local parameters or initial-state variables. Local state obeys a prespecified deterministic or stochastic dynamics with $\mu=\mu(\mathbf r,z,t)$ and $M=M(\mathbf r,z,t)$. Let $\tau_R(\mathbf r,z,\eta)$ be the first time the state leaves the operational rescue set for the chosen rescue and fate endpoint, when that first-exit description is justified. The population fraction committed by $T$ is then

$$f_{\mathrm{commit}}(T;R,Y)=\int \Pr\{\tau_R(\mathbf r,z,\eta)\le T\}\,p(\mathbf r,z,\eta)\,d\mathbf r\,dz\,d\eta.\tag{11}$$

If irreversible first exit is not appropriate, use the directly defined conditional probability that rescue applied at $T$ fails to restore $Y$, rather than a first-exit event. This distinction permits recovery and nonmonotone rescue efficacy without silently forcing a monotone commitment ledger. The probability may represent intrinsic noise; $p$ separately represents the sampled heterogeneity. Both need declared conditioning and sampling units.

For constant-depth, deterministic units satisfying the section assumptions, $\tau_R$ reduces to Eq. (4). For time-dependent treatment it comes from the full trajectory, not an unrestricted threshold on accumulated negative-margin phase. Oxygenation, nutrient access, drug penetration, KEAP1/NRF2 state, FSP1, DHODH, membrane lipids and cell-cell contact may alter the parameter distribution. Listing these variables does not identify their effects or license arbitrarily flexible post-hoc heterogeneity.

Spatial propagation additionally requires a coupling law. A local scalar normal form does not determine front speed or gap transmission by itself. Reaction-diffusion or contact-mediated coupling, geometry and relevant boundary conditions must be specified and independently tested. Outputs become initiation probability, front velocity and transmission range. The Co and Roeck results motivate distinct coupling hypotheses. Failure of a proposed coupling mechanism rejects that extension without automatically disproving every uncoupled local fold.

![Figure 6. Heterogeneous and spatial extension: sample-specific trajectories and a stated rescue operation determine local fate probabilities; an additional coupling model is required for tissue-scale propagation.](assets/figure6_scale.png)

# 8. NRF2-active cancer as the principal application

NRF2-active cancers provide a stringent test because high antioxidant abundance can coexist with substrate and pathway dependencies. SLC7A11/xCT activity can generate cystine and glucose dependencies [34]. Lipid composition, p53 state and antioxidant interventions can alter ferroptosis susceptibility or tumour progression [35--38]. The model asks how far a state is from loss of recoverable survival and how rapidly its support can be redeployed; antioxidant abundance alone does not answer those questions.

Prospective calibration should distinguish basal abundance, inducible reserve, cystine/GSH support, NADPH-linked regeneration, target engagement and at least one dynamic reporter. These are candidate explanatory variables, not automatic measurements of $F$, $\mu$ or $M$. Their contribution requires predictive evaluation with appropriate controls. The delayed normal-tissue protection in SCLC [18] provides an example of intervention ordering, not evidence that every constitutively NRF2-active malignancy has the same response.

A tumour-selective boundary is meaningful only relative to the dose-limiting normal compartment. Comparators should be matched as closely as possible in tissue origin and proliferative state. Estimate tumour and normal response surfaces under the same rescue definition and durable endpoint, or state explicitly when such matching is impossible. An apparent separation produced by different plating efficiencies or different rescue support is not a therapeutic window.

A controlled cellular system is the first gate. Extension to organoids, co-cultures or tumours is justified only after the local model survives calibration and rival comparison in its stated regime. A failed controlled experiment must not be retrospectively rescued by invoking unmeasured spatial complexity.

# 9. Scope, failure conditions and interpretation

The saddle-node normal form is local. It can fail when several independent slow directions remain active, adaptive rewiring occurs on the passage timescale, noise-driven escape dominates, target engagement is strongly time-dependent, or propagation is the principal observable. These are identifiable model alternatives and experimental limitations, not reasons to declare every result compatible with the fold. Model adequacy must be evaluated before interpreting a parameter as a biological property.

Commitment remains operational: failure of the specified rescue to restore the specified endpoint. Distinct execution routes can follow that loss of recoverability, and ferroptotic and apoptotic programmes can intersect [15]. A failed rescue does not prove that every physically possible rescue would fail. Acute protection does not prove durable survival, and continued pharmacological support does not prove restoration after treatment withdrawal.

No clinical regimen follows from this paper. Antioxidants, pro-oxidants, dietary interventions, ferroptosis inducers and treatment schedules should not be changed in patients on the basis of these calculations. The proposed experiments are laboratory tests of a dynamical hypothesis.

No sex- or gender-stratified inference is made. The cited studies use diverse lines and systems with incompletely reported sex information. Prospective experiments should report cell-line or donor sex where known, authentication, culture conditions and other plausible effect modifiers, and should state the scope of any comparison.

**Table 4. Prespecified claims and failure conditions.**

| Claim | Required observation | Failure or limitation |
|---|---|---|
| Finite operational rescue boundary | A reproducible transition in the specified rescue/fate assay | No transition in a design shown to span the relevant regime; otherwise unbracketed/inconclusive |
| Finite-section fold family | Improved held-out predictions under fixed calibrated sections, mobility and observation model | Rival consistently predicts better, or response shape contradicts the constrained family |
| Symmetric monotone crossover | Independently justified symmetric sections and increasing exponent within the accessible regime | Asymmetric/nonmonotone results reject this restricted claim, not all finite-section folds |
| Mobility covariate matters | Independently calibrated dynamic measurement improves prediction | No reproducible incremental predictive value |
| Tumour-normal separation | Tumour and relevant normal response surfaces separate under matched definitions | Equal/earlier normal failure or incompatible assay normalization |
| Spatial extension | A stated coupling model predicts propagation outputs | Propagation contradicts that coupling/local model combination |

# 10. Conclusion

Published experiments distinguish redox injury from the loss of a particular rescue opportunity, demonstrate dependence on exposure duration, state, intervention and environment, and show ferroptotic propagation in suitably coupled populations. The acute rescue data and spatial descriptors are strong motivation for a dynamical theory, while durable clonogenic commitment requires its own measurement.

For the proposed deterministic fold, fixed straddling finite sections give an exact arctangent passage law. Its effective exponent lies between $1/2$ and $1$ with the stated limiting behaviour. Symmetric sections give a monotone crossover; asymmetric sections need not. Time-varying forcing requires a derivative correction and explicit recovery dynamics. Population $T_{50}$ follows the single-unit law only under an additional tested observation or heterogeneity model.

These restrictions preserve a discriminating hypothesis. A calibrated depth-duration-rescue experiment, durable fate assay and held-out model comparison can establish whether the constrained family adds predictive value in NRF2-active cancer. Success would provide a quantified, operation-specific boundary of recoverability; failure would reject the tested model without erasing the independently established biological rescue phenomena.

# Glossary

| Term | Definition |
|---|---|
| Operational commitment | Failure of a named rescue operation to restore a named fate endpoint. |
| Rescue window | Interval in which that operation retains efficacy under the specified assay. |
| Survival margin $\mu$ | Normalized local control parameter for the proposed fold. |
| Fold depth $a$ | Positive calibrated distance below the fold, $a=-\mu$. |
| Mobility $M$ | Positive kinetic coefficient in a fixed coordinate normalization. |
| Finite sections | Prespecified entry and rescue-boundary locations used to define passage. |
| $T_c$ | Deterministic passage time for an individual model trajectory. |
| $T_{50}$ | Population duration yielding the prespecified 50% normalized survival endpoint. |
| Trigger wave | Self-regenerating propagation requiring local response dynamics and spatial coupling. |

# Data and code availability

No new wet-lab, animal or patient data were generated. Original third-party workbooks are available with Wiernicki et al. [12] and Co et al. [16]. The accompanying audit distinguishes publisher data, archived derived tables, re-executed calculations and model-only illustrations. The corrected analysis script validates the Wiernicki component interpretation against the published stacked-bar figure, preserves matched replicate components and computes final death by summation. Archived Co CSV tables, numerical verification code, figure-generation code and this editable manuscript are supplied with the revision materials. The earlier reproducibility package is retained for provenance; its Wiernicki endpoint labels and unrestricted phase interpretation are superseded. A stable public repository identifier should be assigned to the final approved release; this manuscript does not claim that such a release has already occurred.

# Ethics statement

This hypothesis paper and secondary analysis use published cell-line or aggregate data. No new human or animal studies were conducted.

# Funding

This research received no specific grant from funding agencies in the public, commercial or not-for-profit sectors.

# Declaration of competing interests

The author declares no known competing financial interests or personal relationships that could have appeared to influence this work.

# Declaration of generative AI and AI-assisted technologies

During preparation and revision, the author used OpenAI ChatGPT and Google Gemini to assist with literature organization, language refinement, mathematical checking, code development, figure preparation and reference verification. The revision materials identify independent source and calculation checks. Model suggestions are not treated as scientific evidence. The author is responsible for reviewing the final manuscript and its claims. Figures are deterministic plots or schematics derived from stated equations, archived analysis data or cited primary figures; no generative image model was used.

# CRediT author statement

Daniel John Murray: Conceptualization; Methodology; Formal analysis; Investigation; Data curation; Software; Visualization; Writing -- original draft; Writing -- review and editing; Project administration.

# References

\small

1. Murray DJ. A dynamical model of glutathione homeostasis in G6PD deficiency and NRF2-activated non-small cell lung cancer. Redox Biochemistry and Chemistry. 2026;17:100084. [doi:10.1016/j.rbc.2026.100084](https://doi.org/10.1016/j.rbc.2026.100084).

2. Murray DJ. Hormesis as a geometric necessity of bounded adaptive systems: quantitative predictions from first principles. Dose-Response. 2026;24(3). [doi:10.1177/15593258261469171](https://doi.org/10.1177/15593258261469171).

3. DeNicola GM, Karreth FA, Humpton TJ, et al. Oncogene-induced Nrf2 transcription promotes ROS detoxification and tumorigenesis. Nature. 2011;475:106-109. [doi:10.1038/nature10189](https://doi.org/10.1038/nature10189).

4. Romero R, Sayin VI, Davidson SM, et al. Keap1 loss promotes Kras-driven lung cancer and results in dependence on glutaminolysis. Nature Medicine. 2017;23:1362-1368. [doi:10.1038/nm.4407](https://doi.org/10.1038/nm.4407).

5. Koppula P, Olszewski K, Zhang Y, et al. KEAP1 deficiency drives glucose dependency and sensitizes lung cancer cells and tumors to GLUT inhibition. iScience. 2021;24:102649. [doi:10.1016/j.isci.2021.102649](https://doi.org/10.1016/j.isci.2021.102649).

6. LeBoeuf SE, Wu WL, Karakousi TR, et al. Activation of oxidative stress response in cancer generates a druggable dependency on exogenous non-essential amino acids. Cell Metabolism. 2020;31:339-350.e4. [doi:10.1016/j.cmet.2019.11.012](https://doi.org/10.1016/j.cmet.2019.11.012).

7. Jeong Y, Hellyer JA, Stehr H, et al. Role of KEAP1/NFE2L2 mutations in the chemotherapeutic response of patients with non-small cell lung cancer. Clinical Cancer Research. 2020;26:274-281. [doi:10.1158/1078-0432.CCR-19-1237](https://doi.org/10.1158/1078-0432.CCR-19-1237).

8. Baird L, Yamamoto M. The molecular mechanisms regulating the KEAP1-NRF2 pathway. Molecular and Cellular Biology. 2020;40:e00099-20. [doi:10.1128/MCB.00099-20](https://doi.org/10.1128/MCB.00099-20).

9. Hayes JD, Dinkova-Kostova AT. The Nrf2 regulatory network provides an interface between redox and intermediary metabolism. Trends in Biochemical Sciences. 2014;39:199-218. [doi:10.1016/j.tibs.2014.02.002](https://doi.org/10.1016/j.tibs.2014.02.002).

10. Dixon SJ, Lemberg KM, Lamprecht MR, et al. Ferroptosis: an iron-dependent form of nonapoptotic cell death. Cell. 2012;149:1060-1072. [doi:10.1016/j.cell.2012.03.042](https://doi.org/10.1016/j.cell.2012.03.042).

11. Yang WS, SriRamaratnam R, Welsch ME, et al. Regulation of ferroptotic cancer cell death by GPX4. Cell. 2014;156:317-331. [doi:10.1016/j.cell.2013.12.010](https://doi.org/10.1016/j.cell.2013.12.010).

12. Wiernicki B, Maschalidi S, Pinney J, et al. Cancer cells dying from ferroptosis impede dendritic cell-mediated anti-tumor immunity. Nature Communications. 2022;13:3676. [doi:10.1038/s41467-022-31218-2](https://doi.org/10.1038/s41467-022-31218-2).

13. Hefetz R, Lianski S, Ghantous L, et al. Macrophages rescue cells from ferroptotic death. Cell Death & Disease. 2026;17:66. [doi:10.1038/s41419-025-08277-6](https://doi.org/10.1038/s41419-025-08277-6).

14. Poursaitidis I, Wang X, Crighton T, et al. Oncogene-selective sensitivity to synchronous cell death following modulation of the amino acid nutrient cystine. Cell Reports. 2017;18:2547-2556. [doi:10.1016/j.celrep.2017.02.054](https://doi.org/10.1016/j.celrep.2017.02.054).

15. Qiu Y, Hüther JA, Wank B, et al. Interplay of ferroptotic and apoptotic cell death and its modulation by BH3-mimetics. Cell Death & Differentiation. 2025;32:1970-1985. [doi:10.1038/s41418-025-01514-7](https://doi.org/10.1038/s41418-025-01514-7).

16. Co HKC, Wu CC, Lee YC, Chen SH. Emergence of large-scale cell death through ferroptotic trigger waves. Nature. 2024;631:654-662. [doi:10.1038/s41586-024-07623-6](https://doi.org/10.1038/s41586-024-07623-6).

17. Roeck BF, Lotfipour Nasudivar S, Vorndran MRH, et al. Ferroptosis spreads to neighboring cells via plasma membrane contacts. Nature Communications. 2025;16:2951. [doi:10.1038/s41467-025-58175-w](https://doi.org/10.1038/s41467-025-58175-w).

18. Samarin J, Nůsková H, Fabrowski P, et al. Differential KEAP1/NRF2-mediated signaling widens the therapeutic window of redox-targeting drugs in SCLC therapy. Nature Communications. 2026;17:3435. [doi:10.1038/s41467-026-71608-4](https://doi.org/10.1038/s41467-026-71608-4).

19. Sui X, Zhang R, Liu S, et al. RSL3 drives ferroptosis through GPX4 inactivation and ROS production in colorectal cancer. Frontiers in Pharmacology. 2018;9:1371. [doi:10.3389/fphar.2018.01371](https://doi.org/10.3389/fphar.2018.01371).

20. Conlon M, Poltorack CD, Forcina GC, et al. A compendium of kinetic modulatory profiles identifies ferroptosis regulators. Nature Chemical Biology. 2021;17:665-674. [doi:10.1038/s41589-021-00751-4](https://doi.org/10.1038/s41589-021-00751-4).

21. Viswanathan VS, Ryan MJ, Dhruv HD, et al. Dependency of a therapy-resistant state of cancer cells on a lipid peroxidase pathway. Nature. 2017;547:453-457. [doi:10.1038/nature23007](https://doi.org/10.1038/nature23007).

22. Hangauer MJ, Viswanathan VS, Ryan MJ, et al. Drug-tolerant persister cancer cells are vulnerable to GPX4 inhibition. Nature. 2017;551:247-250. [doi:10.1038/nature24297](https://doi.org/10.1038/nature24297).

23. Ferrell JE Jr. Self-perpetuating states in signal transduction: positive feedback, double-negative feedback and bistability. Current Opinion in Cell Biology. 2002;14:140-148. [doi:10.1016/S0955-0674(02)00314-9](https://doi.org/10.1016/S0955-0674(02)00314-9).

24. Eissing T, Conzelmann H, Gilles ED, et al. Bistability analyses of a caspase activation model for receptor-induced apoptosis. Journal of Biological Chemistry. 2004;279:36892-36897. [doi:10.1074/jbc.M404893200](https://doi.org/10.1074/jbc.M404893200).

25. Bagci EZ, Vodovotz Y, Billiar TR, Ermentrout GB, Bahar I. Bistability in apoptosis: roles of Bax, Bcl-2 and mitochondrial permeability transition pores. Biophysical Journal. 2006;90:1546-1559. [doi:10.1529/biophysj.105.068122](https://doi.org/10.1529/biophysj.105.068122).

26. Mojtahedi M, Skupin A, Zhou J, et al. Cell fate decision as high-dimensional critical state transition. PLoS Biology. 2016;14:e2000640. [doi:10.1371/journal.pbio.2000640](https://doi.org/10.1371/journal.pbio.2000640).

27. Strogatz SH. Nonlinear Dynamics and Chaos. 2nd ed. Westview Press; 2015.

28. Kuehn C. A mathematical framework for critical transitions: bifurcations, fast-slow systems and stochastic dynamics. Physica D. 2011;240:1020-1035. [doi:10.1016/j.physd.2011.02.012](https://doi.org/10.1016/j.physd.2011.02.012).

29. Scheffer M, Bascompte J, Brock WA, et al. Early-warning signals for critical transitions. Nature. 2009;461:53-59. [doi:10.1038/nature08227](https://doi.org/10.1038/nature08227).

30. Dakos V, Carpenter SR, Brock WA, et al. Methods for detecting early warnings of critical transitions in time series illustrated using simulated ecological data. PLoS ONE. 2012;7:e41010. [doi:10.1371/journal.pone.0041010](https://doi.org/10.1371/journal.pone.0041010).

31. Gutscher M, Pauleau AL, Marty L, et al. Real-time imaging of the intracellular glutathione redox potential. Nature Methods. 2008;5:553-559. [doi:10.1038/nmeth.1212](https://doi.org/10.1038/nmeth.1212).

32. Pak VV, Ezeriņa D, Lyublinskaya OG, et al. Ultrasensitive genetically encoded indicator for hydrogen peroxide identifies roles for the oxidant in cell migration and mitochondrial function. Cell Metabolism. 2020;31:642-653.e6. [doi:10.1016/j.cmet.2020.02.003](https://doi.org/10.1016/j.cmet.2020.02.003).

33. Waldeck-Weiermair M, Covington TA, Pandey AK, Michel T. Making sense of subcellular H2O2 in mammals. Redox Biochemistry and Chemistry. 2026;16:100080. [doi:10.1016/j.rbc.2026.100080](https://doi.org/10.1016/j.rbc.2026.100080).

34. Koppula P, Zhuang L, Gan B. Cystine transporter SLC7A11/xCT in cancer: ferroptosis, nutrient dependency and cancer therapy. Protein & Cell. 2021;12:599-620. [doi:10.1007/s13238-020-00789-5](https://doi.org/10.1007/s13238-020-00789-5).

35. Doll S, Proneth B, Tyurina YY, et al. ACSL4 dictates ferroptosis sensitivity by shaping cellular lipid composition. Nature Chemical Biology. 2017;13:91-98. [doi:10.1038/nchembio.2239](https://doi.org/10.1038/nchembio.2239).

36. Jiang L, Kon N, Li T, et al. Ferroptosis as a p53-mediated activity during tumour suppression. Nature. 2015;520:57-62. [doi:10.1038/nature14344](https://doi.org/10.1038/nature14344).

37. Sayin VI, Ibrahim MX, Larsson E, et al. Antioxidants accelerate lung cancer progression in mice. Science Translational Medicine. 2014;6:221ra15. [doi:10.1126/scitranslmed.3007653](https://doi.org/10.1126/scitranslmed.3007653).

38. Cuadrado A, Rojo AI, Wells G, et al. Therapeutic targeting of the NRF2 and KEAP1 partnership in chronic diseases. Nature Reviews Drug Discovery. 2019;18:295-317. [doi:10.1038/s41573-018-0008-x](https://doi.org/10.1038/s41573-018-0008-x).

39. Cheff DM, Huang C, Scholzen KC, et al. The ferroptosis inducing compounds RSL3 and ML162 are not direct inhibitors of GPX4 but of TXNRD1. Redox Biology. 2023;62:102703. [doi:10.1016/j.redox.2023.102703](https://doi.org/10.1016/j.redox.2023.102703).
