// Murray, Finite rescue windows (reviewed 7 September 2026), equations 1 and 4.
// Deterministic local normal form; all example parameters are dimensionless.
export function passageTime({depth:a, rescue:r, mobility:M=1, initial:A=1}) {
  if (![a,r,M,A].every(Number.isFinite) || a<=0 || r<=0 || M<=0 || A<=0) throw Error('Positive finite parameters required.');
  return (Math.atan(A/Math.sqrt(a))+Math.atan(Math.sqrt(r/a)))/(M*Math.sqrt(a));
}
export function pulseState(t,{depth:a,mobility:M=1,initial:A=1}) {
  if (!Number.isFinite(t)||t<0) throw Error('Time must be nonnegative.');
  const phase=Math.atan(A/Math.sqrt(a))-M*Math.sqrt(a)*t;
  return phase<=-Math.PI/2 ? -Infinity : Math.sqrt(a)*Math.tan(phase);
}
export function rhs(x,margin,M=1){return M*(margin-x*x);}
export function step(x,margin,h,M=1){const k1=rhs(x,margin,M),k2=rhs(x+h*k1/2,margin,M),k3=rhs(x+h*k2/2,margin,M),k4=rhs(x+h*k3,margin,M);return x+h*(k1+2*k2+2*k3+k4)/6;}
export function simulate({depth=1,duration=1.2,rescue=1,mobility=1,initial=1}={}) {
  if(!Number.isFinite(duration)||duration<0)throw Error('Duration must be nonnegative.');
  const params={depth,rescue,mobility,initial},critical=passageTime(params),boundary=-Math.sqrt(rescue);
  const delta=duration-critical;
  const outcome=Math.abs(delta)<1e-8?'boundary':delta<0?'recoverable':'beyond';
  const horizon=Math.max(4,duration+3),points=[];
  // Stop at an explicitly chosen display section; never interpret divergence as measured death.
  const lower=-2.25;
  let x=initial,t=0,exited=false;
  points.push({t,x,phase:'pulse'});
  while(t<duration-1e-10){const next=Math.min(duration,t+1/180); x=pulseState(next,params);if(!Number.isFinite(x)||x<lower){exited=true;break;}t=next;points.push({t,x,phase:'pulse'});}
  if(!exited){t=duration;while(t<horizon-1e-10){const h=Math.min(1/180,horizon-t);x=step(x,rescue,h,mobility);if(!Number.isFinite(x)||x<lower){exited=true;break;}t+=h;points.push({t,x,phase:'rescue'});}}
  return {params:{...params,duration},critical,boundary,outcome,horizon,points,exited,
    scope:'Illustrative deterministic local model. Time and forcing are normalized; no drug doses, human outcomes or tumour selectivity are inferred.'};
}
