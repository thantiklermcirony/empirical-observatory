import {simulate,passageTime} from './model.mjs';
const el=id=>document.getElementById(id), inputs=['depth','duration','rescue'];
let current;
const line=(pts,x,y)=>pts.map((p,i)=>`${i?'L':'M'}${x(p.t).toFixed(2)},${y(p.x).toFixed(2)}`).join(' ');
function draw(){
 const p=Object.fromEntries(inputs.map(id=>[id,Number(el(id).value)]));current=simulate(p);
 for(const id of inputs)el(id+'-value').textContent=p[id].toFixed(2);
 const {horizon,points,boundary,critical,outcome}=current,x=t=>67+t/horizon*666,y=s=>350-(s+2.25)/4*300;
 const parts=[];
 parts.push(`<rect x="67" y="50" width="${x(p.duration)-67}" height="300" fill="#ecae870d"/>`);
 for(const value of [-2,-1,0,1])parts.push(`<line x1="67" x2="733" y1="${y(value)}" y2="${y(value)}" stroke="#34464a"/><text x="52" y="${y(value)+5}" text-anchor="end" fill="#bac5c3" font-size="14">${value}</text>`);
 for(let i=0;i<=4;i++){const t=horizon*i/4;parts.push(`<text x="${x(t)}" y="378" text-anchor="middle" fill="#bac5c3" font-size="14">${t.toFixed(1)}</text>`);}
 parts.push(`<text x="400" y="411" text-anchor="middle" fill="#bac5c3" font-size="14">Time (normalized model units)</text><line x1="67" x2="733" y1="${y(boundary)}" y2="${y(boundary)}" stroke="#b7bfba" stroke-dasharray="6 6"/><text x="725" y="${y(boundary)-9}" text-anchor="end" fill="#bac5c3" font-size="13">Rescue boundary</text><line x1="${x(p.duration)}" x2="${x(p.duration)}" y1="50" y2="350" stroke="#ecae87" stroke-dasharray="3 5"/><text x="${Math.max(120,Math.min(675,x(p.duration)))}" y="32" text-anchor="middle" fill="#ecae87" font-size="14">Rescue applied</text>`);
 const pulse=points.filter(p=>p.phase==='pulse'),rescue=points.filter(p=>p.phase==='rescue');
 if(pulse.length)parts.push(`<path d="${line(pulse,x,y)}" fill="none" stroke="#ecae87" stroke-width="3"/>`);
 if(rescue.length)parts.push(`<path d="${line([pulse.at(-1),...rescue],x,y)}" fill="none" stroke="#9ed6c3" stroke-width="3"/>`);
 const last=points.at(-1);parts.push(`<circle cx="${x(last.t)}" cy="${y(last.x)}" r="5" fill="#eff0e8"/>`);
 el('trajectory').innerHTML=parts.join('');
 el('critical').textContent=critical.toFixed(2);
 el('outcome-label').textContent='UNDER THESE MODEL ASSUMPTIONS';
 el('outcome').textContent=outcome==='recoverable'?'A return remains possible.':outcome==='boundary'?'Exactly at the unstable boundary.':'This rescue comes too late.';
 el('outcome').style.color=outcome==='recoverable'?'#9ed6c3':'#ecae87';
 el('outcome-detail').textContent=outcome==='recoverable'?'The restored support places the state in a basin that leads back to the stable state.':outcome==='boundary'?'An arbitrarily small perturbation can change the outcome. This is not robust recovery.':'The state has crossed the basin boundary for this particular rescue. A different rescue would define a different boundary.';
 el('trajectory').setAttribute('aria-label',`Illustrative trajectory. Stress ${p.depth}, rescue at ${p.duration}, restored support ${p.rescue}. Crossing time ${critical.toFixed(2)} model units. Outcome: ${outcome}.`);
}
inputs.forEach(id=>el(id).addEventListener('input',draw));
for(const [id,factor] of [['early',.7],['late',1.15]])el(id).addEventListener('click',()=>{el('duration').value=Math.min(16,passageTime({depth:Number(el('depth').value),rescue:Number(el('rescue').value)})*factor);draw();});
el('download').addEventListener('click',()=>{const blob=new Blob([JSON.stringify(current,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='cancer-lab-scenario.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});
draw();
fetch('evidence.json').then(r=>{if(!r.ok)throw Error('Evidence record unavailable.');return r.json();}).then(data=>{
 const x=i=>91+i*100,y=v=>280-v*2.1,parts=[];
 for(const v of [0,25,50,75,100])parts.push(`<line x1="50" x2="660" y1="${y(v)}" y2="${y(v)}" stroke="#34464a"/><text x="40" y="${y(v)+5}" text-anchor="end" fill="#bac5c3" font-size="14">${v}%</text>`);
 data.groups.forEach((g,i)=>{parts.push(`<rect x="${x(i)-23}" y="${y(g.initial)}" width="46" height="${g.initial*2.1}" fill="#8b9da2"/><rect x="${x(i)-23}" y="${y(g.total)}" width="46" height="${g.additional*2.1}" fill="#ecae87"/><text x="${x(i)}" y="${y(g.total)-10}" text-anchor="middle" fill="#eff0e8" font-size="14">${g.total.toFixed(1)}%</text><text x="${x(i)}" y="310" text-anchor="middle" fill="#bac5c3" font-size="14">${g.hour} h</text>`);});
 parts.push('<text x="350" y="342" text-anchor="middle" fill="#bac5c3" font-size="14">Time when ferrostatin-1 was restored (published experiment)</text>');
 el('evidence-chart').innerHTML=parts.join('');
 el('evidence-chart').setAttribute('aria-label',`Published acute death at eight hours: ${data.groups.map(g=>`rescue at ${g.hour} hours, ${g.total.toFixed(1)} percent total death`).join('; ')}. Three source replicates per group.`);
}).catch(e=>{el('evidence-status').textContent=e.message+' Use the source values link to inspect the data.';});
