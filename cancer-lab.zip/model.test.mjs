import test from 'node:test';
import assert from 'node:assert/strict';
import {passageTime,pulseState,step,simulate} from './model.mjs';
test('symmetric unit example has exact pi/2 rescue boundary',()=>{assert.ok(Math.abs(passageTime({depth:1,rescue:1})-Math.PI/2)<1e-14);});
test('direct numerical integration reaches the analytic boundary',()=>{for(const depth of [.05,.2,1,2])for(const rescue of [.2,1,2]){const p={depth,rescue};const t=passageTime(p);let x=1;const n=20000,h=t/n;for(let i=0;i<n;i++)x=step(x,-depth,h);assert.ok(Math.abs(x+Math.sqrt(rescue))<1e-8);assert.ok(Math.abs(pulseState(t,p)+Math.sqrt(rescue))<1e-10);}});
test('rescue on opposite sides returns to different basins',()=>{const p={depth:1,rescue:1};const t=passageTime(p);const early=simulate({...p,duration:.8*t}),late=simulate({...p,duration:1.1*t});assert.equal(early.outcome,'recoverable');assert.ok(early.points.at(-1).x>0);assert.equal(late.outcome,'beyond');assert.equal(late.exited,true);assert.equal(simulate({...p,duration:t}).outcome,'boundary');});
test('depth, rescue and clock dependencies are preserved',()=>{assert.ok(passageTime({depth:2,rescue:1})<passageTime({depth:1,rescue:1}));assert.ok(passageTime({depth:1,rescue:2})>passageTime({depth:1,rescue:1}));assert.equal(passageTime({depth:1,rescue:1,mobility:2}),passageTime({depth:1,rescue:1})/2);});
test('coordinate rescaling does not change passage time',()=>{const p={depth:.3,rescue:.7,mobility:.8,initial:1.2};const c=3;assert.ok(Math.abs(passageTime(p)-passageTime({depth:p.depth*c*c,rescue:p.rescue*c*c,mobility:p.mobility/c,initial:p.initial*c}))<1e-12);});
test('invalid scientific inputs fail explicitly',()=>{for(const a of [0,-1,NaN,Infinity])assert.throws(()=>passageTime({depth:a,rescue:1}));assert.throws(()=>simulate({duration:-1}));});
