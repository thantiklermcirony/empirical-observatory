import distribution from '../../../lib/ontology-distribution.json' with {type:'json'};

/** Keep public paths while serving large records from a pinned repository snapshot. */
export async function GET(_request:Request,context:{params:Promise<{path:string[]}>}){
 const {path}=await context.params;
 const key=path.join('/');
 if(!Object.hasOwn(distribution.files,key))return new Response('Unknown ledger asset.',{status:404});
 return new Response(null,{status:302,headers:{Location:distribution.baseUrl+key,'Cache-Control':'public, max-age=300'}});
}
