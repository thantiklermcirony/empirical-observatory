"""Independent bounded operational probes; edits stay in the owned run copy."""
from copy import deepcopy
from datetime import datetime, timezone
from fractions import Fraction as F
from pathlib import Path
from unittest.mock import patch
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'run'))
from ports import Session, KERNEL_SHA, serial

sha = lambda b: hashlib.sha256(b).hexdigest()
records = []
def passed(name, detail):
    records.append({'name':name, 'passed':True, 'detail':detail})

def observation(s, ident, quantity, interval, unit, **extra):
    return s.event(ident, 'observation', dict(quantity=quantity, interval=interval,
        unit=unit, origin='synthetic', preparation_time_min=0, **extra))

def baseline():
    s=Session()
    s.deliver(observation(s, 'q1', 'q', ['99/100','99/100'], '1'))
    s.deliver(observation(s, 't1', 'T', ['980','1000'], 'uM'))
    s.deliver(observation(s, 'n1', 'N', ['9','11'], 'uM'))
    return s

def reject_atomic(name, event_factory, error=ValueError):
    s=baseline();event=event_factory(s);before=deepcopy(s.__dict__)
    try:s.deliver(event)
    except error as exc:
        assert s.__dict__ == before, name+' changed internal state'
        passed(name, {'exception':type(exc).__name__, 'message':str(exc),
                      'entire_session_unchanged':True})
        return
    raise AssertionError(name+' was accepted')

# Compute expected values directly, without consulting the producer's trace.
s=baseline();before=s.snapshot()
lower=F(99,100)*F(98,100)/2+F(9,1000)+F(3,50)
upper=F(99,100)/2+F(11,1000)+F(3,50)
assert list(map(F,s.result['ceiling_interval_mM'])) == [lower,upper]
assert (lower,upper)==(F(5541,10000),F(283,500))
assert s.result['target_excluded'] is True
assert s.observations['T']['interval']==[F(49,50),F(1)]
capture=deepcopy(before);encoded_capture=json.dumps(capture,sort_keys=True)
s.deliver(observation(s,'n2','N',['60','80'],'uM',replaces='n1'))
assert list(map(F,s.result['ceiling_interval_mM']))==[F(6051,10000),F(127,200)]
assert s.result['target_excluded'] is False and 'n1' not in s.result['active_signals']
assert [x['id'] for x in s.superseded]==['n1']
assert s.audit[-1]['before']['resource']['target_excluded'] is True
assert s.audit[-1]['after']['resource']['target_excluded'] is False
assert json.dumps(capture,sort_keys=True)==encoded_capture
assert capture['revision']+1==s.snapshot()['revision']
capture['resource']['active_signals'].append('external-change')
assert 'external-change' not in s.result['active_signals']
passed('exact observation conversion, correction and captured views',
       {'old_interval':[str(lower),str(upper)],'new_interval':s.result['ceiling_interval_mM'],
        'old_exclusion_retracted':True,'superseded_signal_retained':True,
        'prior_snapshot_bytes_unchanged':True,'snapshot_mutation_isolated':True})

old_resource=deepcopy(s.result);computations=s.computations
s.deliver(s.event('retina','context_selection',{'anatomical_label':'retina'}))
assert s.result==old_resource and s.computations==computations
s.deliver(s.event('quantum-hold','review_hold',{'asset':'quantum_flux','reason':'independent invalid witness'}))
assert s.result==old_resource and s.computations==computations
assert s.audit[-1]['outbound']['changed_scientific_result'] is False
assert s.snapshot()['quantum_connection']['status']=='held_upstream_review'
passed('context-only change and unrelated held quantum preserve biology',
       {'resource_equal':True,'no_recomputation':True,'quantum_hold_visible':True})

# Positive retry after intervening events still acknowledges the same delivery only.
retry=deepcopy(s.audit[2]['event']);all_state=deepcopy(s.__dict__)
ack=s.deliver(retry)
assert ack['delivery']=='duplicate_ignored' and s.__dict__==all_state
passed('retry after correction and other events is inert',ack)

def change_envelope(field,value):
    def make(s):
        event=s.event('bad','context_selection',{'anatomical_label':'heart'})
        event[field]=value
        return event
    return make

for field,value in [('preparation_id','OTHER'),('scenario_id','OTHER'),
                    ('model_sha256','unreviewed-source'),('base_revision',0),
                    ('base_revision',True),('event_id',''),('event_id',1),
                    ('payload',None),('kind','review_accept')]:
    reject_atomic('envelope '+field+' '+repr(value),change_envelope(field,value))

def bad_observation(field,value):
    def make(s):
        event=observation(s,'bad-N','N',['9','11'],'uM',replaces='n1')
        event['payload'][field]=value
        return event
    return make

for field,value in [('unit','a.u.'),('unit','uM/s'),('unit','mmol'),('unit','1'),
                    ('origin','empirical'),('origin','unreviewed'),
                    ('preparation_time_min',1),('preparation_time_min',-1),
                    ('preparation_time_min',None),('preparation_time_min','0'),
                    ('quantity','GSH'),('interval',[9.,11.]),('interval',[True,True]),
                    ('interval',['11','9']),('interval',['-1','1']),
                    ('interval',['NaN','1']),('interval',['1']),('replaces','superseded-id')]:
    reject_atomic('observation '+field+' '+repr(value),bad_observation(field,value))
reject_atomic('unlabelled correction',lambda s:observation(s,'bad-N','N',['9','11'],'uM'))
reject_atomic('dimensioned q',lambda s:observation(s,'q2','q',['.99','.99'],'mM',replaces='q1'))
reject_atomic('noisy q lacks model',lambda s:observation(s,'q2','q',['.98','1'],'1',replaces='q1'))
reject_atomic('q outside admitted range',lambda s:observation(s,'q2','q',['1.1','1.1'],'1',replaces='q1'))
def forged_empirical(s):
    e=bad_observation('origin','empirical')(s)
    e['payload'].update(admitted=True,review_status='accepted',source='root')
    return e
reject_atomic('payload admission labels do not admit empirical data',forged_empirical)
def conflict(s):
    event=deepcopy(s.audit[0]['event']);event['payload']['interval']=['.9','.9']
    return event
reject_atomic('conflicting reused ID is atomic',conflict)

# Exercise rollback after observation/superseded-list mutation, not only validation.
s=baseline();entire=deepcopy(s.__dict__)
with patch('ports.rank_bins',side_effect=RuntimeError('independent forced computation failure')):
    try:s.deliver(observation(s,'n2','N',['60','80'],'uM',replaces='n1'))
    except RuntimeError:pass
    else:raise AssertionError('forced solver failure was swallowed')
assert s.__dict__==entire
passed('late computation failure rolls back every session field',
       {'observations_audit_superseded_seen_revision_and_count_unchanged':True})

# Contradiction is a valid new state; correction recovers from it without old bounds.
s=baseline()
s.deliver(observation(s,'outside','N',['90','100'],'uM',replaces='n1'))
assert s.snapshot()['resource']['status']=='inconsistent'
assert 'ceiling_interval_mM' not in s.snapshot()['resource']
assert s.audit[-1]['outbound']['next_request'] is None
s.deliver(observation(s,'repair','N',['9','11'],'uM',replaces='outside'))
assert s.result['target_excluded'] is True
assert [x['id'] for x in s.superseded]==['n1','outside']
passed('inconsistent observation retracts numbers and remains correctable',
       {'no_answer_or_request_while_inconsistent':True,'replacement_recovers':True})

# Geometry hold remains effective after navigation and subsequent observation changes.
s=baseline();s.deliver(s.event('g-hold','review_hold',{'asset':'geometry','reason':'approved is only text; hold still revokes'}))
for event in [s.event('context-held','context_selection',{'anatomical_label':'heart'})]:
    s.deliver(event)
s.deliver(observation(s,'n-held','N',['60','80'],'uM',replaces='n1'))
view=s.snapshot()
assert view['resource']['status']=='blocked_review'
assert 'ceiling_interval_mM' not in view['resource'] and 'next_request' not in view['resource']
assert s.audit[-1]['outbound']['next_request'] is None
passed('geometry hold suppresses current values and follow-up requests',view)

# Actual on-disk change and deletion are checked at view time, without a mocked hash.
kernel=ROOT/'run/vendor/geometry.py';original=kernel.read_bytes()
try:
    s=baseline();count=s.computations;kernel.write_bytes(original+b'\n# reviewer-owned temporary byte change\n')
    view=s.snapshot()
    assert view['resource']['status']=='blocked_source'
    assert 'ceiling_interval_mM' not in view['resource'] and 'next_request' not in view['resource']
    assert s.computations==count
    s.deliver(s.event('context-stale','context_selection',{'anatomical_label':'liver'}))
    assert s.audit[-1]['outbound']['next_request'] is None
    assert s.snapshot()['resource']['status']=='blocked_source'
    kernel.unlink()
    assert s.snapshot()['resource']['status']=='blocked_source'
    before=deepcopy(s.__dict__)
    try:s.deliver(s.event('question-missing-source','question',{'target_extent_mM':'.7'}))
    except FileNotFoundError:pass
    else:raise AssertionError('Missing source unexpectedly computed')
    assert s.__dict__==before
finally:
    kernel.write_bytes(original)
assert sha(kernel.read_bytes())==KERNEL_SHA
passed('actual changed or missing source blocks at view time',
       {'changed_source_suppresses_number_and_request':True,'missing_source_blocks':True,
        'source_missing_computation_failure_atomic':True,'owned_source_restored':True})

s=baseline();s.deliver(s.event('invalidate','source_invalidated',{'asset':'geometry'}))
assert s.snapshot()['resource']['status']=='blocked_source'
s.deliver(s.event('context-after-invalidated','context_selection',{'anatomical_label':'liver'}))
assert s.snapshot()['resource']['status']=='blocked_source' and s.audit[-1]['outbound']['next_request'] is None
passed('explicit invalidation stays blocked even with original bytes present',
       {'requires_new_reviewed_binding':True})

# Every supplied successful scientific view remains a synthetic candidate companion.
trace=json.loads((ROOT/'run/results/roundtrip.json').read_text())
for event in trace['events']:
    view=event['after']['resource']
    if 'ceiling_interval_mM' in view:
        assert view['evidence']=='synthetic'
        assert view['integration_status']=='candidate_requires_coordinator_acceptance'
        assert view['model_sha256']==KERNEL_SHA
        assert view['mathematical_parent']=='GDL-BIOLOGY-WIDTHS@0.2.1'
        assert view['premises']['status']=='stipulated_for_synthetic_rehearsal'
        assert view['next_request']['state']=='proposal_not_experimental_command'
passed('operational companion never self-admits empirical or deployed state',
       {'scientific_parent':'GDL-BIOLOGY-WIDTHS@0.2.1','candidate_scope_preserved':True,
        'review_accept_control_rejected':True})

manifest=json.loads((ROOT/'frozen/manifest.json').read_text())['files']
source=Path(json.loads((ROOT/'identity-receipt.json').read_text())['source'])
for folder in [ROOT/'frozen',ROOT/'run',source]:
    assert all(sha((folder/p).read_bytes())==h for p,h in manifest.items())
receipt={'checked_at':datetime.now(timezone.utc).isoformat(),'all_passed':True,
         'check_groups':len(records),'checks':records,'frozen_source_and_replay_restored':True,
         'scope':'Local operational rehearsal and current vendored source binding, not a trusted service, general dependency graph or UI/browser/export renderer'}
(ROOT/'independent-probes.json').write_text(json.dumps(serial(receipt),indent=2)+'\n')
print(json.dumps({'all_passed':True,'check_groups':len(records)}))
