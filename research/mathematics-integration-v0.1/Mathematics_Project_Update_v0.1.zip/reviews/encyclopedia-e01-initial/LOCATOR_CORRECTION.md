# Source locator correction

The inverse-action deduplication in the pinned `explorer.py` (SHA256 `4707e39887bf64221ebd5c94f14161a23b619845b4d405cd6f3ad188cd5bc58e`) is at **lines 87–90**, not lines 92–95 as stated in REVIEW.md. The reproducer, findings, source bindings and requested correction are unchanged. This separate note preserves the already handed-off report and receipt hashes.
