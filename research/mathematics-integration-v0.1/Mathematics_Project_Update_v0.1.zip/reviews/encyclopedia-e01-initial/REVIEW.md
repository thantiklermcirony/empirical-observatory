# E01 mathematical domain review

12 September 2026. **Mathematical explanations and ordinary corrected cases are sound; one candidate-grouping correction remains before acceptance of the complete E01 status logic.** This is a review of the pinned working snapshot, not a frozen encyclopedia release or its UI/export implementation.

Reviewed `VIEW_SPEC.md`, `explorer.py:make_e01`, `domain_worker.py:e01`, supporting `content.py`, the pinned engine/uhl inputs and `validation/cases/E01-baseline.json`. Ten source files were copied into a mathematics-owned snapshot before execution and hashed again afterward; none changed during the review. Exact bindings are in `receipt.json`.

## Checks that pass

- The complete three-candidate comparison menu is explicitly separated from the continuously parameterized UHL family and the unrestricted class of interval-preserving maps. Eighty-one plotted inputs are samples, not a global proof or a count of possible worlds.
- The original input box is retained: |x|<=1/4, |u|<=1/3, |v|<=1/2. All six signed boundaries execute, and six just-outside cases are rejected.
- Independent fraction arithmetic gives T_v(T_u(1/4))=9/11 at u=1/3,v=1/2; P(1/4)=79/256 and P(P(1/4))=25393681/67108864 for P(x)=x(5-x²)/4. These match the worker and saved baseline.
- The global cubic argument is correct and properly distinguished from the executed box: P'(x)=(5-3x²)/4>=1/2 on [-1,1], so P is increasing and preserves the interval with fixed endpoints. It fixes zero but differs from the identity; a nondegenerate projective map fixing three distinct points is the identity, so P is a valid nonprojective counterexample. The same distinction applies to its repeated operation.
- T preserves the open interval because 1-T²=(1-x²)(1-u²)/(1+xu)²>0 and its denominator is positive. Endpoint-only observation grouping loses the interior response and cannot establish a unique operation law.
- The optional artanh coordinate is an invertible relabeling on the interior. It supplies no physical time, spatial curvature, mechanism or experimental evidence. The entry states this correctly.
- The exact-zero fixture x=1/4,u=-1/4,v=0 leaves the projective candidate when its prediction is available. With projectivity or calibration removed, it is now unresolved instead of being excluded. The cubic fixture selects the cubic among this finite menu only.
- Probability-of-proposition fields remain null. Synthetic fixtures and imported premises are not presented as empirical validation. Missing physical applicability is explicit.

## Remaining correction: inverse-action grouping loses an unavailable alias

**Priority: high for the finite-family status logic.** `explorer.py:92–95` merges the projective candidate into the identity whenever u+v=0, without preserving the projective alias's unavailable prediction/dependencies. The identity member then has an available output and empty dependencies. `partition_candidates` never sees the unresolved projective alias.

Reproduce with:

```json
{
  "entry_id": "E01",
  "x": "1/4",
  "u": "1/4",
  "v": "-1/4",
  "evidence": "synthetic-negative",
  "missing": ["projective"]
}
```

Actual: `E01-composition` is unresolved, but `E01-finite-family` reports canonical_count=2, survivors=[], undecided=[], status=`inconsistent`. The same defect occurs with `source_revision="unreviewed-example"` instead of premise removal. The literal identity and polynomial predictions do not match zero; the source/premise-withheld projective prediction must still remain undecided under the entry's chosen withdrawal semantics.

The algebraic identity T_-u o T_u=I is valid when the declared projective operation is available. It must not erase the dependency of an interpretation that the same scenario explicitly withholds. This is the already corrected missing-information-versus-refutation issue re-entering through deduplication.

Keep prediction/status dependencies for every original candidate or alias before grouping. A display grouping may merge equivalent available maps, but cannot discard an unresolved member. Alternatively, defer the merge when its required interpretation is unavailable and label known versus unresolved class counts separately. A claim of distinct map count should not silently assume an unavailable equivalence proof. Require family inconsistency only when every original covered candidate has actually been ruled out.

Retain regressions for inverse u+v=0 with projectivity, calibration and source withdrawal; both incompatible and compatible synthetic fixtures; ordinary noninverse zero fixture; and the fully admitted inverse case. Preserve the valid two-map deduplication when its operation equivalence is admitted.

## Scope and disposition

Nine scenario bundles, six boundary acceptances and six outside-box rejections were executed in the owned snapshot. The review did not modify the encyclopedia source, inspect its browser rendering, recheck PNG races, extend the shared engine or audit E03/E04. The reviewed proofs and numerical examples do not require new geometry work. Return a corrected frozen candidate for a focused recheck of alias/prediction-state preservation.
