# Mathematics branch — complete project intake

This index reconciles all completed mathematics work as of12September2026. Two releases are already public; two additional releases and the bounded reviews are supplied here for the Observatory project. Original scientific archives and review records are byte-identical. The index does not turn a candidate into an accepted result or claim a hosted capability has been deployed.

| Contribution | State | Source |
|---|---|---|
| Executable Theory Atlas | Accepted and public | [Published source](https://github.com/thantiklermcirony/empirical-architecture/tree/e97067547acde077f32237bac2803e4e66189bbd/research/theory-atlas-v0.1) |
| Geometry Discovery Lab0.2.1 | Accepted and public | [Published source](https://github.com/thantiklermcirony/empirical-observatory/tree/bf002744364057e50a02ad6ede9ba1985c8e1b31/research/geometry-discovery-v0.2.1) |
| Observatory Integration Companion0.1 | Accepted local operational reference | [Complete source archive](releases/Observatory_Integration_v0.1.zip); [independent acceptance](reviews/integration-companion/ACCEPTANCE.md) |
| Recovery Challenge Lab0.1 | Local scientific review candidate | [Complete source archive](releases/Recovery_Challenge_Lab_v0.1.zip); [next physical experiment](RECOVERY_NEXT_EXPERIMENT.md) |
| Encyclopedia E01 reviews | Targeted successor correction passes | [Review](reviews/encyclopedia-e01-successor/REVIEW.md); initial findings and erratum retained alongside |
| Quantum Discrimination mathematical review | Requested mathematical scope passes | [Review](reviews/quantum-discrimination/REVIEW.md) |

The accepted integration companion demonstrates the observation-to-correction path using the pinned geometry kernel. Recovery extends the mathematics to a continuous family of relaxation modes and an explicit pulse response. These remain synthetic/model-conditional contributions until a domain-owned empirical observation model is admitted.

![Recovery investigation](recovery-investigation.png)

## Add this to the project

Integration owns the shared project and publication. Suggested destination: `research/mathematics/`. Copy the contents of this directory there, retaining the complete archives, review histories, index and manifest. Add one link from the existing project overview and capability/release index. Do not overwrite or re-upload the two already-public release directories. An example overview entry is in `PROJECT_INDEX_ENTRY.md`.

Extract the new archives into separate owned source directories when reviewing or wiring a runtime capability. Each includes its own manifest and reproduction instructions. The integration companion is accepted only as the documented operational reference; the new Recovery solver requires an independent review before activation. A candidate source can be made discoverable with its status visible. Reuse the existing14-field inquiry contract and the coordinator's trusted runtime; this intake introduces no replacement schema or dispatcher.

Some immutable review records retain dated local-path locators. Those paths are provenance, not runtime dependencies and not portable hyperlinks. `CONTRIBUTIONS.json` and this page supply the portable navigation. No credentials or externally acquired experimental dataset is included.

The initial E01 report has a preserved locator error; `reviews/encyclopedia-e01-initial/LOCATOR_CORRECTION.md` identifies the correct line. Keep that erratum with the historical report. Geometry0.2's correction history is already included in the public0.2.1 source. Development scratch, duplicate replays and temporary working copies are not new releases.

Run `python -B verify.py` for this intake's integrity. The original packages retain their separate scientific validation and review boundaries. `MANIFEST.json` binds every supplied file. Public commit and hosted release receipts must be recorded by the actual uploader/deployer after the update; no such completion is asserted by this intake.
