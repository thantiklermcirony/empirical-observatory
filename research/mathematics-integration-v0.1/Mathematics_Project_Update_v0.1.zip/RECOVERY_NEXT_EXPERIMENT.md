# The next experiment must be able to disagree

The proposed next step is one domain-owned recovery protocol with independently calibrated observations. No experiment has been run or scheduled by this release. This request follows the mathematics investigation and does not replace biology's existing NADPH assay request.

**Question:** Does one selected physical system admit a positive stationary mixture with a linear normalized residual, and does the same excitation profile predict its response to a second small pulse?

**First owner:** biology for a cellular implementation, or quantum for an optical/relaxation implementation. Each must choose the actual preparation and observable. The common equations alone do not connect an optical signal to a metabolite, organism or organ.

The domain owner should return one supported observation model: raw signal and units; baseline and normalization; calibration and uncertainty; physical τ and acquisition timing; experimental unit and replicate structure; preparation/reset; stationary period; disturbance from reading; and a justified small-pulse map. If sampling is destructive, the observation at 2τ and the later response cannot come from the same destroyed specimen. A matched-cohort design needs a separate justification for transfer and uncertainty.

The mathematics runner currently treats errors as deterministic enclosures. Real confidence statements require a prespecified likelihood or a simultaneous coverage construction for the actual replicate structure. An exact normalized first reading is a synthetic convenience. A real uncertain baseline may use the conservative moment-box enclosure, but the experiment planner must be extended and independently checked before inheriting a minimax guarantee. No sampling frequency or sample-size recommendation is made without this information.

## A reviewable protocol

1. Use calibration/training preparations to choose τ, support restrictions, pulse amplitude, candidate readouts and a physically meaningful target. Check linearity, signs and sensitivity independently where possible.
2. Fix the uncertainty construction, analysis horizon, repeat count, exclusion rules and declared alternatives before collecting evaluation data. Preserve failed runs and denominators.
3. Record the first and second residual observations with raw data, calibration and preparation IDs. Construct and commit the prediction for the response one interval after the pulse, including every premise and its status.
4. Collect the separate evaluation response under the recorded pulse profile. Compare it with the prediction using the declared uncertainty model. The software record can prevent accidental reuse; external provenance establishes actual chronology and independence.
5. If incompatible, investigate calibration drift, negative/signed modes, nonstationarity, disturbance and changed pulse excitation separately. An incompatibility rejects their conjunction. It does not uniquely identify which premise failed or establish a quantum, biological or adaptive mechanism.

## Signals returned to the Observatory

| Receiver | Concrete incoming result | Useful outgoing action |
|---|---|---|
| Mathematics | Calibrated readout map, uncertainty and accessible operations | Bound, extremal compatible states, or an explicit unsupported-model request |
| Biology | A target response interval and its pulse/resource dependencies | Choose a cellular protocol or explain which premises fail; keep resource and survival meanings separate |
| Quantum | A scoped positive-mixture comparator and a possible violation | Test the observation map; signed/oscillatory behavior alone does not prove quantum mechanics |
| Integration | Source-bound prediction, evaluation, correction and dependency IDs | Route review, retain history and invalidate only affected descendants |
| Encyclopedia/anatomy | A question, alternative futures, experiment request and revised answer | Explain what changed and return the reader's next question; navigation supplies no evidence |

The first success criterion is a fully traceable disagreement or agreement with a committed prediction on a supported observation map. Agreement leaves other mechanisms open. A failed prediction is useful when it narrows a specific next test.

## Where the branch grows after that

Extend the exact low-order solver to certified higher-moment and uncertain-baseline design only as a domain investigation needs it. Couple a proposed pulse to an independently admitted resource ledger before optimizing it. Add continuous-time leaky functionals through an explicit map from measured residuals. Use declared alternative mechanisms to choose the next intervention after a failure. Each extension should return a new calculation and a decisive test to its parent inquiry; adding connections alone is not the objective.
