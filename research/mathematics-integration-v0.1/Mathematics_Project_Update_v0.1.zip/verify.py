from pathlib import Path
import hashlib,json,zipfile
r=Path(__file__).resolve().parent
m=json.loads((r/'MANIFEST.json').read_text())
for n,h in m['files'].items():
 p=(r/n).resolve()
 assert p.is_relative_to(r) and p.is_file(),n
 assert hashlib.sha256(p.read_bytes()).hexdigest()==h,n
for p in (r/'releases').glob('*.zip'):
 with zipfile.ZipFile(p) as z: assert z.testzip() is None
print(json.dumps({'verified_files':len(m['files']),'archive_crc':'pass','scope':'integrity only'}))
