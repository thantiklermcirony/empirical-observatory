## Mathematics branch

[Complete mathematics source and review index](research/mathematics/README.md): executable theory atlas, Geometry Discovery Lab, the independently accepted integration companion, Recovery Challenge Lab candidate, and targeted encyclopedia/quantum reviews. Each item retains its accepted, candidate, published and hosted status. The new integration and recovery source archives are complete and reproducible; empirical and hosted activation claims require their respective review and deployment receipts.
