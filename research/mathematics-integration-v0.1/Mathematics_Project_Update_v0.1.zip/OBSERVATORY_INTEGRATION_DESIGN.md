# One continuous inquiry across the Observatory

**Every useful signal should enter an identifiable inquiry, change only what it justifies, and leave behind a clear result or next action.** The user should be able to move from an organ, mechanism, equation or unanswered question into the same investigation without reconstructing its context.

The mathematical branch's contribution is to make uncertainty operational: compatible states, preserved structure, counterexamples, limits on inference and measurements that distinguish alternatives. Domain branches supply the physical meaning and models. Integration supplies trusted execution and currentness. The encyclopedia and anatomy interfaces make the combined inquiry understandable and return new questions to the branches.

## The full loop

```mermaid
flowchart LR
  U[User question or selected context] --> I[Shared inquiry and target]
  S[Measurements and source material] --> D[Domain interpretation and calibration]
  I --> D
  D --> B[Biology mechanisms and resource models]
  D --> Q[Quantum mechanisms and instruments]
  B --> M[Mathematics: possibilities, witnesses, design]
  Q --> M
  M --> R[Results with assumptions and provenance]
  B --> R
  Q --> R
  R --> C[Integration: reviewed bindings and execution status]
  C --> V[Encyclopedia and anatomy views]
  V --> N[Specific next observation or derivation]
  N --> D
  V --> U
  X[Corrections, changed sources and review holds] --> C
  C --> Y[Refresh affected results and requests]
  Y --> V
```

This is an integration design. The current executable companion rehearses the mathematics/resource path and selected failure transitions locally. It does not claim the entire graph has been connected to the deployed Site.

## Signals coming in

| Signal | What it means | First owner | What it may change |
|---|---|---|---|
| A question or changed target | The outcome the user wants to understand or decide | Encyclopedia/user interface, routed by integration | Which results and measurements are relevant |
| Anatomy selection or a navigation change | The user's current context | Biology/anatomy interface | The displayed context; it supplies no organ measurement or scientific premise |
| A measured value, trace or imported dataset | A potential observation with a particular unit, preparation, time and instrument | Relevant domain lead | Compatible states only after the observation map and evidence scope are established |
| A proposed intervention | A physical operation that may change the state, consume resources or disturb a preparation | Domain lead | A new scenario and its descendants, using an admitted dynamics/instrument model |
| A model or source revision | A different computational/scientific input | Source owner and integration | Currentness of dependent results; historical versions remain inspectable |
| A review decision or discovered numerical failure | A change in which result may be used | Independent review and integration | Exactly the affected claims, displays and queued requests |
| A note, analogy or hypothesis | An idea worth investigating | Any branch | The research queue, without becoming evidence merely through repetition |

An observation needs an identity beyond its number: quantity meaning, units, experimental unit, preparation, physical time, uncertainty, method/calibration, source revision and whether it is synthetic or empirical. A result needs its model and premise dependencies. An operational message needs a delivery ID and the inquiry revision it expects to update. These extend the surrounding operational record; they do not replace the existing 14-field scientific contract.

## Signals going out

The reader should receive the answer that the admitted model can support, its scope, the compatible alternatives, why it changed, and the most useful next question. The receiving branch should get a concrete target, parent result and source version, required observation or derivation, expected discriminating outcome and acceptance criteria.

| Destination | Useful outgoing signal |
|---|---|
| Biology | Which absolute stock or time-resolved assay could resolve a specific reserve or mechanism ambiguity; required units, matched preparation and interval/noise model |
| Quantum | Which preparation/readout or comparator would distinguish the stated mechanisms; full outcome accounting, accessible axis and detector assumptions |
| Mathematics | A scoped claim to prove, a counterexample search, an observation fibre, a target and an explicit allowed operation menu |
| Integration | Immutable package/result IDs, changed dependencies, test/review receipt, owner and actual local/public/deployed state |
| Encyclopedia | A presentable result with contextual vocabulary, remaining possibilities, coverage limits and the next research request |
| Anatomy interface | Structure context plus the actual linked signal/model provenance; unresolved organ/species transfers remain visible |

The prime-sieve, UHL/Aczel, temporal architecture, recovery/IDA, adaptation and state-sufficiency work use this same inquiry loop while keeping their own solver and operation semantics. Discrete arithmetic should not be forced into a convex geometry adapter, and a common visual shape should not imply physical equivalence.

## Keep the logic attached to the signal

The pipeline must carry meaning through every transformation. A dimensionless reduced fraction and a dimensionless quantum yield are different quantities. A concentration, amount and rate are different quantities. A GSH molecular concentration is not a GSSG-equivalent concentration without the stoichiometric convention. Unit compatibility alone is insufficient.

For a legitimate concentration conversion, 1 uM = .001 mM. A legitimate uM/s rate becomes .06 mM/min; its time coordinate also changes from seconds to minutes. Neither conversion supplies a missing species map. An optical absorbance trace is not a concentration until its calibration exists. An infinite-time product probability is not an instantaneous flux. The local executable tests stock-unit conversion and rejects optical/rate inputs as stock observations; the physical quantum-to-biological conversion remains with its domain owners.

Observation refinement and state evolution must be separate operations. Two valid observations of the same matched state can intersect its possibilities. A later observation after an intervention requires a propagation model and a clock. A destructive assay cannot be followed as though its original specimen survived; justified matched preparations are different experimental units.

Keep three independent kinds of status visible: what the mathematics or model establishes, whether its evidence is synthetic or empirical, and whether the software release is reviewed/current/published/deployed. “The calculation ran” answers none of the other questions. A correct theorem does not rescue a faulty numerical implementation; a published package does not create calibration.

Unavailable predictions must also remain distinct from contradicted predictions. Withdrawing a premise can make one candidate unresolved without excluding it. A finite family has no surviving possibilities only when every covered candidate has actually been ruled out; an unevaluable candidate is still missing information. This distinction applies to both mathematical model menus and biological/quantum alternatives.

## Make normal operations predictable

1. Keep one inquiry identity and a revision history as the user moves between views. Changes in presentation need not rerun the solver.
2. Apply each accepted input atomically. A rejected unit, mismatched preparation or failed computation must leave the prior valid state intact and explain the problem.
3. Give each delivered signal a stable ID. A retry acknowledges the same delivery without counting it twice; reusing the ID with changed content is a conflict.
4. Bind updates to an expected inquiry revision. An old tab or late worker cannot overwrite a newer scenario silently.
5. Preserve corrections as new events that name what they replace. Superseded observations leave the active calculation, remain in history, and can retract conclusions.
6. Cache only by the complete relevant input/model/operation identity. An appearance change can reuse the result; a changed source, time, uncertainty model or premise cannot.
7. Route unsupported work to one named owner with the missing input and completion criterion. Stop proposal loops that repeat the same unresolved request without new evidence.
8. Refresh dependent views and queued research requests when a result is held, corrected or superseded. Preserve unaffected branches and historical records.
9. Bind asynchronous plots and downloads to one captured scenario snapshot. The data, filename, source/version and visible scenario must be captured together before awaiting rendering, so a later click cannot mislabel an earlier image.

The rehearsal implements items 1–5 and the local dependency cases in item 8. It supplies a deterministic, replayable trace; it is not a durable queue service, authentication layer, distributed cache or complete dependency scheduler. Those operational services belong in the coordinator's existing execution path.

## A concrete round-trip already executed

The encyclopedia asks whether a 0.60 mM GPx extent target can be excluded by a necessary resource ceiling. The user navigates to a liver context; that action changes no model premise. Biology supplies explicitly synthetic, matched-preparation readouts to the mathematics port:

| Active observations | Compatible ceiling range, mM | What changes |
|---|---:|---|
| q=.99; model stock ranges retained | [.159, .635] | The target is not excluded |
| Add total-pool interval [.98,1] mM | [.5451, .635] | Compatible states narrow; upper ceiling is unchanged |
| Add NADPH interval [9,11] uM | [.5541, .566] | The target becomes excluded under the stipulated ledger |
| Correct that NADPH signal to [60,80] uM | [.6051, .635] | The earlier signal is superseded and the exclusion is retracted |

These ranges describe possible *ceilings*, not achieved clearance. The lowest ceiling is not a guaranteed lower bound on reaction extent or survival. The hypotheses include fixed common volume, complete stoichiometric accounting, nonnegative reserve and an admitted source ceiling.

The port returns both a view update for the encyclopedia/anatomy interface and a proposed next assay-design request to biology. The 9–11 uM input is delivered twice in the test; the second delivery does not change the revision, compute count or scientific answer. A simulated quantum review hold changes the quantum connection but leaves the independent resource result intact. A geometry-source invalidation suppresses the dependent resource answer and its follow-up proposal.

## Integrate in a useful order

| Next delivery | Owner | Completion criterion |
|---|---|---|
| Corrected Geometry 0.2.1 kernel — independent review completed | Integration review | Accepted locally on 12 September 2026: 28 supplied tests, 21 independent groups and 750 duplicate/rescaling checks; review snapshot included |
| Consume one mathematics round-trip in the existing question/encyclopedia view | Integration + encyclopedia | Reader can see active observations, compatible ceilings, a correction and the retracted conclusion from the same parent inquiry |
| Wire anatomy context to that same inquiry | Biology + integration | Selection carries structure identity without altering evidence; source and preparation context remain visible |
| Connect a reviewed domain result to the generic geometry target | Mathematics + domain owner | Real emitted result IDs and observation maps replace the authored adapter example; source changes invalidate affected descendants |
| Add the domain observation-admission route | Biology/quantum + integration | Unreviewed imports cannot masquerade as calibrated measurements; accepted input returns to the original inquiry |
| Complete release and public-state reconciliation | Integration | Local, accepted, GitHub and deployed revisions are separately verified and discoverable |

The programme should judge smooth operation by successful round-trips, stale answers prevented, correction-to-view latency, reproducible handoffs and useful requests resolved. More events and more queued questions are not themselves progress.

The long-term outcome is an Observatory where every branch can both listen and contribute: new evidence tightens what is possible, mathematics makes the next uncertainty explicit, the interface helps the user choose the next investigation, and the result returns with its meaning intact.
