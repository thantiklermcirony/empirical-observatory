"""Fixed integration examples using accepted code, retaining the 14-field inquiry.

This is a proposed mapping adapter, not a new common execution envelope.
"""
from pathlib import Path
from copy import deepcopy
from fractions import Fraction as F
import argparse,json,hashlib,sys

ROOT=Path(__file__).resolve().parent
for relative,expected in json.loads((ROOT/'INPUT_BINDINGS.json').read_text()).items():
    if hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()!=expected:
        raise ValueError('Changed pinned capability input before import: '+relative)
for p in ['inputs/companion','inputs/engine','inputs/gdl']:sys.path.insert(0,str(ROOT/p))
from ports import Session,serial
from vendor.geometry import ball_fibre
import engine,obligations

FIELDS=set('identity question system observer quantities operations constraints mechanism premises execution results contrast next_question provenance'.split())
AVAILABLE=set().union(*obligations.REQUIRED.values())-{'BIO-ORGAN-MAP','BIO-EMPIRICAL-RECEIPT'}


def read(name):return json.loads((ROOT/name).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(serial(x),sort_keys=True,indent=2)+'\n',encoding='utf-8')
def verify_inputs():
    for rel,h in read('INPUT_BINDINGS.json').items():
        if sha(ROOT/rel)!=h:raise ValueError('Changed pinned capability input: '+rel)


def observation(session,id,quantity,interval,unit='mM',**extra):
    return session.event(id,'observation',dict(quantity=quantity,interval=interval,unit=unit,origin='synthetic',preparation_time_min=0,**extra))


def package(kind,id,revision,parent,raw,results,missing=()):
    p=read('templates/'+kind+'.json');assert set(p)==FIELDS
    p['identity']={'id':id,'version':'mapping-0.1','revision':revision,'parent':parent,'producing_task_id':'mathematics','created_date':'2026-09-12'}
    p['execution']={'entrypoints':'CAPABILITIES.json','mapping_status':'proposed_adapter_not_independently_admitted',
                    'pinned_input_sha256':read('INPUT_BINDINGS.json'),'actual_receipt':raw,
                    'command':['python','-B','reproduce.py','--out','REPLAY_DIRECTORY'],
                    'removed_premises':list(missing),'mapping_code_sha256':sha(Path(__file__))}
    p['results']=results
    p['provenance']={'evidence':'synthetic','source_pins':'INPUT_BINDINGS.json','accepted_parent_receipts':'reviews/',
                     'central_admission':'owned by integration; not inferred from payload labels','public_deployed_state':'not established by these examples',
                     'mapping_scope':'source-bound local mapping; parent acceptance does not accept this new adapter'}
    p['contrast']={'removed_premises':list(missing),'history':'receipt retains original operation and correction identities'}
    p['next_question']={'owner':'integration','request':'Bind this capability to the common inquiry revision and trusted premise/source state; keep physical transfer gaps explicit'}
    if kind=='resource':
        p['premises']=[{'id':x,'status':'missing' if x in missing else 'assumed','source':'synthetic fixture / accepted GDL obligation map'} for x in sorted(AVAILABLE) if not x.startswith('Q-') and x not in {'M-BALL','M-AFFINE','M-READOUT'}]
    elif kind=='uhl':
        p['premises']=[{'id':x,**v} for x,v in raw['premises'].items()]
    assert set(p)==FIELDS
    return p


def resource(session,missing=(),inquiry_revision=None):
    raw=deepcopy(session.snapshot());gates=obligations.report(AVAILABLE-set(missing));v=raw['resource']
    usable=v.get('status')=='conditional_local_fixture'
    vals=[]
    for id,gate,scope in [('MAT-RESOURCE-EXPRESSION','abstract_resource_width','Value of the stipulated algebraic expression only; physical interpretation separately gated'),
                          ('MAT-GPX-CEILING','gpx_extent_upper_bound','Necessary GPx extent ceiling; not achieved extent or survival'),
                          ('MAT-NEXT-ASSAY','biological_measurement_proposal','Proposed assay design; no physical experiment commanded')]:
        g=gates[gate];ok=usable and g['status']=='conditional_in_scope'
        value=(v['next_request'] if id=='MAT-NEXT-ASSAY' else {'ceiling_interval_mM':v['ceiling_interval_mM'],'width_mM':v['width_mM'],**({'target_excluded':v['target_excluded']} if id=='MAT-GPX-CEILING' else {})}) if ok else None
        vals.append({'id':id,'result_kind':'formal_under_premises','status':'established_in_scope' if ok else 'unresolved',
                     'value':value,'unit':'mM' if id!='MAT-NEXT-ASSAY' else 'proposal','depends_on':g['depends_on'],'blocked_by':g['blocked_by'],
                     'scope':scope,'evidence':'synthetic'})
    raw={'companion_snapshot':raw,'obligation_report':gates,'original_event_log':deepcopy(session.audit),'superseded_observations':deepcopy(session.superseded)}
    p=package('resource','MAT-RESOURCE-INTEGRATION',session.revision if inquiry_revision is None else inquiry_revision,'GDL-BIOLOGY-WIDTHS@0.2.1 / companion0.1.0',raw,vals,missing)
    if missing:p['provenance']['premise_transition']={'origin':'authored integration fixture','companion_revision':session.revision,'common_envelope_event':'not implemented here; root must create a new durable premise-withdrawal event','removed':list(missing)}
    p['observer']['active_observations']=serial(session.observations)
    return p


def uhl(revision,values,missing=(),replaces=None):
    m=read('inputs/engine/uhl.json')
    for step in m['steps']:
        if step['id']=='example':step['values']=values
    receipt=engine.execute(m,missing)
    results=[]
    for step in receipt['steps']:
        if step['id'] in ['composition','example','alternative_not_identity']:
            status={'verified':'established_in_scope','blocked':'unresolved','unresolved':'unresolved','invalid':'execution_error','refuted':'not_supported'}[step['status']]
            results.append({'id':'MAT-UHL-'+step['id'],'result_kind':'formal_under_premises','status':status,'unit':'1',
                            'value':step.get('value',step.get('equal',step.get('enclosure'))) if status=='established_in_scope' else None,
                            'depends_on':step['premises'],'blocked_by':step.get('missing_premises',[]),
                            'scope':'Original authored UHL example within the pinned conservative boxes; no physical law inferred'})
    p=package('uhl','MAT-UHL-INTEGRATION',revision,'uhl_verb_composition / engine0.2',receipt,results,missing)
    p['observer']['value_bindings']=values
    p['provenance']['correction']={'delivery_id':'uhl-values-'+str(revision),'replaces':replaces,'meaning':'authored parameter correction; central event envelope owns durable identity'}
    return p


def ball_case(name,matrix,readout,target,offset=0):
    args=dict(matrix=matrix,readout=readout,target=target,offset=offset)
    try:
        val=ball_fibre(**args);status='established_in_scope';error=None
    except (ValueError,ArithmeticError) as e:
        val=None;status='unresolved';error={'type':type(e).__name__,'message':str(e),'scope':'numerical/conditioning decline, not an empirical refutation'}
    result={'id':'MAT-BALL-TARGET','result_kind':'formal_under_premises','status':status,'value':val,'unit':'declared affine target unit',
            'depends_on':['M-BALL','M-AFFINE','M-READOUT'],'error':error}
    p=package('ball','MAT-BALL-'+name,0,'Geometry Discovery Lab0.2.1',{'args':args,'error':error},[result])
    p['system']={'entities':'abstract vector state r','boundary':'||r||<=1 in declared Euclidean coordinates','physical_transfer':'not specified; no quantum mechanism inferred'}
    p['observer']={'map':'M r=y','args':args,'noise':'exact finite input coordinates, no empirical tolerance inferred'}
    p['premises']=[{'id':x,'status':'assumed','source':'stipulated abstract geometry'} for x in ['M-BALL','M-AFFINE','M-READOUT']]
    return p


def main(out):
    verify_inputs();out=Path(out);s=Session()
    s.deliver(s.event('question','question',{'target_extent_mM':'3/5'}))
    s.deliver(observation(s,'q-1','q',['99/100','99/100'],'1'))
    s.deliver(observation(s,'T-1','T',['49/50','1']))
    low=observation(s,'N-1','N',['9','11'],'uM');s.deliver(low)
    examples={'resource-normal':resource(s)}
    s.deliver(observation(s,'N-2','N',['60','80'],'uM',replaces='N-1'))
    examples['resource-corrected']=resource(s)
    old=deepcopy(s.__dict__);duplicate=s.deliver(low);assert s.__dict__==old
    examples['resource-missing-volume']=resource(s,['BIO-VOLUME'],inquiry_revision=6)
    examples['resource-missing-ledger']=resource(s,['BIO-LEDGER'],inquiry_revision=7)
    normal=next(x for x in examples['resource-normal']['results'] if x['id']=='MAT-GPX-CEILING')
    corrected=next(x for x in examples['resource-corrected']['results'] if x['id']=='MAT-GPX-CEILING')
    assert normal['value']['ceiling_interval_mM']==['5541/10000','283/500'] and normal['value']['target_excluded']
    assert corrected['value']['ceiling_interval_mM']==['6051/10000','127/200'] and not corrected['value']['target_excluded']
    for key in ['resource-missing-volume','resource-missing-ledger']:
        assert examples[key]['results'][0]['value'] is not None
        assert all(r['value'] is None for r in examples[key]['results'][1:])
    examples['uhl-normal']=uhl(0,{'x':'1/4','u':'1/3','v':'1/2'})
    examples['uhl-corrected']=uhl(1,{'x':'1/4','u':'-1/4','v':'0'},replaces='uhl-values-0')
    examples['uhl-missing-calibration']=uhl(2,{'x':'1/4','u':'-1/4','v':'0'},missing=['calibration'])
    examples['uhl-outside-reviewed-box']=uhl(3,{'x':'1/2','u':'1/3','v':'1/2'})
    get=lambda k,id:next(x for x in examples[k]['results'] if x['id']==id)
    assert get('uhl-normal','MAT-UHL-example')['value']=='9/11'
    assert get('uhl-corrected','MAT-UHL-example')['value']=='0'
    assert get('uhl-missing-calibration','MAT-UHL-example')['value'] is None
    assert get('uhl-missing-calibration','MAT-UHL-alternative_not_identity')['status']=='established_in_scope'
    assert get('uhl-outside-reviewed-box','MAT-UHL-example')['status']=='execution_error'
    examples['ball-normal']=ball_case('normal',[[0,0,1]],[0],[.25,0,0],.5)
    examples['ball-conditioning-decline']=ball_case('conditioning-decline',[[1,0],[1,1e-13]],[0,0],[0,1])
    examples['ball-offset-decline']=ball_case('offset-decline',[],[],[1e-30,0],1)
    assert examples['ball-normal']['results'][0]['value']['width']==.5
    for k in ['ball-conditioning-decline','ball-offset-decline']:
        assert examples[k]['results'][0]['status']=='unresolved' and examples[k]['results'][0]['value'] is None
    for name,p in examples.items():dump(out/(name+'.json'),p)
    summary={'examples':len(examples),'all_checks_pass':True,'scientific_fields':14,'duplicate_ack':duplicate,
             'correction_id':'N-2','replaces':'N-1','normal_resource_revision':examples['resource-normal']['identity']['revision'],
             'corrected_resource_revision':examples['resource-corrected']['identity']['revision'],
             'proposed_mapping_not_admitted':True,'inputs_unchanged':True}
    verify_inputs();dump(out/'validation.json',summary);print(json.dumps(summary))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--out',required=True);args=parser.parse_args();main(args.out)
