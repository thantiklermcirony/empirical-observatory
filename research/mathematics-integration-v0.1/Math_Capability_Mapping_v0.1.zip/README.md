# Accepted mathematics capabilities — integration mapping 0.1

This package answers the coordinator's whole-system audit request. It supplies exact entrypoints, types, source bindings and executed examples using accepted GDL0.2.1, Integration Companion0.1 and inquiry engine0.2/UHL algebra. **The mapping adapter itself is new and awaits integration review.** Recovery Challenge0.1 remains a separate candidate and is not dispatched here.

Run from this directory with Python3.12 and NumPy (tested with NumPy2.3.5):

```text
python -B reproduce.py --out ../math-capability-replay
```

Every input is hash-checked before importing the pinned code and again after execution. Eleven14-field inquiry examples are produced, plus a validation receipt. Accepted source files are byte-identical; the wrapper does not edit them. `CAPABILITIES.json` is a contribution to the coordinator's capability catalogue, not a competing scientific contract or operational envelope. Fixed executable/argument arrays belong in the trusted worker registry, never in prompt-supplied shell text.

## Entrypoints and domains

| Capability | Actual Python entrypoint | Admitted inputs | Returned meaning |
|---|---|---|---|
| Resource observation/correction | `inputs/companion/ports.py:Session.event`, `Session.deliver`, `Session.snapshot` | Synthetic q exactly in[0,1], T/N nonnegative ordered intervals in mM/uM; one matched preparation at time0; exact rational strings/integers | Possible necessary ceiling qT/2+N+0.06 mM, width, target exclusion and proposed next assay |
| Exact resource geometry | `inputs/companion/vendor/geometry.py:resource_fibre`, `Polytope.intersect`, `Polytope.bounds`, `rank_bins` | T=G+2O in[0.2,1]mM; N in[0,0.08]mM; target qT/2+N+0.06; exact constraints and complete ordered bins | Exact rational bounds and feasible endpoint witnesses; rank complete supplied measurement menus |
| UHL algebra | `inputs/engine/engine.py:execute(manifest, missing=())` with pinned `uhl.json` | Authored projective map T(x,u)=(x+u)/(1+xu), dimensionless rational x in[-1/4,1/4], u in[-1/3,1/3], v in[-1/2,1/2] | Symbolic identity/domain receipts and exact selected point result, conditional on projectivity and fixed calibration |
| Abstract ball target | `inputs/companion/vendor/geometry.py:ball_fibre` | Finite matrix M, readout y, affine target v and offset; ||r||≤1, Mr=y, consistent dimensions; exact finite-coordinate rank must agree with numerical SVD rank | Floating analytic endpoints/witnesses plus exact rational feasibility metadata, or an explicit numerical decline |

The general polytope implementation supports an explicit bounded box in dimension1..4. This accepted resource capability specializes it to dimension2. User-supplied exact rational input should use strings or integers; never infer precision from a float or turn a ratio/rate/optical signal into a stock concentration. An empty feasible set is inconsistent; it is not zero uncertainty. The01companion only accepts an exact q, not a ratio interval. The regeneration term is fixed at0.003mM/min for20minutes and Jg=0 in this fixture, giving0.06mM; it is not a configurable biological claim.

UHL's global open-interval theorem is broader than this conservative executable box. Widening that box is a new reviewed query. Boundedness alone does not select the projective map. Physical time, spatial distance, biological action, calibration transfer and a mechanistic derivation are not outputs. The exact engine preserves original denominator guards and source binding. An `engine.execute` result marked verified is a calculation under authored premises, not trusted theorem or empirical admission.

The ball solver uses tolerance1e-10 for the consistency check between SVD rank and exact rank of the supplied finite float coordinates. It does not enlarge the ball or manufacture a null space. Its endpoints are float64 evaluations, **not outward-rounded interval certificates**. A normalized output axis is for display; retain exact projected-target coordinates if an exact additional row is required. Empirical precision, measurement accessibility and disturbance require separate domain premises. Central worker dimensions, memory, deadlines and rational-size limits must be separately enforced; this mapping does not set a generic service budget.

## Required premises and dependencies

Abstract resource arithmetic uses M-COMPACT-BOX and M-LINEAR-TARGET; the existing `abstract_resource_width` obligation also includes M-COVERING-BINS because it is a campaign result. Biological ceiling interpretation additionally needs BIO-VOLUME, BIO-LEDGER, BIO-NONNEG, BIO-SUPPLY and BIO-UNIT-MAP. Assay proposals add covering bins, BIO-MATCHED-UNIT and BIO-ASSAY-CALIBRATION. The exact existing obligation sets are emitted by `inputs/gdl/obligations.py:report` and recorded in `CAPABILITIES.json`.

The companion does not implement individual premise-withdrawal events. It stipulates its biological premises and supports only geometry/quantum review holds and source invalidation. The mapping composes its captured result with the **accepted GDL obligation report** to show the correct dependency filtering: missing volume or accounting preserves explicitly abstract algebra but withholds the biological ceiling and assay proposal. This projection is newly authored and needs review. It is not a claim that a native companion premise event or the common durable envelope already exists.

Normal/corrected resource examples retain the actual native event IDs, revisions4/5, N-2 replacing N-1, original units, superseded observations and duplicate acknowledgement. Missing-premise examples use distinct authored inquiry revisions6/7 while the original companion receipt remains revision5. The coordinator must create the corresponding common durable events and bind its trusted premise state. Do not rewrite an old result in place or promote diagnostic numbers from `execution.actual_receipt` into an active view.

UHL's native premise dependency propagation blocks its example after calibration removal while the bounded cubic counterexample remains available. Original input hashes and engine fingerprints remain in the14-field inquiry's execution section. A corrected UHL example names the prior authored value delivery. The engine itself is stateless; durable correction identity belongs to the coordinator's envelope.

## Executed examples

| File in results/ | Checked behavior |
|---|---|
| resource-normal.json | NADPH9–11uM gives[0.5541,0.566]mM; 0.60mM target excluded |
| resource-corrected.json | N-2 replaces N-1 with60–80uM; ceiling[0.6051,0.635]mM; exclusion retracted |
| resource-missing-volume.json | Biological ceiling/assay values null; explicitly abstract expression retained |
| resource-missing-ledger.json | Same selective accounting withdrawal; common premise event remains a required interface |
| uhl-normal.json | Actual pinned engine returns9/11 |
| uhl-corrected.json | u=−1/4,v=0 returns0 and retains its correction reference |
| uhl-missing-calibration.json | UHL result unresolved; independent bounded counterexample still established in its mathematical scope |
| uhl-outside-reviewed-box.json | x=1/2 yields an invalid point evaluation, mapped to execution_error; no broader inference |
| ball-normal.json | z=0, target0.5+0.25x gives[0.25,0.75] and width0.5 |
| ball-conditioning-decline.json | Rows[1,0] and[1,1e−13] have exact rank2 but numerical rank1; unresolved with no endpoints |
| ball-offset-decline.json | Nonzero target1e−30 at offset1 cannot be resolved at float64 scale; ArithmeticError becomes unresolved, not zero width |

The numerical examples preserve exception type/message. Distinguish a conditioning/precision decline from a mathematically empty domain and from malformed input. This fixed-example adapter only maps the declared decline fixtures; a generic ValueError-to-unresolved mapper would conflate those categories.

## Next interface needed from integration

Bind the common investigation ID and parent jobs around these14-field packages; map unique delivery IDs, expected revisions and replaces relationships into the durable event contract. Set trusted premise/review states outside the payload; gate active results and queued requests by their dependencies. Pin the exact Python worker entrypoints and source files, capture output and runtime/failure receipts, and specify unsupported-transfer responses.

The hosted Worker cannot import these Python/NumPy modules directly. A fixed controlled worker and result storage/API bridge are still required. Quantum is inapplicable to the first resource example until an observation/operation map is supplied; no shared word, unit or geometric resemblance establishes it. The encyclopedia should consume only the captured current projection, retaining older receipts as history.

The separate complete mathematics project intake is `outputs/mathematics-project-update-v0.1` in this branch's workspace. It covers the public atlas/geometry links, missing source archives, review histories and candidate Recovery record. This mapping provides the executable integration detail for the accepted capabilities; it does not replace that source inventory or grant publication authority.
