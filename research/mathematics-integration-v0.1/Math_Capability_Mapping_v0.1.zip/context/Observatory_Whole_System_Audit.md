# Whole-system integration audit

12 September 2026. Coordinator: integration. This is an audit and implementation contract, not a claim that the proposed architecture is deployed.

## Verdict

**The Observatory is not yet one integrated research laboratory.** It contains working scientific components, local inquiry and correction machinery, external-data collectors, a live interface, and communicating specialist agents. The complete runtime path from an arbitrary desk question through compatible branches into durable findings and a current encyclopedia does not exist yet.

The shortcoming is architectural: branch results are not consistently carried by one investigation identity, executed through one admitted capability registry, or consumed from one versioned findings projection. Publishing a package, linking a room, or posting to the agent board does not establish those connections.

## Direct verification

The live Site is saved version **29**, deployed from source **7ee8fdbc40e01b5c1fe68080481ac2071b22faee**. Deployment succeeded on 11 September at 08:07 UTC. This is distinct from newer public GitHub source releases and uncommitted local desk work.

The live `/api/question` contract calls itself a **stateless bounded numerical runner; no language model**. I executed its normal example and a combined UHL–redox–quantum question. Without interpretation confirmation, the composite question stopped with a gap. With UHL selected, it executed the same three-pass UHL example; it did not invoke biology or quantum, acquire observations, save a finding, or update an encyclopedia. The API correctly retained the broader original question as not established.

Live database inspection returned one binding, `DB`, with one user table: `daily_interest`. It is usage accounting, not scientific findings storage. The local prediction/evidence ledger is real and useful, but it is not connected to that hosted desk. Its existing prediction contracts cannot silently be used as a schema for every kind of scientific conclusion.

Evidence: [live API responses](../work/system-integration-audit/live-api-probes.json), [reproducible probe](../work/system-integration-audit/probe_live.py), [deployment and database receipt](../work/system-integration-audit/live-deployment-receipt.json). The three specialist audit reports and receipts are in `work/system-integration-audit/`.

## Coverage and concrete gaps

| Required connection | Observed state |
|---|---|
| Agents read and signal each other | Shared five-role board and direct task messaging work. They coordinate work; they do not dispatch scientific functions. |
| Common scientific description | The 14-field inquiry is used in specialist handoffs. Nested results and executable formats still differ and require explicit normalization adapters. |
| Prompt becomes an executable interpretation | Live desk uses four model vocabulary matches and explicit structured parameters. Local reasoning handles a limited grammar; neither provides full scientific interpretation. |
| Theorems can be selected and manipulated | Reviewed rational operations and domain calculations exist. The paper-rule register includes citations/obligations, not a generally verified or callable theorem catalogue. |
| Branches execute one another | Some do: quantum invokes accepted geometry; local encyclopedia invokes pinned root/biology code; the companion recomputes resource geometry. There is no general branch planner. |
| One overall answer | No common cross-branch synthesis with aligned domains and a complete support graph was found. |
| Connections to reality | 13 connector paths were inventoried. Grid collection/forecast display and Oslo availability have real acquisition paths. AlphaGenome, hardware quantum and EEG have different key, submission, calibration and validation limits. |
| Persistent scientific memory | 11 distinct stores were inventoried, including Git archives, local SQLite, JSONL, frozen files and browser storage. They are not a common hosted findings service. |
| Corrections propagate everywhere | Tested local revision/retraction paths exist. No central authenticated review/currentness subscription propagates changes to all consumers. |
| Encyclopedia is a live knowledge projection | Local entries perform real pinned calculations. They do not yet subscribe to a shared findings stream. |
| Recursive improvement | Toy learning, source freshness, next-question proposals and real collection/review tools exist. Their loops remain separate; new capabilities are not autonomously developed, validated and deployed by one scientific coordinator. |

Three concrete synchronization problems need to be resolved by that common path:

- Biology atlas0.2.1 checks copied geometry0.2.0 results and an earlier quantum packet. Those are not calls to the newest accepted capability. Rebinding requires an explicit compatible adapter and review.
- Operations triage reads historical Recovery feasibility `3451/4104`, while the final admission records `3445/4104`. Both fail the90% gate, so the decision is unchanged, but the selected evidence revision is inconsistent.
- The normal Site test command omits the separate learning-session regression checks. Passing the current component tests cannot certify the proposed joined flow.

The runtime audit passed **38 existing TypeScript tests, nine independent behavior probes and 14 companion tests**. The probes demonstrate the limits as well as the working calculations. The branch audit traces source composition; it does not independently accept every new numerical release. The source audit records exact source hashes and read-only database evidence. See [runtime report](../work/system-integration-audit/desk-runtime/RUNTIME_AUDIT.md), [branch signal map](../work/system-integration-audit/branch-flow/REPORT.md), and [data/findings report](../work/system-integration-audit/data-and-findings/REPORT.md).

## What the whole project should be

An investigation should preserve a question while changing the perspective, mathematical description, observations and admissible conclusions around it. The shared object is an **investigation with an explicit dependency graph**. The branches contribute compatible operations and results to that graph; they are not independent applications whose answers are pasted together.

Nouns identify entities, states, observables, instruments and resources. Verbs identify measurements, interventions, composition, adaptation and time evolution. The interpretation also needs units, domain, preparation, time, target, quantifiers, uncertainty and assumptions. A noun/verb match alone cannot supply those.

UHL belongs in the common operation library where its composition law and coordinate assumptions apply. Biology supplies actual dynamics, adaptation and accounting; quantum supplies state and instrument rules; mathematics supplies constraints, geometry, witnesses and distinguishability. Their shared language makes transfers checkable. It does not make unlike quantities physically interchangeable or turn boundedness alone into every domain law.

```mermaid
flowchart TD
  D[Desk: question and selected context] --> I[Structured interpretation with unresolved meaning]
  I --> P[Capability and dependency planner]
  S[Sources, datasets and instruments] --> A[Domain adapters and evidence checks]
  A --> O[Versioned observations]
  O --> P
  P --> M[Admitted mathematics and UHL operations]
  P --> B[Admitted biology models]
  P --> Q[Admitted quantum and instrument models]
  M --> R[Executed results with premises and witnesses]
  B --> R
  Q --> R
  R --> C[Consistency checks and scoped synthesis]
  C --> F[Versioned findings and review history]
  F --> V[Desk, encyclopedia and visual projections]
  F --> N[Missing measurement, derivation or counterexample]
  N --> P
  X[Correction, withdrawn premise or changed source] --> F
  F --> G[Invalidate affected descendants and replan]
  G --> P
```

The planner should inspect the common capability catalogue, then run the applicable operations in dependency order, with independent work in parallel. Running every engine on every question would mix incompatible models and waste computation. Every omitted or blocked relevant operation should have a visible reason.

## Construction rules

1. **One scientific contract, one operational envelope.** Preserve the existing 14-field inquiry format and accepted domain meanings. Surround it with investigation ID, revision, parent jobs, source/model hashes, admission references, delivery identity and execution limits. Do not introduce a parallel scientific vocabulary in each branch.
2. **Interpretation proposes; validation determines executability.** A language model may identify entities, quantities and candidate operations, retaining the supporting words and ambiguities. It cannot invent data, certify a theorem, turn a descriptive analogy into an equation, or grant itself an approved capability. Structured forms remain an executable fallback.
3. **Capabilities are explicit and versioned.** Each operation declares accepted input/output types, units, preparation/time restrictions, required premises, source identities, numerical validity limits, dependencies, cost and a pinned entry point. Publication and a producer's status string are insufficient admission.
4. **Execution is separate from presentation.** Reuse the reviewed Python engines in a controlled worker process and the existing Active Context receipts for scoped freshness/rechecks. The hosted Worker interface should validate, queue and expose results; it cannot simply import the local Python/SciPy engines. Commands are fixed argument arrays selected from admitted operations, never shell text supplied by a prompt.
5. **A finding is a record, not automatically a new truth.** Store conditional calculations, hypotheses, exclusions, unresolved cases, measurements and failures with distinct statuses. Established knowledge changes through the relevant evidence/review process. Do not average incompatible branch answers or assign a probability of truth without a specified probabilistic model.
6. **Preserve evidence and corrections.** Keep raw source snapshots, extraction/calibration records and derived observations distinct. New evidence names what it replaces. A correction or review hold invalidates precisely the dependent current claims, displays and next-action requests; unaffected work survives and history remains readable.
7. **The encyclopedia reads findings.** Its cards, equations, maps, animations and exports are projections of a captured investigation revision. A slider or anatomy selection must not silently assert an empirical measurement. Changing the scene while an image exports must not relabel the old data.
8. **Feedback proposes useful work.** Gaps should create named, deduplicated requests for a measurement, derivation, counterexample or integration. Repeat execution requires changed information or a justified experimental action, with budgets and stopping rules. Repeating an answer does not strengthen its evidence.
9. **External tools enter through owned adapters.** Each connector declares actual source, licence/access conditions, collection mode, freshness, units, uncertainty, calibration, revision handling and failure state. A repository library, an archived dataset, a live feed and a model prediction are different inputs. Avoid connecting a source solely because it is available.
10. **The permanent centre is the method.** Identity, provenance, type checking, evidence distinctions and dependency accounting stay stable. Scientific models, accepted assumptions, observations, capabilities and conclusions evolve through versioned changes. Self-improvement means finding gaps, proposing and testing revisions, and admitting successful changes; unrestricted self-rewriting is not an evidence mechanism.

## First delivery: one complete investigation

Use the already reviewed resource/geometry companion as the first acceptance scenario. It connects a biological resource question, mathematical possibilities, observations, conclusions, a correction and an encyclopedia view without inventing a quantum-biological transfer.

Question: **Can a 0.60 mM reaction-extent target be excluded by the declared resource model, and which observation changes the answer?**

The reviewed synthetic sequence starts with a compatible ceiling range `[0.159, 0.635] mM`, adds a total-pool interval, then adds NADPH `[9, 11] uM`, producing `[0.5541, 0.566] mM` and excluding the target under its premises. Correcting that observation to `[60, 80] uM` gives `[0.6051, 0.635] mM` and retracts the exclusion. These are possible necessary ceilings, not achieved clearance, survival or empirical validation.

The companion already passes local revision/currentness checks. The missing delivery is to carry this exact investigation from the desk through real registered code into durable findings and the actual encyclopedia view. Quantum must report no admitted observation map for this scenario until such a map is justified. An honest incompatibility is part of integration, not a reason to fabricate a link.

Acceptance requires:

- The original prompt and resolved quantities remain inspectable; unsupported details remain explicit gaps.
- Actual pinned biology/mathematics operations run, with execution receipts and an explicit quantum applicability decision.
- Findings survive process/browser restart and retain source, premise, code and revision identity.
- Correcting the NADPH observation recomputes the affected result, retracts the earlier exclusion and updates both desk and encyclopedia.
- Removing a necessary accounting or volume premise withdraws the affected numerical conclusion.
- Duplicate delivery, conflicting delivery, stale revision, changed source, unavailable runner and wrong units/preparation/time produce tested, atomic outcomes.
- Rendered values and downloads bind to the same captured revision; a refreshed page shows the same current record.
- A fresh checkout can replay the recorded run. The local and deployed versions are separately identified and verified before calling the feature live.

## Ownership and delivery order

| Owner | Next integration responsibility |
|---|---|
| Integration — Access GitHub repositories | Shared capability registry and inquiry envelope; admitted worker dispatch; durable research-event contract; dependency invalidation; hosted API and desk connection; independent review and deployment verification. |
| Mathematics — Build executable theory atlas | Expose accepted geometry/UHL operations and checked input/output restrictions; preserve the companion's correction semantics; supply applicability and numerical-decline fixtures. Keep the new Recovery Challenge release a separately reviewed candidate. |
| Biology — Build cellular adaptation inquiry | Supply the resource observation adapter, unit/preparation/calibration checks and explicit accounting dependencies. Connect the Observation Bridge through the common inquiry contract. Keep anatomy context separate from biological evidence. |
| Quantum — Assess quantum biology project | Supply typed instrument/state/observation capabilities and explicit transfer gaps. Preserve held successor boundaries until review. Expose the Optical Evidence work as versioned observations with uncertainty and calibration lineage, not an assumed bridge into redox. |
| Encyclopedia — Build living encyclopedia | Consume a revisioned finding projection rather than copied result files; show active, superseded, held and unresolved states; derive next requests and exported visuals from the captured record. |

First freeze the common interface against these existing pieces. Then implement and test the local durable round-trip. Then wire and verify the hosted desk and encyclopedia. Only after that should additional branches, sources and more autonomous planning expand this same path. New domain work can continue, but it must arrive as an adapter and reviewed capability rather than another disconnected application.

This audit does not certify every paper, reproduce every numerical result, validate every external dataset, or establish a scientific breakthrough. It identifies the actual integration boundary and the work needed to turn the existing components into the laboratory described above.
