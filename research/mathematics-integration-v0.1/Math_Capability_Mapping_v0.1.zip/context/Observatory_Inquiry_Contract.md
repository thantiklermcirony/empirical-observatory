# Observatory shared inquiry handoff — version 0.1

12 September 2026. A proposed interchange contract for the four-agent programme. This is a handoff specification, not a claim that the deployed Site or existing engine already implements these fields. The coordinator owns revisions; specialists propose extensions with examples.

One investigation connects a system, its environment, an observer, permitted operations, constraints, mechanisms, consequences and the next discriminating question. Different mathematical domains share this description without sharing a solver or losing their meanings.

## Required content of an inquiry package

| Field | Required meaning |
|---|---|
| identity | Stable inquiry ID, package version, producing task ID, timestamp and parent/version relationships |
| question | Original question, precise target, scope, intended user and the useful output requested |
| system | Entities, operational boundary, environment and coupling interfaces; what enters or leaves |
| observer | Available measurements and actions, observation map, resolution/noise, memory and clock; preparation/reset, experimental unit and physical effects of measurement if relevant |
| quantities | IDs, meanings, units, admissible domains and representation: real/complex/vector/distribution/etc. A normalized readout is distinct from a physical reserve. |
| operations | Inputs/outputs, state spaces, target, admissibility, order, duration or propagation parameter, and justified composition law; distinguish a process from an outcome-recording instrument |
| constraints | Bounds, conservation, capacities, symmetries, resource budgets and joint coupling restrictions |
| mechanism | Explicit equations or algorithm, chosen model family, calibration, source and alternative mechanisms; declare conditioning/postselection and trace-preserving versus trace-decreasing quantum evolution where relevant |
| premises | Stable IDs, statement, source, evidence status and scope; assumed, observed, derived, missing or rejected remain distinguishable |
| execution | Solver/method ID and version, input hashes, step dependencies, needed premises, numerical tolerances and reproducible command |
| results | Values or artifacts, units, uncertainty, scope, result kind and execution status; dependencies retained per conclusion |
| contrast | A changed assumption/intervention/measurement and the expected difference; at least one failure, counterexample or unresolved case |
| next_question | Which remaining uncertainty matters, what would distinguish it, and whether this question is authored or automatically generated |
| provenance | Source/model/data/code hashes, citations with locations, source/access dates, observation-unit/replicate and measurement provenance, licensing information for reused artifacts and local/GitHub/deployed revision distinctions |

Keep `result_kind` separate from `status`. Useful kinds are `formal_under_premises`, `model_prediction`, `empirical_comparison` and `hypothesis_or_analogy`. Useful statuses are `established_in_scope`, `not_supported`, `out_of_scope`, `unresolved`, `inconsistent` and `execution_error`. State exactly what is established; successful execution is not empirical support.

No new engine is required to emit this package. An existing simulator, rational certificate, imported theorem and empirical analysis may each supply an execution artifact. A complex quantum calculation does not become a rational proof by appearing in the same interface. A theorem source is not a checked instance certificate. Unsupported domain operations must remain explicit obligations.

The domain lead owns the scientific observation model, experimental unit, likelihood, calibration and statistical validation. Central validation checks completeness, compatibility and recorded evidence; it cannot certify a biological or quantum likelihood merely because the package is well formed. For quantum biology, the quantum lead checks the quantum mechanism and the biology lead checks the biological coupling and measurements.

## Example: the tunnelling inquiry

- Question: can a barrier's forbidden-region action alone determine transmission?
- System: coherent stationary electron scattering, constant mass, real barriers, equal exterior media.
- Observer: specified incident state and outgoing probability-current measurement.
- Quantities: complex wave amplitudes; spatial opacity `s=kappa*L`; allowed-gap phase `theta=k*ell`; transmission probability. Neither s nor theta is automatically an elapsed traversal time.
- Operations: forbidden-region transfer B(s), allowed-region transfer F(theta), ordered matrix composition and boundary matching.
- Constraints/mechanism: Schrödinger equation, conserved current and declared interfaces. These are imported physical premises.
- Result: at E=V0/2 and s=1 per barrier, contiguous double-barrier transmission is approximately0.0706508; a quarter-wave gap gives1 in the ideal model. Equal forbidden action is insufficient because phase matters.
- Evidence: standard model calculation and checked algebra; no new physical law or observed electron trajectory.
- Contrast: remove the coherent-phase premise and the ideal resonance conclusion is no longer licensed by this inquiry.
- Next question: what representation retains phase and boundary matching while simplifying useful calculations?
- Existing package: `C:/Users/madma/Documents/Codex/2026-09-09/ca/work/integrated-inquiry/tunnelling.json`, its result receipt and `tunnelling_probe.py`.

## Acceptance for the first shared integration

1. Another agent reproduces each submitted case from its instructions without rebuilding the science by hand.
2. Removing a necessary premise blocks or narrows its descendants; unrelated results remain available. Changing a physical operation recomputes its consequences.
3. Source/data/model changes invalidate affected results rather than silently reusing stale outputs.
4. Identity, simulation and empirical evidence remain distinguishable on the exported record and screen.
5. The interface can show the physical system, relevant rules, resulting geometry/trajectory and next useful question from the same package. It need not force all domains into one visual shape.
6. Each proposed cross-domain transfer names the map, preserved structure and additional assumptions. Mere resemblance is labelled as a search hypothesis.

First contributions should expose concrete incompatibilities in this contract. Send a minimal failing case and a proposed extension to the coordinator; do not implement a separate universal schema.
