# Integration companion handoff

This is a local, tested reference interaction for the existing coordinator-owned execution and presentation path. It consumes the frozen Geometry Discovery Lab 0.2.1 kernel, byte-identical in `vendor/geometry.py`. The vendor licence is included. All other files are original local integration code/prose for the Observatory.

Entry points: `DESIGN.md`, `ports.py`, `run.py`, `results/roundtrip.json` and `results/roundtrip.md`. `input-bindings.json` identifies the source snapshots consulted. Its recorded review states are dated provenance, not a live central status service.

The scientific parent is `GDL-BIOLOGY-WIDTHS@0.2.1`. The local event trace is companion metadata, not an additional scientific schema or trusted receipt. The domain premises for biological interpretation are inherited as explicitly stipulated fixture assumptions. This replay cannot admit real empirical evidence or certify an organ prediction.

Implemented: exact stock-unit conversion, original-preparation/time checks, same-ID retry suppression, conflicting-ID rejection, expected-revision checks, atomic rejected updates, named observation replacement, empty-intersection handling, context-only navigation, captured view snapshots and selective review/source blocking. Current local source is checked at view time as well as computation time. Fourteen tests pass against the real vendored resource kernel. The fixed local asset links demonstrate dependency behaviour without implementing a generic central dependency graph.

Not implemented: distributed transport, delivery authentication, durable storage, background workers, live instrument ingestion, source receipt trust, general noisy ratio observations, physical intervention propagation, shared Site wiring or public deployment. These remain explicit integration work in DESIGN.md. Do not use the simulated review-control messages as actual central approvals.

Recommended first consumer patch: add a companion view to the existing inquiry state using the active observation IDs and parent result binding. Route a selected next-request record to the domain owner; return its admitted response to the same inquiry. Render historic/superseded and current results distinctly. Keep the coordinator's trusted result-value rendering and admission logic rather than trusting payload fields from the port.

The Geometry 0.2.0 review issues were corrected in a separate frozen 0.2.1 release during this work. Independent review has accepted that version for local conditional geometry: 28 supplied tests, 21 independent check groups and 750 duplicate/rescaling cases passed. The immutable review snapshot is included under `inputs/`; it does not constitute admission of this new consumer rehearsal. No existing shared source, Site, anatomy asset, frozen release or public repository was edited for this companion.
