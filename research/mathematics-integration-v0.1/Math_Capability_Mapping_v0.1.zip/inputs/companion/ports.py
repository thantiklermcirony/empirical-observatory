"""Mathematics branch-port rehearsal. No shared bus, authentication or admission service."""
from copy import deepcopy
from fractions import Fraction as F
from pathlib import Path
import hashlib,json
from vendor.geometry import resource_fibre,resource_measurements,rank_bins

ROOT=Path(__file__).resolve().parent
KERNEL_SHA='04ff1dff72e2f4c0b4f094a1a988e60ba74712e92959d661a070eae9f65e3407'
# The build replaces KERNEL_SHA with the exact immutable vendored source hash.


def encoded(x):return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def sha(x):return hashlib.sha256(x).hexdigest()
def rational(x):
    if isinstance(x,bool) or not isinstance(x,(str,int)):
        raise ValueError('Use exact decimal/rational strings or integers for scientific values')
    return F(x)
def serial(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {k:serial(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [serial(v) for v in x]
    return x


class Session:
    def __init__(self):
        self.revision=0;self.computations=0;self.context=None
        self.scenario='GDL-ROUNDTRIP-SYNTHETIC';self.preparation='MATCHED-PREP-001'
        self.seen={};self.audit=[];self.observations={};self.superseded=[]
        self.target=F(3,5);self.holds={};self.stale=False
        self.result=dict(status='awaiting_observation',reason='Supply a reduced-fraction readout for the synthetic preparation')
        self.question='Can the 0.60 mM GPx target be excluded by the necessary resource ceiling?'

    def event(self,id,kind,payload):
        return dict(event_id=id,kind=kind,base_revision=self.revision,scenario_id=self.scenario,
                    preparation_id=self.preparation,model_sha256=KERNEL_SHA,payload=payload)

    def _compute(self):
        self.computations+=1
        if self.stale or sha((ROOT/'vendor/geometry.py').read_bytes())!=KERNEL_SHA:
            self.result=dict(status='blocked_source',reason='Pinned mathematical source is no longer current');return
        if 'geometry' in self.holds:
            self.result=dict(status='blocked_review',reason=self.holds['geometry']);return
        if 'q' not in self.observations:
            self.result=dict(status='awaiting_observation',reason='Reduced fraction q is missing');return
        q=self.observations['q']['interval'][0]
        poly,target,offset=resource_fibre(q)
        for quantity,row in [('T',(1,0)),('N',(0,1))]:
            if quantity in self.observations:
                lo,hi=self.observations[quantity]['interval'];poly=poly.intersect(row,lo,hi)
        if not poly.vertices():
            self.result=dict(status='inconsistent',reason='The retained observations and model bounds have no compatible stock state',active_signals=[o['id'] for o in self.observations.values()]);return
        bounds=poly.bounds(target,offset)
        choices=rank_bins(poly,target,offset,resource_measurements())
        best=choices[0]
        self.result=serial(dict(status='conditional_local_fixture',result_kind='formal_under_premises',
            evidence='synthetic',integration_status='candidate_requires_coordinator_acceptance',
            target_extent_mM=self.target,ceiling_interval_mM=[bounds['lower'],bounds['upper']],width_mM=bounds['width'],
            target_excluded=self.target>bounds['upper'],
            interpretation='Necessary resource ceiling; neither achieved clearance nor survival',
            premises=dict(status='stipulated_for_synthetic_rehearsal',ids=['BIO-VOLUME','BIO-LEDGER','BIO-NONNEG','BIO-SUPPLY','BIO-UNIT-MAP','BIO-MATCHED-UNIT']),
            active_signals=[o['id'] for o in self.observations.values()],
            model_sha256=KERNEL_SHA,mathematical_parent='GDL-BIOLOGY-WIDTHS@0.2.1',
            next_request=dict(to='biology',operation='request_assay_design',measurement=best['id'],
                              guaranteed_width_reduction_mM=best['guaranteed_reduction'],
                              state='proposal_not_experimental_command',
                              requires=['interval calibration','matched preparation','fixed volume','complete ledger','source ceiling']) if best['guaranteed_reduction']>0 else
                         dict(to='biology',operation='review_noise_and_target',state='proposal_not_experimental_command')))

    def snapshot(self):
        visible=deepcopy(self.result)
        try:source_ok=sha((ROOT/'vendor/geometry.py').read_bytes())==KERNEL_SHA
        except OSError:source_ok=False
        if self.stale or not source_ok:
            visible=dict(status='blocked_source',reason='Pinned source unavailable or stale; previous values are historical only')
        return dict(revision=self.revision,computation_count=self.computations,context=self.context,
                    context_meaning='Navigation only; no organ calibration or scientific premise supplied',
                    resource=visible,
                    quantum_connection=dict(status='held_upstream_review' if 'quantum_flux' in self.holds else 'candidate_unaccepted',
                        species_mapping='unresolved',reason=self.holds.get('quantum_flux','Independent numerical review required'),
                        downstream_display='No organ/species prediction'),
                    publication=dict(local='integration_rehearsal',github='not published',site='not deployed'))

    def deliver(self,event):
        previous=deepcopy(self.__dict__)
        try:return self._deliver(event)
        except Exception:
            self.__dict__.clear();self.__dict__.update(previous)
            raise

    def _deliver(self,event):
        before=self.snapshot()
        fingerprint=sha(encoded(event))
        id=event.get('event_id')
        if not isinstance(id,str) or not id:raise ValueError('A nonempty event ID is required')
        if id in self.seen:
            if self.seen[id]!=fingerprint:raise ValueError('Conflicting reuse of an event ID')
            return dict(event_id=id,delivery='duplicate_ignored',revision=self.revision,computation_count=self.computations)
        if type(event.get('base_revision')) is not int or event['base_revision']!=self.revision:raise ValueError('Stale revision: refresh the inquiry before proposing an update')
        if event.get('scenario_id')!=self.scenario or event.get('preparation_id')!=self.preparation:
            raise ValueError('Scenario/preparation mismatch; domain review must establish transfer first')
        if event.get('model_sha256')!=KERNEL_SHA:raise ValueError('Wrong source revision; rebinding requires a new reviewed inquiry')
        kind,payload=event.get('kind'),event.get('payload')
        if not isinstance(payload,dict):raise ValueError('Structured payload required')
        recompute=False
        if kind=='context_selection':
            name=payload.get('anatomical_label')
            if not isinstance(name,str) or not name.strip():raise ValueError('A context label is required')
            self.context=name
        elif kind=='question':
            value=rational(payload['target_extent_mM'])
            if value<0:raise ValueError('Nonnegative target required')
            self.target=value;recompute=True
        elif kind=='observation':
            if payload.get('origin')!='synthetic':raise ValueError('Route unreviewed empirical input to biology admission; it cannot update this synthetic rehearsal')
            if payload.get('preparation_time_min')!=0:raise ValueError('Different physical time requires a dynamics/transfer model')
            quantity=payload.get('quantity');unit=payload.get('unit')
            if quantity not in {'q','T','N'}:raise ValueError('Quantity has no admitted observation map')
            if quantity=='q' and unit!='1':raise ValueError('q requires a dimensionless ratio')
            if quantity!='q' and unit not in {'mM','uM'}:raise ValueError('Stock concentrations require mM or uM, not a ratio, rate or optical intensity')
            interval=payload.get('interval')
            if not isinstance(interval,list) or len(interval)!=2:raise ValueError('A two-endpoint interval is required')
            lo,hi=map(rational,interval)
            if unit=='uM':lo/=1000;hi/=1000
            if lo<0 or hi<lo:raise ValueError('Nonnegative increasing interval required')
            if quantity=='q' and (lo!=hi or hi>1):raise ValueError('This adapter requires one exact q in [0,1]; general noisy ratios need a reviewed extension')
            old=self.observations.get(quantity)
            if old and payload.get('replaces')!=old['id']:raise ValueError('Correction must name the active signal it replaces')
            if not old and payload.get('replaces'):raise ValueError('No matching active signal to replace')
            if old:self.superseded.append(deepcopy(old))
            self.observations[quantity]=dict(id=id,quantity=quantity,interval=[lo,hi],original_unit=unit,origin='synthetic')
            recompute=True
        elif kind=='review_hold':
            asset=payload.get('asset');reason=payload.get('reason')
            if asset not in {'geometry','quantum_flux'} or not isinstance(reason,str) or not reason:raise ValueError('Named asset and reason required')
            self.holds[asset]=reason;recompute=asset=='geometry'
        elif kind=='source_invalidated':
            if payload.get('asset')!='geometry':raise ValueError('Only the local mathematical binding is handled by this port')
            self.stale=True;recompute=True
        else:raise ValueError('Unsupported branch-port event')
        if recompute:self._compute()
        self.revision+=1;self.seen[id]=fingerprint
        after=self.snapshot()
        entry=dict(event=deepcopy(event),delivery='applied',before=before,after=after,
                   outbound=dict(to=['encyclopedia','biology'],kind='inquiry_view_update',
                                 changed_scientific_result=before['resource']!=after['resource'],
                                 next_request=after['resource'].get('next_request'),
                                 execution='local_rehearsal_only'))
        self.audit.append(entry)
        return entry
