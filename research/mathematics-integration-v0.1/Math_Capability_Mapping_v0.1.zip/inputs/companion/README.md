# Observatory signals and operations — integration rehearsal 0.1

The aim is a single understandable research loop across the Observatory: a question identifies a target, domain branches supply its model and observations, mathematics locates the remaining ambiguity, the interface proposes a useful measurement, and its reviewed result returns to the same inquiry.

This local companion demonstrates that loop with the frozen Geometry Discovery Lab's resource kernel. It also rehearses delivery retries, incompatible inputs, corrected observations and a selective upstream release hold. It is an integration proposal for the coordinator, not a second central engine or a deployed message service.

Read `DESIGN.md` for the programme-wide flow and ownership. Run `python -B run.py` with Python 3.10+ and NumPy to reproduce the local event trace, exact calculations and tests. `results/roundtrip.json` is the machine-readable trace; `results/roundtrip.md` explains each transition. `input-bindings.json` pins the files consumed or cited during this rehearsal. The shared 14-field inquiry remains the scientific interchange record; event records here are local operational metadata.

All observations in the round-trip are explicitly synthetic. Anatomical selection changes context only. Empirical input needs the domain's admission route. Review notices in tests are simulated control messages, not signed central approvals. Existing release state is recorded as a dated snapshot with its source; the rehearsal cannot publish, deploy, admit evidence or issue real-world experimental commands.
