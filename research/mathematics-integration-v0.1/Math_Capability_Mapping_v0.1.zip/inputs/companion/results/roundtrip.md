# One question across Observatory branches

Executed locally against the pinned Geometry Discovery Lab 0.2.1 kernel. All readouts are synthetic. Review notifications are rehearsed control inputs, not trusted admissions.

| Revision | Signal in | Result out | Next destination |
|---:|---|---|---|
| 1 | ctx: context_selection | awaiting_observation | Biology request / encyclopedia view |
| 2 | question: question | awaiting_observation | Biology request / encyclopedia view |
| 3 | q1: observation | Possible ceiling [0.1590, 0.6350] mM; target not excluded | Biology request / encyclopedia view |
| 4 | t1: observation | Possible ceiling [0.5451, 0.6350] mM; target not excluded | Biology request / encyclopedia view |
| 5 | n1: observation | Possible ceiling [0.5541, 0.5660] mM; target excluded | Biology request / encyclopedia view |
| 6 | n2: observation | Possible ceiling [0.6051, 0.6350] mM; target not excluded | Biology request / encyclopedia view |
| 7 | quantum-review: review_hold | Possible ceiling [0.6051, 0.6350] mM; target not excluded | Biology request / encyclopedia view |

The q readout leaves an upper ceiling of 0.635 mM. A total-pool interval narrows the compatible states. The 9–11 uM NADPH readout reduces the ceiling to 0.566 mM, excluding the 0.60 mM target under the stipulated ledger. Correcting NADPH to 60–80 uM supersedes that earlier signal and retracts the exclusion. The possible ceiling is again at most 0.635 mM. None of these ceilings proves achieved clearance or survival.

The duplicate n1 delivery is ignored. Navigation selection produces no scientific recomputation. A hold on the independent quantum connection leaves this resource calculation intact. A hold or stale source on the geometry itself suppresses its numeric answer and proposed follow-up. Wrong-unit, empirical-without-admission and different-time observations are rejected without mutating the accepted local state.

Validation: 14 tests passed. Events and full before/after views are in `roundtrip.json`.
