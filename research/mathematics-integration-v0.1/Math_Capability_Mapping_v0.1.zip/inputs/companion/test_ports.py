from copy import deepcopy
import unittest
from unittest.mock import patch
from ports import Session


def observe(s,id,quantity,interval,unit='mM',**extra):
    return s.event(id,'observation',dict(quantity=quantity,interval=interval,unit=unit,origin='synthetic',preparation_time_min=0,**extra))


def populated():
    s=Session();s.deliver(observe(s,'q','q',['.99','.99'],'1'))
    s.deliver(observe(s,'t','T',['.98','1']))
    s.deliver(observe(s,'n','N',['9','11'],'uM'))
    return s


class PortTests(unittest.TestCase):
    def test_real_kernel_roundtrip_and_unit_conversion(self):
        s=populated()
        self.assertEqual(s.result['ceiling_interval_mM'],['5541/10000','283/500'])
        self.assertEqual(s.result['width_mM'],'119/10000')
        self.assertTrue(s.result['target_excluded'])
        self.assertEqual(s.result['evidence'],'synthetic')

    def test_context_is_not_an_observation(self):
        s=populated();before=deepcopy(s.result);count=s.computations
        s.deliver(s.event('context','context_selection',dict(anatomical_label='liver')))
        self.assertEqual(before,s.result);self.assertEqual(count,s.computations)

    def test_captured_view_does_not_change_after_later_signal(self):
        s=populated();export_snapshot=s.snapshot()
        s.deliver(observe(s,'new-n','N',['60','80'],'uM',replaces='n'))
        self.assertTrue(export_snapshot['resource']['target_excluded'])
        self.assertFalse(s.snapshot()['resource']['target_excluded'])
        self.assertNotEqual(export_snapshot['revision'],s.revision)

    def test_current_source_checked_even_without_recomputation(self):
        s=populated();count=s.computations
        with patch('ports.sha',return_value='changed-source'):
            view=s.snapshot()
        self.assertEqual(view['resource']['status'],'blocked_source')
        self.assertNotIn('ceiling_interval_mM',view['resource'])
        self.assertEqual(s.computations,count)

    def test_duplicate_delivery_does_not_double_count(self):
        s=Session();e=observe(s,'q','q',['.99','.99'],'1');s.deliver(e)
        snapshot=s.snapshot();self.assertEqual(s.deliver(e)['delivery'],'duplicate_ignored')
        self.assertEqual(snapshot,s.snapshot())

    def test_reused_id_with_changed_content_rejected(self):
        s=Session();e=observe(s,'q','q',['.99','.99'],'1');s.deliver(e)
        e['payload']['interval']=['.9','.9']
        with self.assertRaisesRegex(ValueError,'Conflicting reuse'):s.deliver(e)

    def test_observation_correction_retracts_exclusion(self):
        s=populated();s.deliver(observe(s,'n-corrected','N',['60','80'],'uM',replaces='n'))
        self.assertFalse(s.result['target_excluded'])
        self.assertEqual(s.result['ceiling_interval_mM'],['6051/10000','127/200'])
        self.assertEqual([x['id'] for x in s.superseded],['n'])
        self.assertNotIn('n',s.result['active_signals'])

    def test_unlabelled_replacement_rejected_atomically(self):
        s=populated();before=s.snapshot()
        with self.assertRaisesRegex(ValueError,'Correction must name'):s.deliver(observe(s,'new-n','N',['60','80'],'uM'))
        self.assertEqual(before,s.snapshot())

    def test_stale_edit_and_wrong_binding_rejected(self):
        for field,value in [('base_revision',-1),('model_sha256','changed'),('preparation_id','OTHER'),('scenario_id','OTHER')]:
            s=populated();e=s.event('bad','context_selection',dict(anatomical_label='retina'));e[field]=value
            before=s.snapshot()
            with self.assertRaises(ValueError):s.deliver(e)
            self.assertEqual(before,s.snapshot())

    def test_optical_ratio_rate_and_empirical_inputs_do_not_become_stocks(self):
        for unit in ['a.u.','1','uM/s']:
            s=Session()
            with self.assertRaises(ValueError):s.deliver(observe(s,'bad','N',['1','2'],unit))
        s=Session();e=observe(s,'bad','N',['1','2'],'uM');e['payload']['origin']='empirical'
        with self.assertRaisesRegex(ValueError,'biology admission'):s.deliver(e)

    def test_different_time_and_noisy_q_require_new_model(self):
        s=Session();e=observe(s,'bad','N',['1','2'],'uM');e['payload']['preparation_time_min']=5
        with self.assertRaisesRegex(ValueError,'Different physical time'):s.deliver(e)
        with self.assertRaisesRegex(ValueError,'exact q'):s.deliver(observe(s,'noisy','q',['.9','1'],'1'))

    def test_inconsistent_observations_suppress_numeric_answer(self):
        s=populated();s.deliver(observe(s,'outside','N',['90','100'],'uM',replaces='n'))
        self.assertEqual(s.result['status'],'inconsistent')
        self.assertNotIn('ceiling_interval_mM',s.result)

    def test_quantum_hold_does_not_erase_independent_resource_result(self):
        s=populated();before=deepcopy(s.result);count=s.computations
        s.deliver(s.event('hold','review_hold',dict(asset='quantum_flux',reason='Independent quadrature review hold')))
        self.assertEqual(before,s.result);self.assertEqual(count,s.computations)
        self.assertEqual(s.snapshot()['quantum_connection']['status'],'held_upstream_review')

    def test_geometry_hold_and_stale_source_suppress_dependent_answer(self):
        for kind,payload,status in [('review_hold',dict(asset='geometry',reason='Numerical review hold'),'blocked_review'),('source_invalidated',dict(asset='geometry'),'blocked_source')]:
            s=populated();s.deliver(s.event('hold',kind,payload))
            self.assertEqual(s.result['status'],status)
            self.assertNotIn('ceiling_interval_mM',s.result)
            self.assertNotIn('next_request',s.result)


if __name__=='__main__':unittest.main()
