from pathlib import Path
from copy import deepcopy
import hashlib,json,unittest
from ports import Session,KERNEL_SHA,serial
from test_ports import observe,populated

ROOT=Path(__file__).resolve().parent
def dump(path,x):path.write_text(json.dumps(serial(x),indent=2,allow_nan=False)+'\n',encoding='utf-8')


def main():
    assert hashlib.sha256((ROOT/'vendor/geometry.py').read_bytes()).hexdigest()==KERNEL_SHA
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.discover(str(ROOT),pattern='test_*.py'))
    if not result.wasSuccessful():raise SystemExit(1)
    s=Session()
    s.deliver(s.event('ctx','context_selection',dict(anatomical_label='liver (navigation context only)')))
    s.deliver(s.event('question','question',dict(target_extent_mM='.6')))
    s.deliver(observe(s,'q1','q',['.99','.99'],'1'))
    s.deliver(observe(s,'t1','T',['.98','1']))
    n=observe(s,'n1','N',['9','11'],'uM');s.deliver(n)
    duplicate=s.deliver(n)
    s.deliver(observe(s,'n2','N',['60','80'],'uM',replaces='n1'))
    s.deliver(s.event('quantum-review','review_hold',dict(asset='quantum_flux',reason='Rehearsed response to the coordinator-reported quadrature hold; source snapshot is retained')))
    contrasts=[]
    for kind,payload in [('review_hold',dict(asset='geometry',reason='Simulated kernel review hold')),('source_invalidated',dict(asset='geometry'))]:
        branch=deepcopy(s);event=branch.event('contrast-'+kind,kind,payload);branch.deliver(event)
        contrasts.append(dict(event=event,after=branch.snapshot()))
    errors=[]
    for field,value in [('unit','a.u.'),('origin','empirical'),('preparation_time_min',5)]:
        branch=deepcopy(s);event=observe(branch,'bad-'+field,'N',['1','2'],'uM',replaces='n2');event['payload'][field]=value
        try:branch.deliver(event)
        except ValueError as e:errors.append(dict(event=event,reason=str(e),science_unchanged=branch.result==s.result))
    data=dict(version='0.1.0',scope='local branch-port rehearsal; control messages are fixtures, not central approvals',
              geometry_version='0.2.1',kernel_sha256=KERNEL_SHA,events=s.audit,duplicate_ack=duplicate,
              contrasts=contrasts,rejected_inputs=errors,final=s.snapshot(),superseded_signals=s.superseded)
    out=ROOT/'results';out.mkdir(exist_ok=True);dump(out/'roundtrip.json',data)
    lines=['# One question across Observatory branches','',
      'Executed locally against the pinned Geometry Discovery Lab 0.2.1 kernel. All readouts are synthetic. Review notifications are rehearsed control inputs, not trusted admissions.','',
      '| Revision | Signal in | Result out | Next destination |','|---:|---|---|---|']
    for e in s.audit:
        r=e['after']['resource'];value=r['status']
        if 'ceiling_interval_mM' in r:
            lo,hi=map(lambda v:float(__import__('fractions').Fraction(v)),r['ceiling_interval_mM'])
            value=f'Possible ceiling [{lo:.4f}, {hi:.4f}] mM; target '+('excluded' if r['target_excluded'] else 'not excluded')
        lines.append(f"| {e['after']['revision']} | {e['event']['event_id']}: {e['event']['kind']} | {value} | Biology request / encyclopedia view |")
    lines+=['','The q readout leaves an upper ceiling of 0.635 mM. A total-pool interval narrows the compatible states. The 9–11 uM NADPH readout reduces the ceiling to 0.566 mM, excluding the 0.60 mM target under the stipulated ledger. Correcting NADPH to 60–80 uM supersedes that earlier signal and retracts the exclusion. The possible ceiling is again at most 0.635 mM. None of these ceilings proves achieved clearance or survival.','',
      'The duplicate n1 delivery is ignored. Navigation selection produces no scientific recomputation. A hold on the independent quantum connection leaves this resource calculation intact. A hold or stale source on the geometry itself suppresses its numeric answer and proposed follow-up. Wrong-unit, empirical-without-admission and different-time observations are rejected without mutating the accepted local state.','',
      f'Validation: {result.testsRun} tests passed. Events and full before/after views are in `roundtrip.json`.']
    (out/'roundtrip.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    dump(out/'validation.json',dict(all_passed=True,tests=result.testsRun,events=len(s.audit),duplicate_ignored=True,
                                 geometry_source_sha256=KERNEL_SHA,input_hashes={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(ROOT.rglob('*.py'))}))
    print(json.dumps(dict(all_passed=True,tests=result.testsRun,events=len(s.audit),final_resource=s.result)))


if __name__=='__main__':main()
