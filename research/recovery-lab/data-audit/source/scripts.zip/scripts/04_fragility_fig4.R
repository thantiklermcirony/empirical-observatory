#################################################################################################################
#################################################################################################################
######
######                Title: 04_fragility_fig4.R
######
######                Project: Fragility
######
######                Description: Generate Fig 4, healthspan analysis
######
######                Author: AL
######
######                Date:  2023-10-01
######
#################################################################################################################
#################################################################################################################

# prep workspace ----------------------------------------------------------

if (!is.null(pacman::p_loaded())) {
  pacman::p_unload("all")
}
rm(list = ls())
graphics.off()
library(groundhog)
pkgs <- c(
  "tidyverse",
  "ggsci",
  "here",
  "janitor",
  "slider",
  "survival",
  "survminer",
  "patchwork"
)
groundhog.library(pkgs, "2023-03-27")
source(here::here("scripts", "fragility_vecs.R")) # helper vecs
source(here::here("scripts", "fragility_funs.R")) # helper funs

# df prep -----------------------------------------------------------------

df <- df_process() 

# subset dfs
df_DO <- df %>% filter(strain == "J:DO")
df_B6 <- df %>% filter(strain == "C57BL/6J")
df_t0 <- df %>% filter(n == 1) # Baseline; all
df_DO_t0 <- df_DO %>%
  filter(n == 1) %>%
  mutate(d = 1) # Baseline; DO
df_B6_t0 <- df_B6 %>%
  filter(n == 1) %>%
  mutate(d = 1) # Baseline; B6


# Generate health span summaries ------------------------------------


# Health span = FgI score_sum < 4

# DO

df1 <- df_DO %>%
  group_by(id) %>%
  summarize(frail = ifelse(any(score_sum >= 4), 1, 0))

df2 <-
  df_DO %>%
  ungroup() %>%
  # collect age of first score_sum >= 4 in each as binary event
  mutate(temp = ifelse(score_sum >= 4, 1, 0)) %>%
  filter(temp == 1) %>%
  group_by(id) %>%
  arrange(age_in_weeks, .by_group = T) %>%
  # collect age of first event, among mice w/ event
  mutate(n = row_number()) %>%
  filter(n == 1) %>%
  mutate(healthspan = age_in_weeks) %>%
  select(id, healthspan)

healthspan_DO <-
  full_join(df_DO_t0, df1, by = "id") %>%
  full_join(., df2, by = "id") %>%
  select(id, frail, healthspan, diet, lifespan) %>%
  mutate(healthspan = ifelse(frail == 0, lifespan, healthspan / 4.34))

rm(df1, df2)

# B6
df1 <- df_B6 %>%
  group_by(id) %>%
  summarize(frail = ifelse(any(score_sum >= 4), 1, 0)) 

# collect age of first score_sum >= 4 in each
df2 <-
  df_B6 %>%
  ungroup() %>%
  mutate(temp = ifelse(score_sum >= 4, 1, 0)) %>%
  filter(temp == 1) %>%
  group_by(id) %>%
  arrange(collection_date, .by_group = T) %>%
  mutate(n = row_number()) %>%
  filter(n == 1) %>%
  mutate(healthspan = age_in_weeks) %>%
  select(id, healthspan)

healthspan_B6 <-
  full_join(df_B6_t0, df1, by = "id") %>%
  full_join(., df2, by = "id") %>%
  select(id, frail, healthspan, sex, lifespan) %>%
  mutate(healthspan = ifelse(frail == 0, lifespan, healthspan / 4.34))

rm(df1, df2)

# Summarize health span data ----

# not all mice met the threshold prior to exit:
healthspan_DO %>%
  tabyl(frail) %>%
  adorn_pct_formatting(digits = 0)
# frail   n percent
# 0   3      1%
# 1 231     99%
healthspan_B6 %>%
  tabyl(frail) %>%
  adorn_pct_formatting(digits = 0)
# frail  n percent
# 0  4     11%
# 1 32     89%

### quant summary of healthspan w/ censoring:

sfit_b6 <- surv_fit(Surv(healthspan, frail) ~ 1, data = healthspan_B6, stype = 2, conf.int = 0.95, conf.type = "log")
quantile(sfit_b6, probs = 0.5) %>%
  bind_cols() %>%
  data.matrix() %>%
  data.frame() %>%
  rename(Median = quantile, lbCI95 = lower, ubCI95 = upper) %>%
  knitr::kable(digits = 1)
#   | Median| lbCI95| ubCI95|
#   |------:|------:|------:|
#   |   24.9|   24.2|   26.3|

sfit_b6_sex <- surv_fit(Surv(healthspan, frail) ~ sex, data = healthspan_B6, stype = 2, conf.int = 0.95, conf.type = "log")
quantile(sfit_b6_sex, probs = 0.5) %>%
  bind_cols() %>%
  data.matrix() %>%
  data.frame() %>%
  rename(Median = quantile, lbCI95 = lower, ubCI95 = upper) %>%
  mutate(Sex = levels(healthspan_B6$sex)) %>%
  select(Sex, everything()) %>%
  knitr::kable(digits = 2)
#   |Sex | Median| lbCI95| ubCI95|
#   |:---|------:|------:|------:|
#   |m   |  24.23|  23.73|  25.15|
#   |f   |  27.19|  26.14|     NA|
sfit_do <- surv_fit(Surv(healthspan, frail) ~ 1, data = healthspan_DO, stype = 2, conf.int = 0.95, conf.type = "log")
quantile(sfit_do, probs = 0.5) %>%
  bind_cols() %>%
  data.matrix() %>%
  data.frame() %>%
  rename(Median = quantile, lbCI95 = lower, ubCI95 = upper) %>%
  knitr::kable(digits = 2)
#   | Median| lbCI95| ubCI95|
#   |------:|------:|------:|
#   |   31.6|   31.6|  32.09|

sfit_do_diet <- surv_fit(Surv(healthspan, frail) ~ diet, data = healthspan_DO, stype = 2, conf.int = 0.95, conf.type = "log")
quantile(sfit_do_diet, probs = 0.5) %>%
  bind_cols() %>%
  data.matrix() %>%
  data.frame() %>%
  rename(Median = quantile, lbCI95 = lower, ubCI95 = upper) %>%
  mutate(Diet = levels(healthspan_DO$diet)) %>%
  select(Diet, everything()) %>%
  knitr::kable(digits = 2)
#   |Diet | Median| lbCI95| ubCI95|
#   |:----|------:|------:|------:|
#   |AL   |  31.60|  30.94|  32.09|
#   |IF1  |  31.40|  30.94|  32.46|
#   |CR20 |  31.60|  31.34|  32.52|
#   |IF2  |  32.06|  31.40|  32.98|
#   |CR40 |  32.03|  31.60|  33.64|

# compare maximum health span with fisher exact tests ----

# b6
q <- quantile(sfit_b6, probs = 0.9)$quantile # 27.9131
q
healthspan_B6$frail_q90 <- ifelse(healthspan_B6$healthspan > q, 1, 0) 
healthspan_B6 %>%
  tabyl(sex, frail_q90) %>%
  adorn_percentages(denominator = "col") %>%
  adorn_pct_formatting(digits = 0) # 100% female
table(healthspan_B6$sex, healthspan_B6$frail_q90)
# # 0  1
# # m 24  0
# # f 10  2
fisher.test(table(healthspan_B6$sex, healthspan_B6$frail_q90))$p.value %>% round(., 2) # 0.1


# do
q <- quantile(sfit_do, probs = 0.9)$quantile # 38.47926
healthspan_DO$frail_q90 <- ifelse(healthspan_DO$healthspan > q, 1, 0) 
table(healthspan_DO$diet, healthspan_DO$frail_q90)
# #       0  1
# # AL   23  2
# # IF1  33  0
# # CR20 49  6
# # IF2  44  4
# # CR40 67  6
fisher.test(table(healthspan_DO$diet, healthspan_DO$frail_q90))$p.value %>% round(., 2) # 0.39
# cr v other groups in do by diet
healthspan_DO %>%
  mutate(diet_cr = ifelse(str_detect(diet, "CR"), 1, 0)) %>%
  tabyl(diet_cr, frail_q90) %>%
  adorn_percentages(denominator = "col") %>%
  adorn_pct_formatting(digits = 0) # 67% of frail_q90 on CR diet
healthspan_DO$diet2 <- ifelse(healthspan_DO$diet == "CR20" | healthspan_DO$diet == "CR40", "CR", "Other")
table(healthspan_DO$diet2, healthspan_DO$frail_q90)
# 0   1
# CR    116  12
# Other 100   6
fisher.test(table(healthspan_DO$diet2, healthspan_DO$frail_q90))$p.value %>% round(., 2) # 0.33


# surv plots ----------------------------------------------------------------

a <- surv_plot_fun(df_DO_t0, "J:DO", "lifespan", "d", "diet", min(df_DO_t0$lifespan), max(df_DO_t0$lifespan), 44, 0.85)
b <- surv_plot_fun(healthspan_DO, "J:DO", "healthspan", "frail", "diet", min(healthspan_DO$healthspan), max(healthspan_DO$healthspan), 37, 0.85)
c <- surv_plot_fun(df_B6_t0, "C57BL/6J", "lifespan", "d", "sex", min(df_B6_t0$lifespan), max(df_B6_t0$lifespan), 30, 0.85) + scale_color_manual(values = c(colors5[2], colors5[5]))
d <- surv_plot_fun(healthspan_B6, "C57BL/6J", "healthspan", "frail", "sex", min(healthspan_B6$healthspan), max(healthspan_B6$healthspan), 28, 0.85) + scale_color_manual(values = c(colors5[2], colors5[5]))

top <- (a + b & theme(legend.position = "none")) 
bottom <- (c + d & theme(legend.position = "none")) 
p <- top / bottom + plot_annotation(tag_levels = "A")

ggsave(
  here::here("results", "Figure_4.pdf"),
  plot = p,
  scale = 1.5,
  width = 160,
  height = 160,
  unit = "mm",
  dpi = 300
)

###
# v2 - death treated as event

healthspan_DO <- healthspan_DO %>% mutate(d = 1)
healthspan_B6 <- healthspan_B6 %>% mutate(d = 1)

a <- surv_plot_fun(df_DO_t0, "J:DO", "lifespan", "d", "diet", min(df_DO_t0$lifespan), max(df_DO_t0$lifespan), 44, 0.85)
b <- surv_plot_fun(healthspan_DO, "J:DO", "healthspan", "d", "diet", min(healthspan_DO$healthspan), max(healthspan_DO$healthspan), 37, 0.85)
c <- surv_plot_fun(df_B6_t0, "C57BL/6J", "lifespan", "d", "sex", min(df_B6_t0$lifespan), max(df_B6_t0$lifespan), 30, 0.85) + scale_color_manual(values = c(colors5[2], colors5[5]))
d <- surv_plot_fun(healthspan_B6, "C57BL/6J", "healthspan", "d", "sex", min(healthspan_B6$healthspan), max(healthspan_B6$healthspan), 28, 0.85) + scale_color_manual(values = c(colors5[2], colors5[5]))

top <- (a + b & theme(legend.position = "none")) 
bottom <- (c + d & theme(legend.position = "none")) 
p <- top / bottom + plot_annotation(tag_levels = "A")

ggsave(
  here::here("results", "Figure_4_v2.pdf"),
  plot = p,
  scale = 1.5,
  width = 160,
  height = 160,
  unit = "mm",
  dpi = 300
)

# clear workspace ---------------------------------------------------------

rm(list = ls())
pacman::p_unload("all")
graphics.off()
# .rs.restartR()
