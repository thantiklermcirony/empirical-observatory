#################################################################################################################
#################################################################################################################
######
######                Title: 14_fragility_butcher.R
######
######                Project: Fragility
######
######                Description:  Reduce ML obj size
######
######                Author: AL
######
######                Date:  2023-10-03
######
#################################################################################################################
#################################################################################################################

# prep workspace ----------------------------------------------------------

if (!is.null(pacman::p_loaded())) {
  pacman::p_unload("all")
}
rm(list = ls())
graphics.off()
library(groundhog)
pkgs <- c("tidyverse", "stacks", "butcher")
groundhog.library(pkgs, "2023-03-27")  

# begin -----------------------------------------------------------------

# store w/ and w/o ml size reduction
fragility_stack_big <- readRDS(here::here("results", "/fitted_stack.rds"))
fragility_stack_small <- fragility_stack_big %>% butcher()

# compare obj sizes
lobstr::obj_size(fragility_stack_big) # 5.11 GB
lobstr::obj_size(fragility_stack_small) # 520.66 MB

# confirm results same pre/post reduction
demo <- slice_sample(fragility_stack_big$train, n=20)
demo_preds_big_obj <- demo %>% bind_cols(predict(fragility_stack_big, .))
demo_preds_small_obj <- demo %>% bind_cols(predict(fragility_stack_small, .))
cbind(demo_preds_big_obj$.pred_class, demo_preds_small_obj$.pred_class)
test <- demo_preds_big_obj == demo_preds_small_obj  
test %>% as_tibble() %>% filter(!Reduce(`|`, select(., everything()))) # same result w/ ml objs big and small. 

# store smaller obj 
saveRDS(fragility_stack_small, file = here::here("results", "/fitted_stack.rds"))

# clear workspace ---------------------------------------------------------

rm(list = ls())
pacman::p_unload('all')
graphics.off()
.rs.restartR()
