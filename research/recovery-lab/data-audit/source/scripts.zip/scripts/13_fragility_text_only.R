#################################################################################################################
#################################################################################################################
######
######                Title: 13_fragility_text_only.R
######
######                Project: Fragility
######
######                Description: non-ml results in text
######
######                Author: AL
######
######                Date:  2023-08-15
######
#################################################################################################################
#################################################################################################################

# prep workspace ----------------------------------------------------------

if (!is.null(pacman::p_loaded())) {
  pacman::p_unload("all")
}
rm(list = ls())
graphics.off()
library(groundhog)
pkgs <- c(
  "tidyverse",
  "broom",
  "car",
  "here",
  "janitor",
  "pacman"
)
groundhog.library(pkgs, "2023-03-27")
source(here::here("scripts", "fragility_vecs.R")) # helper vecs
source(here::here("scripts", "fragility_funs.R")) # helper funs

# df prep -----------------------------------------------------------------

df <- df_process()

# subset dfs
df_DO <- df %>% filter(strain == "J:DO")
df_B6 <- df %>% filter(strain == "C57BL/6J")
df_t0 <- df %>% filter(n == 1) # Baseline; all
df_DO_t0 <- df_DO %>%
  filter(n == 1) %>%
  mutate(d = 1) # Baseline; DO
df_B6_t0 <- df_B6 %>%
  filter(n == 1) %>%
  mutate(d = 1) # Baseline; B6

# Results -----------------------------------------------------------------

# Lifespan in fragility ----

###
# B6

# enrollment age
round(mean(df_B6_t0$age_enroll), 0) #  24

# lifespan, overall
df_B6_t0 %>%
  summarize(across(lifespan,
    list(
      q25 = ~ quantile(., probs = 0.25),
      median = median,
      q75 = ~ quantile(., probs = 0.75),
      q90 = ~ quantile(., probs = .9),
      raw_max = max
    ),
    .names = "{.fn}"
  )) %>%
  mutate(iqr = q75 - q25)
# q25 median   q75   q90 raw_max   iqr
# 27.4   29.3  32.7  34.7    36.6  5.34

# maximum lifespan sex
slice_max(df_B6_t0, order_by = lifespan) %>% select(sex) # m

# diff in est max by sex
.quantile <- 0.90
q <- quantile(df_B6_t0$lifespan, probs = .quantile, na.rm = T) # threshold
round(q, 1) # 34.7
df_B6_t0$d <- ifelse(df_B6_t0$lifespan > q, 1, 0) # above/below threshold
fisher.test(df_B6_t0$sex, df_B6_t0$d)$p.value %>% round(., 2) # 0.28

# lifespan, by sex
t.test(lifespan ~ sex, data = df_B6_t0, var.equal = FALSE)$p.value %>% round(., 2) # 0.51
leveneTest(lifespan ~ sex, data = df_B6_t0)$`Pr(>F)`[1] %>% round(., 2) # 0.05
df_B6_t0 %>%
  group_by(sex) %>%
  summarize(across(lifespan,
    list(
      q25 = ~ quantile(., probs = 0.25),
      median = median,
      q75 = ~ quantile(., probs = 0.75),
      max = max,
      n = ~ n()
    ),
    .names = "{.fn}"
  )) %>%
  mutate(iqr = q75 - q25)
# sex     q25 median   q75   max     n   iqr
# 1 m      27.1   29.6  33.1  36.6    24  6.02
# 2 f      27.8   28.9  30.5  34.4    12  2.67

###
# DO

# enrollment age
round(mean(df_DO_t0$age_enroll), 1) # 32.7 months

# lifespan, overall
df_DO_t0 %>%
  summarize(across(lifespan,
    list(
      q25 = ~ quantile(., probs = 0.25),
      median = median,
      q75 = ~ quantile(., probs = 0.75),
      q90 = ~ quantile(., probs = .9),
      raw_max = max
    ),
    .names = "{.fn}"
  )) %>%
  mutate(iqr = q75 - q25)
# q25 median   q75   q90 raw_max   iqr
# 34.3   37.4  41.5  46.3    53.9  7.22

# diff in est max by diet?
.quantile <- 0.90
q <- quantile(df_DO_t0$lifespan, probs = .quantile, na.rm = T) # threshold
round(q, 1) # 46.3
df_DO_t0$d <- ifelse(df_DO_t0$lifespan > q, 1, 0) 
fisher.test(table(df_DO_t0$diet, df_DO_t0$d))$p.value # 4.132813e-08

# lifespan, by diet
aov(lifespan ~ diet, data = df_DO_t0) %>%
  tidy() %>%
  pluck(6, 1) # 3.122942e-15

df_DO_t0 %>%
  group_by(diet) %>%
  summarize(across(lifespan,
    list(
      q25 = ~ quantile(., probs = 0.25),
      median = median,
      q75 = ~ quantile(., probs = 0.75),
      max = max,
      n = ~ n()
    ),
    .names = "{.fn}"
  )) %>%
  mutate(iqr = q75 - q25) %>%
  arrange(median)

# diet    q25 median   q75   max     n   iqr
# 1 AL     33.0   34.6  36.6  42.6    25  3.59
# 2 IF1    33.3   34.9  36.4  41.0    33  3.09
# 3 IF2    33.8   35.8  39.3  45.0    48  5.54
# 4 CR20   35.0   38.9  42.3  48.2    55  7.24
# 5 CR40   37.6   40.8  47.0  53.9    73  9.48

###
# n and timing of assessments
nrow(df) # 5957
min(df$collection_date) #  "2019-09-03"
max(df$collection_date) # 2021-12-21"
round(min(df_B6_t0$age_enroll), 1) # 22.7
round(min(df_DO_t0$age_enroll), 1) # 30.2
round(mean(df_B6_t0$age_enroll), 1) # 22.8
round(mean(df_DO_t0$age_enroll), 1) # 31.3


# FgI scores ----

round(range(df_B6$score_mean, na.rm = T), 2) # 0.02 0.48
round(range(df_DO$score_mean, na.rm = T), 2) # 0.02 0.57

df %>%
  group_by(strain) %>%
  summarize(across(score_mean,
    list(
      q25 = ~ quantile(., probs = 0.25, na.rm = TRUE),
      median = ~ median(., na.rm = TRUE),
      q75 = ~ quantile(., probs = 0.75, na.rm = TRUE),
      n = ~ n()
    ),
    .names = "{.fn}"
  )) %>%
  mutate(iqr = q75 - q25) %>%
  mutate_if(is.numeric, ~ round(., 2))
# strain     q25 median   q75     n   iqr
# C57BL/6J  0.17   0.22  0.27   892  0.1
# J:DO      0.2    0.27  0.33  5065  0.13

# n deficits ----

fragility_B6_max <-
  df_B6 %>%
  ungroup() %>%
  dplyr::group_by(id) %>%
  dplyr::summarise(
    score_sum_max = max(score_sum, na.rm = TRUE), # score sum = tally items rated severe
    score_mean_max = max(score_mean, na.rm = TRUE) # score mean = mean of item scores
  )

summary(fragility_B6_max$score_mean_max) %>% round(., 2)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
# 0.10    0.28    0.35    0.33    0.39    0.48

round(summary(fragility_B6_max$score_sum_max), 0)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
# 1       6       8       7       9      13

fragility_DO_max <-
  df_DO %>%
  ungroup() %>%
  dplyr::group_by(id) %>%
  dplyr::summarise(
    score_sum_max = max(score_sum, na.rm = TRUE),
    score_mean_max = max(score_mean, na.rm = TRUE)
  )

summary(fragility_DO_max$score_mean_max)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
# 0.1167  0.3500  0.3964  0.3897  0.4333  0.5667

round(summary(fragility_DO_max$score_sum_max), 0)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
# 1       8      10       9      11      17


# clear workspace ---------------------------------------------------------

rm(list = ls())
pacman::p_unload("all")
graphics.off()
# .rs.restartR()
