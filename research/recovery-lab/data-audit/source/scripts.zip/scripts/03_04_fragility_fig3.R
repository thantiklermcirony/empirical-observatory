#################################################################################################################
#################################################################################################################
######
######                Title: 03_04_fragility_fig3.R
######                
######                Project: Fragility
######
######                Description:  Sensitivity analyses for ROC curves. ML-FI in testing data with complete TxW 
######
######                Author: AL 
######
######                Date:  2023-10-19
######
#################################################################################################################
#################################################################################################################

# prep workspace ----------------------------------------------------------

if (!is.null(pacman::p_loaded())) { pacman::p_unload("all")}
rm(list = ls())
graphics.off()
library(groundhog)
pkgs <- c(
  "ggsci",
  "janitor",
  "patchwork",
  "slider",
  "rsample",
  "yardstick",
  "tidyverse"
)
groundhog.library(pkgs, "2023-03-27")
source(here::here("scripts", "fragility_vecs.R")) # helper vecs
source(here::here("scripts", "fragility_funs.R")) # helper funs
source(here::here("scripts", "fragility_funs_ml.R")) # ml funs

# import stack ------------------------------------------------------------

fragility_stack <- readRDS(here::here("results", "/fitted_stack.rds"))

# df prep ------------------------------------------------------------------

df <- df_process() 
df_ml <- df_process_ml() 
df_do <- df_ml %>% filter(strain == "J:DO") %>% select(-strain) 

# get testing dataframe - add TxW - drop_na  --------------

set.seed(20230501)
dat_split <- group_initial_split(data = df_do, group = id)
testing_data <- testing(dat_split) 
testing_data <- testing_data %>% txw_fun(.) %>% drop_na() %>% mutate(lifespan_p_95 = relevel(lifespan_p_95, ref = "Ref"))

# stack_test_fun ----------------------------------------------------------

  # for each sub-model in stack & overall:
  
  # preds in test set (class)
  fragility_stack_preds_by_m <-
    testing_data %>%
    select(lifespan_p_95) %>%
    bind_cols(predict(fragility_stack, testing_data, members = FALSE, type = "class"))
  
  # accuracy in test set
  accuracy <- map_dfr(
    setNames(colnames(fragility_stack_preds_by_m), colnames(fragility_stack_preds_by_m)),
    ~ mean(fragility_stack_preds_by_m$lifespan_p_95 == pull(fragility_stack_preds_by_m, .x))
  ) %>%
    pivot_longer(c(everything(), -lifespan_p_95)) %>%
    rename(accuracy = value)
  
  # preds in test set (probs)
  fragility_stack_preds_by_m <-
    testing_data %>%
    select(lifespan_p_95) %>%
    bind_cols(predict(fragility_stack, testing_data, members = FALSE, type = "prob")) 
  
  # roc auc in test set
  roc_auc <- fragility_stack_preds_by_m %>%
    pivot_longer(!lifespan_p_95) %>%
    filter(str_detect(name, "Event")) %>%
    group_by(name) %>%
    yardstick::roc_auc(., truth = lifespan_p_95, value, event_level = "first") %>%
    select(name, .estimate) %>%
    rename(auc = ".estimate") %>%
    mutate(name = str_replace(name, "Event", "class"))
  
  # pr auc in test set
  pr_auc <- fragility_stack_preds_by_m %>%
    pivot_longer(!lifespan_p_95) %>%
    filter(str_detect(name, "Event")) %>%
    group_by(name) %>%
    yardstick::pr_auc(., truth = lifespan_p_95, value, event_level = "first") %>%
    select(name, .estimate) %>%
    rename(pr_auc = ".estimate") %>%
    mutate(name = str_replace(name, "Event", "class"))
  
  # export metrics
  testing_set_metrics <- list(accuracy,  pr_auc, roc_auc) %>% # ppv, npv,
    reduce(left_join, by = "name") %>%
    mutate(across(where(is.numeric), ~ round(.x, digits = 3))) %>%
    mutate(
      model = case_when(
        name == ".pred_class" ~ "Ensemble",
        str_detect(name, "xg") ~ "XGB",
        str_detect(name, "svm") ~ "SVM",
        str_detect(name, "rf") ~ "RF",
        str_detect(name, "reg") ~ "RLR"
      ),
      preprocessor = case_when(
        name == ".pred_class" ~ NA,
        str_detect(name, "m0") ~ "M0",
        str_detect(name, "m1") ~ "M1",
        str_detect(name, "m2") ~ "M2",
        str_detect(name, "m3") ~ "M3"
      )
    ) %>%
    select(-c("name", "lifespan_p_95")) 
  
  # export ------------------------------------------------------------------
  
  write_csv(testing_set_metrics, here::here("results", "stack_testing_set_metrics_sensitivity.csv"))
  write_csv(fragility_stack_preds_by_m, here::here("results", "stack_probs_sensitivity.csv"))

  
  # generate ROC curves -----------------------------------------------------
  
  ###
  # import predictions on test data
  
  # stack_do <- read_csv(here::here("results", "stack_probs.csv")) %>% select(lifespan_p_95, value = .pred_Event) %>% mutate(name = "Ensemble")
  stack_do_sensitivity <-  read_csv(here::here("results", "stack_probs_sensitivity.csv")) %>% select(lifespan_p_95, value = .pred_Event) %>% mutate(name = "ML-FgI")
  txw_do <- read_csv(here::here("results", "txw_probs_do.csv")) %>% select(lifespan_p_95, name, value)
  txwxfi_do <- read_csv(here::here("results", "txwxfi_probs_do.csv")) %>% select(lifespan_p_95, name, value) %>% mutate(name = "TxW+FgI")
  all_preds_by_m_do <- rbind(stack_do_sensitivity, txw_do, txwxfi_do) %>% mutate_if(is.character, as.factor)
  
  ###
  # plot
  levels(all_preds_by_m_do$lifespan_p_95) # [1] "Event" "Ref"; roc_curve defaults to event = first level; o
  p_do <- main_roc_fun(all_preds_by_m_do) + labs(title = "J:DO")
  # write_rds(p_do, here::here("results", "Figure_3_sensitivity"))
  ggsave(here::here("results", "Figure_3_v2.pdf"))
  
  
  # clear workspace ---------------------------------------------------------
  
  rm(list = ls())
  pacman::p_unload('all')
  graphics.off()
  # .rs.restartR()

