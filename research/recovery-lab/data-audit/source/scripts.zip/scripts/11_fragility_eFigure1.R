#################################################################################################################
#################################################################################################################
######
######                Title: 11_fragility_eFigure1.R
######
######                Project: Fragility
######
######                Description:  Generate eFigure1
######
######                Author: AL
######
######                Date:  2023-08-15
######
#################################################################################################################
#################################################################################################################

# prep workspace ----------------------------------------------------------

if (!is.null(pacman::p_loaded())) {
  pacman::p_unload("all")
}
rm(list = ls())
graphics.off()
library(groundhog)
pkgs <- c(
  "tidyverse",
  "cowplot",
  "ggsci",
  "here",
  "janitor",
  "patchwork",
  "pacman"
)
groundhog.library(pkgs, "2023-03-27")
source(here::here("scripts", "fragility_vecs.R")) # helper vecs
source(here::here("scripts", "fragility_funs.R")) # helper funs

# df prep -----------------------------------------------------------------

df <- df_process() # data process

# plot -----------------------------------------------

legend.title <- "My title"

temp <- df %>%
  select(
    strain,
    sex,
    diet,
    lifespan_p,
    score_mean,
    body_weight,
    temperature,
    all_of(index_names)
  ) %>%
  pivot_longer(-c(strain, sex, diet, lifespan_p)) %>%
  group_by(name) %>%
  nest()

temp$legible <- append(c(
  "Frailty Score by PLL",
  "Body Weight",
  "Temperature"
), index_names_legible)
temp <- temp %>%
  mutate(plot = map2(
    data, legible,
    ~ .x %>%
      mutate(sex2 = ifelse(sex == "m", "Male", "Female")) %>%
      ggplot(., aes(
        linetype = paste0(strain, ", ", sex2),
        color = paste0(strain, ", ", sex2),
        x = lifespan_p,
        y = value
      )) +
      geom_smooth(
        method = "loess",
        na.rm = TRUE, se = T, size = 1, alpha = .2
      ) +
      guides(
        linetype = guide_legend(
          title = NULL,
          nrow = 3,
          override.aes = list(fill = NA),
          size = .2
        ),
        color = guide_legend(
          title = NULL,
          nrow = 3,
          override.aes = list(fill = NA)
        )
      ) +
      labs(title = str_wrap(.y, width=15), x = NULL, y = NULL) +
      coord_cartesian(xlim = c(.6, 1), ylim = c(0, 1)) +
      scale_color_npg() +
      theme(
        panel.grid.minor = element_blank(),
        legend.text = element_text(size = 12), 
        panel.background = element_blank(),
        axis.ticks.x = element_blank(),
        plot.title = element_text(size = 12), 
        legend.key = element_blank()
      )
  ))

temp$plot[[1]] <- temp$plot[[1]] + coord_cartesian(ylim = c(0, .4)) # FI
temp$plot[[2]] <- temp$plot[[2]] + coord_cartesian(ylim = c(20, 50)) # BW
temp$plot[[3]] <- temp$plot[[3]] + coord_cartesian(ylim = c(33, 37)) # Temp
plot_list <- temp$plot

supp_items <- index_names[!index_names %in% c(
  "score_mean",
  "body_weight",
  "temperature",
  "body_condition",
  "breathing_rate_depth",
  "coat_condition",
  "dehydration_reduced_skin_turgor",
  "distended_abdomen",
  "head_piloerection",
  "pallor_and_or_cyanosis",
  "tail_stiffening",
  "tremor",
  "tumors"
)]
temp_supp <- temp %>% filter(name %in% supp_items)
plot_list <- temp_supp$plot
legend <- cowplot::get_legend(plot_list[[1]] + theme(legend.position = "bottom"))
plot_list <- lapply(plot_list, function(x) x + theme(legend.position = "none"))
wrap_plots(plot_list)
ggsave(here::here("results", "eFigure_1.pdf"),
  scale = 1,
  width = 270,
  height = 270,
  unit = "mm",
  dpi = 300
)


# clear workspace ---------------------------------------------------------

rm(list = ls())
pacman::p_unload("all")
graphics.off()
# .rs.restartR()
