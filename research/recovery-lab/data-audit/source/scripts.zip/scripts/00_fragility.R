############################

# Fragility Script

############################

### begin

source(here::here("scripts", "01_fragility_fig1.R"))   
source(here::here("scripts", "02_fragility_fig2.R"))   
source(here::here("scripts", "03_01_fragility_fig3.R"))
source(here::here("scripts", "03_02_fragility_fig3.R"))
source(here::here("scripts", "03_03_fragility_fig3.R"))
source(here::here("scripts", "03_04_fragility_fig3.R"))
source(here::here("scripts", "04_fragility_fig4.R")) 
source(here::here("scripts", "05_fragility_table1.R")) 
source(here::here("scripts", "06_fragility_eTable6.R"))
source(here::here("scripts", "07_fragility_eTable2.R"))
source(here::here("scripts", "08_fragility_eTable3.R"))
source(here::here("scripts", "09_fragility_eTable4.R"))
source(here::here("scripts", "10_fragility_eTable5.R"))
source(here::here("scripts", "11_fragility_eFigure1.R"))
source(here::here("scripts", "12_fragility_eFigure2.R"))
source(here::here("scripts", "13_fragility_text_only.R"))
source(here::here("scripts", "14_fragility_butcher.R"))

### end