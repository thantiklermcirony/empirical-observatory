#################################################################################################################
#################################################################################################################
######
######                Title: 06_fragility_eTable6.R
######
######                Project: Fragility
######
######                Description:  Generate eTable 6
######
######                Author: AL
######
######                Date:  2023-08-15
######
#################################################################################################################
#################################################################################################################

# prep workspace ----------------------------------------------------------

if (!is.null(pacman::p_loaded())) {
  pacman::p_unload("all")
}
rm(list = ls())
graphics.off()
library(groundhog)
pkgs <- c(
  "tidyverse",
  "caret", 
  "here",
  "janitor",
  "slider", 
  "pacman"
)
groundhog.library(pkgs, "2023-03-27")
source(here::here("scripts", "fragility_vecs.R")) # helper vecs
source(here::here("scripts", "fragility_funs.R")) # helper funs

# df prep -----------------------------------------------------------------

df <- df_process() # data process

# TxW test --------------------------------------------------------------

df2 <- txw_fun(df)
df2 %>% nrow() # 5957
df2 %>%
  group_by(id) %>%
  n_groups() # 270
df2 %>%
  drop_na() %>%
  nrow() # 3730
df2 %>%
  drop_na() %>%
  group_by(id) %>%
  n_groups() # 199
df2 <- df2 %>% drop_na()

df2 <- df2 %>%
  mutate(
    lifespan_p_95 = factor(
      ifelse(lifespan_p < 0.95, "Ref", "Event"),
      levels = c("Ref", "Event")
    ), # truth
    txw_binary = factor(txw_binary, levels = c("Ref", "Event")) # pred
  )

metrics <- df2 %>%
  group_by(strain, sex, diet) %>%
  nest() %>%
  mutate(
    conf_matrix = map(data, ~ table(.x$txw_binary, .x$lifespan_p_95)),
    pred_events = map(data, ~ sum(.x$txw_binary == "Event")),
    obs_events = map(data, ~ sum(.x$lifespan_p_95 == "Event")),
    sens = map(conf_matrix, ~ caret::sensitivity(.x, positive = "Event") %>% round(., 3)),
    spec = map(conf_matrix, ~ caret::specificity(.x, negative = "Ref") %>% round(., 3)),
    npv = map(conf_matrix, ~ caret::negPredValue(.x, negative = "Ref") %>% round(., 3)),
    ppv = map(conf_matrix, ~ caret::posPredValue(.x, positive = "Event") %>% round(., 3))
  ) %>%
  select(-c("data", "conf_matrix")) %>%
  unnest(cols = -c("strain", "sex", "diet")) %>%
  mutate(sex = str_to_upper(sex)) %>%
  relocate(strain, sex, diet)
names(metrics) <- c(
  "Strain",
  "Sex",
  "Diet",
  "Predicted",
  "Observed",
  "Sensitivity",
  "Specificity",
  "NPV",
  "PPV"
)


# export ------------------------------------------------------------------


write_csv(metrics, here::here("results", "Supplement_eTable6.csv"))

# clear workspace ---------------------------------------------------------

rm(list = ls())
pacman::p_unload("all")
graphics.off()
# .rs.restartR()
