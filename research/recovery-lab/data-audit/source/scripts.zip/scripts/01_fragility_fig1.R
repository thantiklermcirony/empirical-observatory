#################################################################################################################
#################################################################################################################
######
######                Title: 01_fragility_fig1.R
######
######                Project: Fragility
######
######                Description:  Generates Figure 1
######
######                Author: AL
######
######                Date:  2023-08-15
######
#################################################################################################################
#################################################################################################################

# prep workspace ----------------------------------------------------------

if (!is.null(pacman::p_loaded())) {
  pacman::p_unload("all")
}
rm(list = ls())
graphics.off()
library(groundhog)
pkgs <- c(
  "tidyverse",
  "janitor",
  "here",
  "pacman"
)
groundhog.library(pkgs, "2023-03-27")
source(here::here("scripts", "fragility_vecs.R")) # helper vecs
source(here::here("scripts", "fragility_funs.R")) # helper funs

# df prep -----------------------------------------------------------------

df <- df_process() # data process

# plot --------------------------------------------------------------------

df <- df %>%
  group_split(diet) %>%
  purrr::map_df(~ .x %>%
    group_by(id) %>%
    mutate(newid = cur_group_id())) %>%
  ungroup() %>%
  bind_rows()

p <-
  ggplot2::ggplot(
    df %>% mutate(
      diet = ifelse(as.character(diet) == "1 Day Fast", "IF1", as.character(diet)),
      diet = ifelse(as.character(diet) == "2 Day Fast", "IF2", as.character(diet)),
      diet = ifelse(as.character(diet) == "20% CR", "CR20", as.character(diet)),
      diet = ifelse(as.character(diet) == "40% CR", "CR40", as.character(diet))
    ),
    aes(
      x = age_in_weeks / 4.34,
      y = newid,
      color = diet
    )
  ) +
  geom_point(size = .7) + 
  geom_vline(
    xintercept = c(24, 36, 48),
    size = .2,
    linetype = 2
  ) +
  scale_color_manual(values = colors5) +
  labs(x = "Age in Months") +
  theme(
    axis.ticks.y = element_blank(),
    axis.title.y = element_blank(),
    axis.line.y = element_blank(),
    legend.key = element_blank(),
    legend.background = element_blank(),
    panel.background = element_blank(),
    strip.background = element_rect(colour = "grey", fill = "white"),
    strip.text = element_text(size = 12),
    text = ggplot2::element_text(size = 12),
    axis.text.y = element_blank(),
    legend.title = element_text(size = 12)
  ) +
  guides(shape = guide_legend(override.aes = list(size = 3)), color = "none") +
  facet_wrap(
    diet ~ strain,
    ncol = 1,
    scales = "free_y",
    shrink = F,
    labeller = label_wrap_gen(multi_line = FALSE)
  ) +
  scale_x_continuous(breaks = round(seq(20, max(df$age_in_weeks / 4.34), by = 4), 0))

p
ggsave(
  here::here("results", "Figure_1.pdf"),
  plot = p,
  scale = 1.5,
  width = 160,
  height = 160,
  unit = "mm",
  dpi = 300
)


# note --------------------------------------------------------------------

###
# n assessments
nrow(df) # 5957

###
# n assessments per mouse
df %>%
  group_by(id) %>%
  summarize(n = n()) %>%
  ungroup() %>%
  summarize(median = median(n), q25 = quantile(n, probs = c(.25)), q75 = quantile(n, probs = c(.75)))
# median   q25   q75
#  18     9    30

###
# when assessments
min(df$collection_date) #  "2019-09-03"
max(df$collection_date) # 2021-12-21"

###
# n mice
df %>%
  group_by(id) %>%
  n_groups() # 270

# clear workspace ---------------------------------------------------------

rm(list = ls())
p_unload("all")
graphics.off()
# .rs.restartR()
