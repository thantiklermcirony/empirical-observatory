#################################################################################################################
#################################################################################################################
######
######                Title: 07_fragility_eTable2.R
######
######                Project: Fragility
######
######                Description:  Generate eTable 2 - Cumulative incidence in J:DO
######
######                Author: AL
######
######                Date:  2023-08-15
######
#################################################################################################################
#################################################################################################################

# prep workspace ----------------------------------------------------------

if (!is.null(pacman::p_loaded())) {
  pacman::p_unload("all")
}
rm(list = ls())
graphics.off()
library(groundhog)
pkgs <- c(
  "tidyverse",
  "here",
  "janitor",
  "table1"
)
groundhog.library(pkgs, "2023-03-27")
source(here::here("scripts", "fragility_vecs.R")) # helper vecs
source(here::here("scripts", "fragility_funs.R")) # helper funs

# df prep -----------------------------------------------------------------

df <- df_process() # data process
df_DO <- df %>% filter(strain == "J:DO")

# Supplement  ------------------------------------------------------------


df_DO_CI <- df_DO %>%
  dplyr::group_by(id, diet) %>%
  dplyr::summarise(across(all_of(c(index_names_fct)), ~ max(.x, na.rm = TRUE), .names = "{.col}")) %>%
  relocate(id, diet, sort(index_names_fct))
names(df_DO_CI) <- c("ID", "Diet", sort(index_names_legible))

etable_2 <- tab1_fun(df_DO_CI, "Diet") %>%
  as.data.frame() 


# export ------------------------------------------------------------------

write_csv(etable_2, here::here("results", "Supplement_eTable2.csv"))

# clear workspace ---------------------------------------------------------

rm(list = ls())
pacman::p_unload('all')
graphics.off()
# .rs.restartR()

