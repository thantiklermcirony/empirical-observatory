#################################################################################################################
#################################################################################################################
######
######                Title: 03_02_fragility_fig3.R
######
######                Project: Fragility
######
######                Description:  Generate predicted probabilities for TxW and TxW+FgI
######
######                Author: AL
######
######                Date:  2023-08-15
######
#################################################################################################################
#################################################################################################################

# prep workspace ----------------------------------------------------------

if (!is.null(pacman::p_loaded())) {
  pacman::p_unload("all")
}
rm(list = ls())
graphics.off()
library(groundhog)
pkgs <- c(
  "janitor",
  "lme4",
  "slider",
  "tidymodels",
  "tidyverse"
)
groundhog.library(pkgs, "2023-03-27")
source(here::here("scripts", "fragility_vecs.R")) # helper vecs
source(here::here("scripts", "fragility_funs.R")) # helper funs
source(here::here("scripts", "fragility_funs_ml.R")) # ml funs

# df prep ------------------------------------------------------------------

df <- df_process()
df_ml <- df_process_ml()

# subset df to conduct analysis separately in parallel

df_do <- df_ml %>%
  filter(strain == "J:DO") %>%
  select(-strain)

df_b6 <- df_ml %>%
  filter(strain != "J:DO") %>%
  select(-strain)

# generate grouped initial data splits  --------------

# J:DO

set.seed(20230501)
dat_split_do <- group_initial_split(data = df_do, group = id)
training_data_do <- training(dat_split_do) %>%
  mutate(strain = "J:DO") %>%
  as.data.frame()
testing_data_do <- testing(dat_split_do) %>%
  mutate(strain = "J:DO") %>%
  as.data.frame()

# B6

set.seed(20230501)
dat_split_b6 <- group_initial_split(data = df_b6, group = id)
training_data_b6 <- training(dat_split_b6) %>%
  mutate(strain = "C57BL/6J") %>%
  as.data.frame()
testing_data_b6 <- testing(dat_split_b6) %>%
  mutate(strain = "C57BL/6J") %>%
  as.data.frame()

# n's

print(paste("DO ns train/test:", nrow(training_data_do), "/", nrow(testing_data_do))) # "DO ns train/test: 3524 / 1195"
print(paste("B6 ns train/test:", nrow(training_data_b6), "/", nrow(testing_data_b6))) # "B6 ns train/test: 661 / 211"

# generate TxW & TxW+FI models in training data; get pred probs in test data -----------------------------------------

training_data <- rbind(training_data_do, training_data_b6) %>%
  txw_fun(.) %>%
  drop_na() %>%
  mutate(lifespan_p_95 = relevel(lifespan_p_95, ref = "Ref"))
testing_data <- rbind(testing_data_do, testing_data_b6) %>%
  txw_fun(.) %>%
  drop_na() %>%
  mutate(lifespan_p_95 = relevel(lifespan_p_95, ref = "Ref"))

models <- training_data %>%
  group_by(strain) %>%
  nest() %>%
  mutate(
    txw = map(data, ~ glmer(lifespan_p_95 ~ txw_binary + (1 | id), family = "binomial", data = .x, control = glmerControl(optimizer = "bobyqa"))),
    txwxfi = map(data, ~ glmer(lifespan_p_95 ~ txw_binary + score_mean + (1 | id), family = "binomial", data = .x, control = glmerControl(optimizer = "bobyqa")))
  )

out <- testing_data %>%
  group_by(strain) %>%
  nest() %>%
  left_join(models, by = c("strain"), suffix = c("_testing", "_training")) %>%
  mutate(
    n_training = map(data_training, ~ nrow(.x)),
    n_testing = map(data_testing, ~ nrow(.x)),
    txw_probs = map2(txw, data_testing, ~ bind_cols(predict(.x, newdata = .y, type = "response", re.form = NA), .y)), # fitted values, unconditional
    txwxfi_probs = map2(txwxfi, data_testing, ~ bind_cols(predict(.x, newdata = .y, type = "response", re.form = NA), .y)), # fitted values, unconditional
    txw_probs = map(txw_probs, ~ .x %>%
      rename(value = `...1`) %>%
      mutate(name = "TxW") %>%
      select(lifespan_p_95, name, value)),
    txwxfi_probs = map(txwxfi_probs, ~ .x %>%
      rename(value = `...1`) %>%
      mutate(name = "TxW+FI") %>%
      select(lifespan_p_95, name, value)),
    txw_roc_auc = map(txw_probs, ~ roc_auc(data = .x, value, truth = lifespan_p_95, estimator = "binary", event_level = "second")),
    txwxfi_roc_auc = map(txwxfi_probs, ~ roc_auc(data = .x, value, truth = lifespan_p_95, estimator = "binary", event_level = "second"))
  )

# replace w/ NA if model was singular
out <- out %>%
  mutate(
    txw_probs = map2(txw, txw_probs, ~ if (is_warning_generated(.x) == TRUE) {
      .x <- NA
    } else {
      .y
    }),
    txwxfi_probs = map2(txwxfi, txwxfi_probs, ~ if (is_warning_generated(.x) == TRUE) {
      .x <- NA
    } else {
      .y
    })
  )


out %>%
  select(txw_probs) %>%
  unnest(cols = txw_probs) %>%
  filter(strain == "J:DO") %>%
  write_csv(here::here("results", "txw_probs_do.csv"))
out %>%
  select(txwxfi_probs) %>%
  unnest(cols = txwxfi_probs) %>%
  filter(strain == "J:DO") %>%
  write_csv(here::here("results", "txwxfi_probs_do.csv"))
out %>%
  select(txw_roc_auc) %>%
  unnest(cols = txw_roc_auc) %>%
  filter(strain == "J:DO") %>%
  write_csv(here::here("results", "txw_roc_auc_do.csv"))
out %>%
  select(txwxfi_roc_auc) %>%
  unnest(cols = txwxfi_roc_auc) %>%
  filter(strain == "J:DO") %>%
  write_csv(here::here("results", "txwxfi_roc_auc_do.csv"))
out %>%
  select(txw_probs) %>%
  unnest(cols = txw_probs) %>%
  filter(strain == "C57BL/6J") %>%
  write_csv(here::here("results", "txw_probs_b6.csv"))
out %>%
  select(txwxfi_probs) %>%
  unnest(cols = txwxfi_probs) %>%
  filter(strain == "C57BL/6J") %>%
  write_csv(here::here("results", "txwxfi_probs_b6.csv"))
out %>%
  select(txw_roc_auc) %>%
  unnest(cols = txw_roc_auc) %>%
  filter(strain == "C57BL/6J") %>%
  write_csv(here::here("results", "txw_roc_auc_b6.csv"))
out %>%
  select(txwxfi_roc_auc) %>%
  unnest(cols = txwxfi_roc_auc) %>%
  filter(strain == "C57BL/6J") %>%
  write_csv(here::here("results", "txwxfi_roc_auc_b6.csv"))

# clear workspace ---------------------------------------------------------

rm(list = ls())
pacman::p_unload("all")
graphics.off()
# .rs.restartR()
