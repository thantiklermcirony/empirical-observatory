# ML-specific function definition(s) and setups ----

.grid_size <- 25
# .grid_size <- 5

is_warning_generated <- function(.x) {
  df <- summary(.x)
  !is.null(df$optinfo$conv$lme4$messages) &&
    grepl("singular", df$optinfo$conv$lme4$messages)
}

ml_binary_fun <- function() {
  # import ------------------------------------------------------------------

  dat_split <- get("dat_split")
  training_data <- get("training_data")
  testing_data <- get("testing_data")
  cv_split <- get("cv_split")

  # model defs --------------------------------------------------------------

  rf_tune_model <-
    rand_forest(
      mtry = tune(),
      min_n = tune(),
      # trees=1e3
    ) %>%
    set_engine("ranger", importance = "impurity", respect.unordered.factors = TRUE) %>%
    set_mode("classification")

  xg_tune_model <-
    boost_tree(
      mode = "classification",
      trees = tune(),
      mtry = tune(),
      tree_depth = tune(),
      learn_rate = tune(),
      loss_reduction = tune(),
      min_n = tune()
    )

  reg_tune_model <-
    logistic_reg(
      penalty = tune(),
      mixture = tune()
    ) %>%
    set_engine("glmnet") %>%
    set_mode("classification")

  svm_tune_model <-
    svm_rbf(
      cost = tune(),
      rbf_sigma = tune()
    ) %>%
    set_mode("classification")

  # preprocessors -----------------------------------------------------------

  m0_vars <- c("age_in_weeks", "diet", "sex")
  m1_vars <- c(m0_vars, "body_weight", "temperature", "body_weight_30d_delta", "temperature_30d_delta")
  m2_vars <- c(m1_vars, "score_mean")

  m0_recipe <-
    recipe(training_data) %>%
    update_role(everything()) %>%
    update_role(id, new_role = "ID") %>%
    update_role(collection_date, new_role = "ID2") %>%
    update_role(lifespan_p_95, new_role = "outcome") %>%
    step_rm(all_predictors(), -all_of(m0_vars)) %>%
    step_unorder(all_nominal_predictors()) %>%
    step_dummy(all_nominal_predictors(), one_hot = TRUE) %>%
    step_zv(all_predictors()) %>%
    step_normalize(all_numeric_predictors()) %>%
    themis::step_upsample(lifespan_p_95, seed = 20230327)

  m1_recipe <-
    recipe(training_data) %>%
    update_role(everything()) %>%
    update_role(id, new_role = "ID") %>%
    update_role(collection_date, new_role = "ID2") %>%
    update_role(lifespan_p_95, new_role = "outcome") %>%
    step_rm(all_predictors(), -all_of(m1_vars)) %>%
    step_unorder(all_nominal_predictors()) %>%
    step_dummy(all_nominal_predictors(), one_hot = TRUE) %>%
    step_zv(all_predictors()) %>%
    step_normalize(all_numeric_predictors()) %>%
    themis::step_upsample(lifespan_p_95, seed = 20230327)

  m2_recipe <-
    recipe(training_data) %>%
    update_role(everything()) %>%
    update_role(id, new_role = "ID") %>%
    update_role(collection_date, new_role = "ID2") %>%
    update_role(lifespan_p_95, new_role = "outcome") %>%
    step_rm(all_predictors(), -all_of(m2_vars)) %>%
    step_unorder(all_nominal_predictors()) %>%
    step_dummy(all_nominal_predictors(), one_hot = TRUE) %>%
    step_zv(all_predictors()) %>%
    step_normalize(all_numeric_predictors()) %>%
    themis::step_upsample(lifespan_p_95, seed = 20230327)

  m3_recipe <-
    recipe(training_data) %>%
    update_role(everything()) %>%
    update_role(id, new_role = "ID") %>%
    update_role(collection_date, new_role = "ID2") %>%
    update_role(lifespan_p_95, new_role = "outcome") %>%
    step_unorder(all_nominal_predictors()) %>%
    step_dummy(all_nominal_predictors(), one_hot = TRUE) %>%
    step_zv(all_predictors()) %>%
    # concurrent items
    step_pca(
      ends_with(paste0(!!index_names_fct, "_Absent")),
      ends_with(paste0(!!index_names_fct, "_Mild")),
      ends_with(paste0(!!index_names_fct, "_Severe")),
      options = list(center = TRUE, scale. = TRUE),
      prefix = "0d_"
    ) %>%
    # 30-day delta items
    step_pca(
      starts_with(paste0(!!index_names_fct, "_30d")),
      options = list(center = TRUE, scale. = TRUE),
      prefix = "30d_"
    ) %>%
    step_normalize(all_numeric_predictors()) %>%
    themis::step_upsample(lifespan_p_95, seed = 20221028)


  # generate wfs ---------------------------------------------------------

  wf_set <-
    workflow_set(
      preproc = list(
        m0_xs = m0_recipe,
        m1_xs = m1_recipe,
        m2_xs = m2_recipe,
        m3_xs = m3_recipe
      ),
      models = list(
        rf = rf_tune_model,
        xg = xg_tune_model,
        reg = reg_tune_model,
        svm = svm_tune_model
      ),
      cross = TRUE
    )

  # tune wfs ---------------------------------------------------------------

  cores <- parallel::detectCores(logical = FALSE)
  cores
  cl <- makePSOCKcluster(cores)
  registerDoParallel(cl)
  tuned_wfs <-
    wf_set %>%
    workflow_map(
      "tune_race_anova",
      seed = 20230327,
      resamples = cv_split,
      grid = .grid_size,
      control =
        control_race(
          save_pred = TRUE,
          save_workflow = TRUE,
          verbose = TRUE,
          parallel_over = "everything"
        ),
      metrics = metric_set(roc_auc)
    )
  doParallel::stopImplicitCluster()

  return(tuned_wfs)
}


stack_fit_fun <- function() {
  # import ------------------------------------------------------------------

  tuned_wfs <- get("tuned_wfs")
  training_data <- get("training_data")
  testing_data <- get("testing_data")

  # ensemble ----------------------------------------------------------------

  fragility_stack <-
    stacks() %>%
    add_candidates(tuned_wfs) %>% # https://stacks.tidymodels.org/articles/workflowsets.html
    blend_predictions() %>%
    fit_members()

  saveRDS(fragility_stack, here::here("results", "/fitted_stack.rds"))
  return(fragility_stack)
}

stack_test_fun <- function() {
  # import ------------------------------------------------------------------

  fragility_stack <- get("fragility_stack")
  testing_data <- get("testing_data")

  # test --------------------------------------------------------------------

  # for each sub-model in stack & overall:

  # preds in test set (class)
  fragility_stack_preds_by_m <-
    testing_data %>%
    select(lifespan_p_95) %>%
    bind_cols(predict(fragility_stack, testing_data, members = FALSE, type = "class"))

  # accuracy in test set
  accuracy <- map_dfr(
    setNames(colnames(fragility_stack_preds_by_m), colnames(fragility_stack_preds_by_m)),
    ~ mean(fragility_stack_preds_by_m$lifespan_p_95 == pull(fragility_stack_preds_by_m, .x))
  ) %>%
    pivot_longer(c(everything(), -lifespan_p_95)) %>%
    rename(accuracy = value)

  # ppv in test set
  ppv <- fragility_stack_preds_by_m %>%
    pivot_longer(!lifespan_p_95) %>%
    group_by(name) %>%
    yardstick::ppv(., truth = lifespan_p_95, value, event_level = "first") %>%
    select(name, .estimate) %>%
    rename(ppv = ".estimate")

  # npv in test set
  npv <- fragility_stack_preds_by_m %>%
    pivot_longer(!lifespan_p_95) %>%
    group_by(name) %>%
    yardstick::npv(., truth = lifespan_p_95, value, event_level = "first") %>%
    select(name, .estimate) %>%
    rename(npv = ".estimate")

  # preds in test set (probs)
  fragility_stack_preds_by_m <-
    testing_data %>%
    select(lifespan_p_95) %>%
    bind_cols(predict(fragility_stack, testing_data, members = FALSE, type = "prob"))

  # roc auc in test set
  roc_auc <- fragility_stack_preds_by_m %>%
    pivot_longer(!lifespan_p_95) %>%
    filter(str_detect(name, "Event")) %>%
    group_by(name) %>%
    yardstick::roc_auc(., truth = lifespan_p_95, value, event_level = "first") %>%
    select(name, .estimate) %>%
    rename(auc = ".estimate") %>%
    mutate(name = str_replace(name, "Event", "class"))

  # pr auc in test set
  pr_auc <- fragility_stack_preds_by_m %>%
    pivot_longer(!lifespan_p_95) %>%
    filter(str_detect(name, "Event")) %>%
    group_by(name) %>%
    yardstick::pr_auc(., truth = lifespan_p_95, value, event_level = "first") %>%
    select(name, .estimate) %>%
    rename(pr_auc = ".estimate") %>%
    mutate(name = str_replace(name, "Event", "class"))

  # export metrics
  testing_set_metrics <- list(accuracy, ppv, npv, pr_auc, roc_auc) %>%
    reduce(left_join, by = "name") %>%
    mutate(across(where(is.numeric), ~ round(.x, digits = 3))) %>%
    mutate(
      model = case_when(
        name == ".pred_class" ~ "Ensemble",
        str_detect(name, "xg") ~ "XGB",
        str_detect(name, "svm") ~ "SVM",
        str_detect(name, "rf") ~ "RF",
        str_detect(name, "reg") ~ "RLR"
      ),
      preprocessor = case_when(
        name == ".pred_class" ~ NA,
        str_detect(name, "m0") ~ "M0",
        str_detect(name, "m1") ~ "M1",
        str_detect(name, "m2") ~ "M2",
        str_detect(name, "m3") ~ "M3"
      )
    ) %>%
    select(-c("name", "lifespan_p_95"))

  # export ------------------------------------------------------------------

  write_csv(testing_set_metrics, here::here("results", "stack_testing_set_metrics.csv"))
  write_csv(fragility_stack_preds_by_m, here::here("results", "stack_probs.csv"))
}

main_roc_fun <- function(.x) {
  .x %>%
    group_by(name) %>%
    roc_curve(truth = lifespan_p_95, value) %>%
    mutate(name = factor(name, levels = c("TxW", "TxW+FgI", "ML-FgI"))) %>% 
    rename(Sensitivity = sensitivity, Specificity = specificity) %>%
    # autoplot() +
    ggplot(aes(x = 1 - Specificity, y = Sensitivity, color = name)) +
    geom_path(size = 1) +
    geom_abline(lty = 3) +
    coord_equal() +
    scale_color_npg() +
    theme_classic(base_size=14) +
    theme(legend.position = "top",
          legend.title = element_blank(),
          legend.text = element_text(size=14)
          )
}


df_process_ml <- function() {
  df <-
    df %>%
    select(
      # process vars
      id, collection_date, strain,
      # raw predictors
      age_in_weeks, sex, diet, body_weight, temperature, all_of(index_names_fct), score_mean,
      # outcomes
      lifespan_p
    ) %>%
    group_by(id) %>%
    arrange(collection_date, .by_group = T) %>%
    # prep for as.numeric so absent->severe is equivalent distance for two- and three-level items
    mutate(across(c(response_to_external_stimuli_fct, diarrhea_fct), ~ fct_expand(.x, "Mild", after = 1))) %>%
    # Feature engineering
    mutate(

      # 30-day Rolling Delta
      across(all_of(index_names_fct),
        ~ slide_index_dbl(
          .x,
          collection_date,
          ~ last(na.omit(as.numeric(.x))) - first(na.omit(as.numeric(.x))),
          .before = lubridate::days(30)
        ),
        .names = "{.col}_30d_delta"
      ),

      # 30-day % diff

      across(c("body_weight", "temperature"),
        ~ slide_index_dbl(
          .x,
          collection_date,
          ~ 100 * ((last(na.omit(.x)) - first(na.omit(.x))) / first(na.omit(.x))),
          .before = lubridate::days(30)
        ),
        .names = "{.col}_30d_delta"
      )
    ) %>%
    ungroup() %>%
    # 30-day % diff indicator
    mutate(body_weight_30d_delta_threshold = ifelse(body_weight_30d_delta <- 10 | body_weight_30d_delta > 8, TRUE, FALSE)) %>%
    # var class
    mutate_if(is_logical, as_factor) %>%
    # outcome
    mutate(lifespan_p_95 = factor(ifelse(lifespan_p < 0.95, "Ref", "Event"))) # outcome

  df_ml <-
    df %>%
    # keep if >=30d data
    group_by(id) %>%
    filter(last(collection_date) - first(collection_date) >= 30) %>%
    ungroup() %>%
    # select vars
    select(
      # ids
      id, collection_date,
      # outcome
      lifespan_p_95,
      # features
      age_in_weeks,
      sex,
      strain,
      diet,
      body_weight, temperature,
      all_of(index_names_fct),
      contains("30"),
      score_mean
    )

  print("IDs with less than 30 days between first and last collection_date?")
  df %>%
    group_by(id) %>%
    filter(!last(collection_date) - first(collection_date) >= 30) %>%
    distinct(id, strain) %>%
    tabyl(strain) %>%
    print() # n <30d data = 6 B6, 29 DO
  print("N IDs before excluding IDs w/ <30 days in study?")
  df %>%
    group_by(id) %>%
    n_groups() %>%
    print() # 270
  print("N IDs total left in ML?")
  df_ml %>%
    group_by(id) %>%
    n_groups() %>%
    print() # 235
  print("N assessments before excluding IDs w/ <30 days in study?")
  df %>%
    nrow() %>%
    print() # 5957
  print("N assessments left in ML? Includes B6 and DO")
  df_ml %>%
    nrow() %>%
    print() # 5867
  print("N assessments left in ML df - DO only?")
  df_ml %>%
    filter(strain == "J:DO") %>%
    nrow() %>%
    print() # 4995

  # explore na
  # most are related to early assessments before 2 items added
  # rest are 5 with missing temperature
  a <- df_ml %>%
    filter(rowAny(
      across(
        .cols = everything(),
        .fns = ~ is.na(.x)
      )
    )) %>%
    nrow()
  b <- df_ml %>% nrow()
  a # n grps = 276
  b # n assessments = 5867
  (a / b) * 100 < 5 # TRUE
  rm(a, b)

  # repeat in J:DO only
  a <- df_ml %>%
    filter(strain == "J:DO") %>%
    filter(rowAny(
      across(
        .cols = everything(),
        .fns = ~ is.na(.x)
      )
    )) %>%
    nrow() # 4995
  b <- df_ml %>%
    filter(strain == "J:DO") %>%
    nrow()
  a # n grps = 276
  b # n assessments = 4995
  (a / b) * 100 < 5 # TRUE
  rm(a, b)

  # drop if any na
  df_ml <- df_ml %>% drop_na()
  print("After dropping any na - how many assessments remain?")
  df_ml %>%
    nrow() %>%
    print() # 5591

  return(df_ml)
}
