#################################################################################################################
#################################################################################################################
######
######                Title: 08_fragility_eTable3.R
######
######                Project: Fragility
######
######                Description:  Generate eTable3, Cumulative incidence in C57BL/6J
######
######                Author: AL
######
######                Date:  2023-08-15
######
#################################################################################################################
#################################################################################################################

# prep workspace ----------------------------------------------------------

if (!is.null(pacman::p_loaded())) {
  pacman::p_unload("all")
}
rm(list = ls())
graphics.off()
library(groundhog)
pkgs <- c(
  "tidyverse",
  "here",
  "janitor",
  "table1"
)
groundhog.library(pkgs, "2023-03-27")
source(here::here("scripts", "fragility_vecs.R")) # helper vecs
source(here::here("scripts", "fragility_funs.R")) # helper funs

# df prep -----------------------------------------------------------------

df <- df_process() # data process
df_B6 <- df %>% filter(strain == "C57BL/6J")

# eTable3 ------------------------------------------------------------

df_B6_CI <- df_B6 %>%
  dplyr::group_by(id, sex) %>%
  dplyr::summarise(across(all_of(c(index_names_fct)), ~ max(.x, na.rm = TRUE), .names = "{.col}")) %>%
  relocate(id, sex, sort(index_names_fct))
names(df_B6_CI) <- c("ID", "Sex", sort(index_names_legible))

etable_3 <- tab1_fun(df_B6_CI, "Sex") %>%
  as.data.frame() 


# export ------------------------------------------------------------------

write_csv(etable_3, here::here("results", "Supplement_eTable3.csv"))

# clear workspace ---------------------------------------------------------

rm(list = ls())
pacman::p_unload('all')
graphics.off()
# .rs.restartR()

