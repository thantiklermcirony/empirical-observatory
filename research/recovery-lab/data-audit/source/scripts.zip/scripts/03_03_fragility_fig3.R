#################################################################################################################
#################################################################################################################
######
######                Title: 03_03_fragility_fig3.R
######
######                Project: Fragility
######
######                Description: Compare TxW, TxW+FgI, and FgI_ML ensemble via ROC curve
######
######                Author: AL
######
######                Date:  2023-08-15
######
#################################################################################################################
#################################################################################################################

# prep workspace ----------------------------------------------------------

if (!is.null(pacman::p_loaded())) {
  pacman::p_unload("all")
}
rm(list = ls())
graphics.off()
library(groundhog)
pkgs <- c(
  "ggsci",
  "janitor",
  "patchwork",
  "slider",
  "yardstick",
  "tidyverse"
)
groundhog.library(pkgs, "2023-03-27")
source(here::here("scripts", "fragility_vecs.R")) # helper vecs
source(here::here("scripts", "fragility_funs.R")) # helper funs
source(here::here("scripts", "fragility_funs_ml.R")) # ml funs

# generate ROC curves -----------------------------------------------------

# import predictions on test data
stack_do <- read_csv(here::here("results", "stack_probs.csv")) %>%
  select(lifespan_p_95, value = .pred_Event) %>%
  mutate(name = "ML-FgI")
txw_do <- read_csv(here::here("results", "txw_probs_do.csv")) %>% select(lifespan_p_95, name, value)
txwxfi_do <- read_csv(here::here("results", "txwxfi_probs_do.csv")) %>%
  select(lifespan_p_95, name, value) %>%
  mutate(name = "TxW+FgI")
all_preds_by_m_do <- rbind(stack_do, txw_do, txwxfi_do) %>% mutate_if(is.character, as.factor)

# plot
levels(all_preds_by_m_do$lifespan_p_95) # [1] "Event" "Ref"; roc_curve defaults to event = first level
p_do <- main_roc_fun(all_preds_by_m_do)
ggsave(here::here("results", "Figure_3.pdf"))

# clear workspace ---------------------------------------------------------

rm(list = ls())
pacman::p_unload("all")
graphics.off()
# .rs.restartR()
