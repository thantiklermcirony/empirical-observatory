# Function definition(s) and setups ----

select <- dplyr::select

max_fun <- function(x) ifelse(!all(is.na(x)), max(x, na.rm = T), NA)

min_fun <- function(x) ifelse(!all(is.na(x)), min(x, na.rm = T), NA)

rowAny <- function(x) rowSums(x) > 0

surv_plot_fun <- function(.df, .grp, .y, .d, .covar, .xmin, .xmax, .p.x, .p.y) {
  
  dat <- .df

  fit <- survminer::surv_fit(Surv(dat[[.y]], dat[[.d]]) ~ dat[[.covar]], data = dat)  

  test <- survdiff(Surv(dat[[.y]], dat[[.d]]) ~ dat[[.covar]], rho = 0, data = dat)

  pval <- pchisq(test$chisq, df = 4, lower.tail = FALSE)

  ggsurvplot(
    fit,
    data = dat,
    xlim = c(.xmin, .xmax),
    ylim = c(0, 1),
    legend.labs= paste0(.grp, ":", str_to_upper(levels(dat[[.covar]]))),
    surv.median.line = "hv", 
    palette = colors5
  ) %>% .$plot +
    annotate(
      "text",
      x = .p.x,
      y = .p.y,
      size = 5,
      hjust = "left",
      label = paste0("p=", format.pval(pval, digits = 2))
    ) +
    scale_x_continuous(n.breaks = 5) +
    scale_y_continuous(n.breaks = 5) +
    theme(
      legend.text = element_text(size = 14),
      legend.title = element_blank(),
      legend.position = "bottom",
      axis.text.x = element_text(angle = 45, hjust = 1)
    ) +
    labs(y = "p(survival)", 
         x = paste( str_to_sentence(.y), "(months)"))
}

pvalue <- function(x, ...) {
  # runif(1,0,10^8) #99860556
  set.seed(99860556)
  y <- unlist(x)
  g <- factor(rep(1:length(x), times = sapply(x, length)))
  p <- tryCatch(fisher.test(table(y, droplevels(g)), simulate.p.value = TRUE)$p.value, error = function(err) NA)
  c("", sub("&lt;", "<", format.pval(p, digits = 3, eps = 0.001)))
}

txw_fun <- function(.x) {
  .x %>%
    group_by(id) %>%
    arrange(collection_date, .by_group = T) %>%
    mutate(txw = temperature * body_weight) %>%
    mutate(
      across(
        c("txw"),
        ~ slide_index_dbl(
          as.numeric(.x),
          collection_date,
          ~ mean(.x, na.rm = TRUE),
          .before = lubridate::weeks(14),
          .after = lubridate::weeks(-10)
        ),
        .names = "{.col}_phase1"
      ),
      across(
        c("txw"),
        ~ slide_index_dbl(
          as.numeric(.x),
          collection_date,
          ~ mean(.x, na.rm = TRUE),
          .before = lubridate::weeks(3)
        ),
        .names = "{.col}_phase3"
      )
    ) %>%
    ungroup() %>%
    mutate(
      txw_phase3_delta = 100 * ((txw_phase3 - txw_phase1) / txw_phase1),
      txw_binary = factor(ifelse(txw_phase3_delta > -10, "Ref", "Event"))
    ) %>%
    select(-txw, -contains("phase"))
}

tab1_fun <- function(.data, .group) {
  table1::table1(
    ~
      `Activity` +
        `Body Condition` +
        `Breathing Rate/Depth` +
        `Changes to Eye Globe` +
        `Coat Condition` +
        `Dehydration, Skin Turgor` +
        `Dermatitis` +
        `Diarrhea` +
        `Distended Abdomen` +
        `Eye Discharge/Eyelid Inflammation ` +
        `Gait Disorders` +
        `Head Piloerection` +
        `Hunched` +
        `Kyphosis` +
        `Malocclusions` +
        `Nasal Discharge` +
        `Pallor/Cyanosis` +
        `Paralysis` +
        `Peri-retro-orbital Swelling` +
        `Piloerection` +
        `Rectal Prolapse` +
        `Response to Analgesic` +
        `Response to External Stimuli` +
        `Tail Stiffening` +
        `Thoracic Mass` +
        `Tremor` +
        `Tumors` +
        `Urine` +
        `Vaginal/Uterine Prolapse` +
        `Vestibular Disturbance` |
        .data[[.group]],
    data = .data,
    overall = F,
    render.missing = NULL,
    render.categorical = "FREQ (PCTnoNA%)",
    extra.col = list(`P-value` = pvalue)
  )
}


df_process <- function() {
  
  # import data -------------------------------------------------------------
  
  df <- read_csv(here::here("data", "fragility_longitudinal_mpd.csv"))
  
  # edit id, per G.C.
  
  df <- df %>% mutate(id= if_else(id == "DO-AL-0097", "DO-AL-0105", id))

  # initial prep -------------------------------------------------------------

  df <- df %>%
    pivot_longer(
      -c(id, date_born, date_exit, exit_reason, sex, diet, strain, has_clinical_record),
      names_to = c(".value", "n"),
      names_sep = "_(?!.*_)",
      values_drop_na = T
    ) %>%
    mutate(
      diet = forcats::as_factor(diet),
      sex = forcats::as_factor(sex),
    )

  # Generate vars -----------------------------------------------------------

  df <-
    df %>%
    group_by(id) %>%
    arrange(collection_date, .by_group = TRUE) %>%
    ungroup() %>%
    mutate(
      age_in_weeks = as.numeric(difftime(collection_date, date_born, units = "weeks")),
      lifespan = as.numeric(difftime(date_exit, date_born, units = "weeks")),
      lifespan_residual = as.numeric(difftime(date_exit, collection_date, units = "weeks")),
      lifespan_p = age_in_weeks / lifespan,
    ) %>%
    group_by(id) %>%
    arrange(collection_date, .by_group = TRUE) %>%
    mutate(
      age_enroll = min(age_in_weeks),
      n = row_number(),
      N = n()
    ) %>%
    ungroup()

  # format ordinal items ----------------------------------------------------

  # dermatitis

  # only one response in the 1-2cm group.
  # collapse <1 cm and 1-2 cm into one "Mild" category.

  fct_count(as.character(df$dermatitis))
  # f         n
  # <fct> <int>
  # 0      6163
  # 0.25    128
  # 0.75      1 <--
  # 1        25

  df <-
    df %>%
    mutate(dermatitis = ifelse(dermatitis %in% c(0.25, 0.75), .5, dermatitis))

  # diarrhea

  df <- df %>%
    mutate(diarrhea_fct = forcats::as_factor(diarrhea)) %>%
    mutate(diarrhea_fct = ordered(
      diarrhea_fct,
      levels = c(0, 1),
      labels = c("Absent", "Severe")
    ))
  attributes(df$diarrhea_fct)

  # response to external stimuli

  # 0 = responded; not frail , severe = does not respond; frail.

  df <- df %>%
    mutate(response_to_external_stimuli_fct = forcats::as_factor(response_to_external_stimuli)) %>%
    mutate(
      response_to_external_stimuli_fct = ordered(
        response_to_external_stimuli_fct,
        levels = c(0, 1),
        labels = c("Absent", "Severe")
      )
    )
  attributes(df$response_to_external_stimuli_fct)

  # format all 3 level ordinal vars. 2 binary formatted above.

  df <- df %>% mutate(across(c(all_of(index_names), -c("diarrhea", "response_to_external_stimuli")),
    ~ forcats::as_factor(.),
    .names = "{.col}_fct"
  ))

  index_names_fct <- sapply(index_names, paste0, "_fct") %>% unname()

  df <- df %>% mutate(across(
    c(all_of(index_names_fct), -c("diarrhea_fct", "response_to_external_stimuli_fct")),
    ~ ordered(., levels = c(0, 0.5, 1), labels = c("Absent", "Mild", "Severe"))
  ))

  # binarize items


  df <- df %>%
    mutate(across(all_of(index_names_fct),
      ~ as.character(.x) == "Severe",
      .names = "{.col}_binary"
    ) %>%
      mutate_if(is_logical, as_factor))

  # note now 3 copies per categorical item:
  # 1: no suffix. As numeric
  # 2: [x]_fct. As ordered factors
  # 3: [x]_fct_binary. As binary factors: y/n severe

  # Compute FI --------------------------------------------------------------

  df <- df %>%
    select(all_of(index_names)) %>%
    mutate(score_mean = rowMeans(., na.rm = TRUE)) %>%
    bind_cols(df[setdiff(names(df), names(.))], .)

  index_sum
  df <- df %>%
    select(all_of(index_sum)) %>%
    mutate(score_sum = rowSums(.[index_sum] == "TRUE", na.rm = TRUE)) %>%
    bind_cols(df[setdiff(names(df), names(.))], .)

  # Convenience subsets ---

  df_DO <- df %>% filter(strain == "J:DO")
  df_B6 <- df %>% filter(strain == "C57BL/6J")
  df_DO_t0 <- df_DO %>% filter(n == 1) # Baseline; DO
  df_B6_t0 <- df_B6 %>% filter(n == 1) # Baseline; B6

  # Methods -------------------------------------------------------------

  # Ns ----

  dplyr::n_distinct(df %>% filter(strain == "J:DO") %>% select(id)) # 246
  dplyr::n_distinct(df %>% filter(strain == "C57BL/6J") %>% select(id)) # 43
  table(df_B6_t0$sex) # m 28 f 15

  # N per diet group ---

  df %>%
    filter(strain == "J:DO") %>%
    group_by(id) %>%
    slice_sample(n = 1) %>%
    group_by(diet) %>%
    tally() %>%
    mutate(prop = (n / 192) * 100) # prop of original 192 per diet group
  # diet      n  prop
  # 1 AL       26  13.5
  # 2 IF1      34  17.7
  # 3 CR20     56  29.2
  # 4 IF2      51  26.6
  # 5 CR40     79  41.1

  # missing lifespan ----

  df <- df %>%
    mutate(exit_reason = ifelse(is.na(exit_reason), "MSG", exit_reason)) %>%
    mutate(exit_reason2 = case_when(
      str_detect(exit_reason, "FD") ~ "D",
      str_detect(exit_reason, "ES|RE") ~ "E",
      str_detect(exit_reason, c("DC|FTR|MSG")) ~ "C"
    ))
  df %>%
    filter(n == 1) %>%
    tabyl(exit_reason2) %>%
    adorn_percentages("col") %>%
    adorn_pct_formatting()
  # exit_reason2   n percent
  # C 0.1    6.6%
  # D 0.8   78.2%
  # E 0.2   15.2%
  df <- df %>% filter(exit_reason2 != "C")

  # rescale to months
  df <- df %>% mutate(
    lifespan = lifespan / 4.34,
    age_enroll = age_enroll / 4.34
  )

  return(df)
}
