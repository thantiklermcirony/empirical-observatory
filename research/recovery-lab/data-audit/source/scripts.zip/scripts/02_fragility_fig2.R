#################################################################################################################
#################################################################################################################
######
######                Title: 02_fragility_fig2.R
######
######                Project: Fragility
######
######                Description: Generates Figure 2
######
######                Author: AL
######
######                Date:  2023-08-15
######
#################################################################################################################
#################################################################################################################

# prep workspace ----------------------------------------------------------

if (!is.null(pacman::p_loaded())) {
  pacman::p_unload("all")
}
rm(list = ls())
graphics.off()
library(groundhog)
pkgs <- c(
  "tidyverse",
  "janitor",
  "here",
  "patchwork",
  "cowplot",
  "ggsci",
  "pacman"
)
groundhog.library(pkgs, "2023-03-27")
source(here::here("scripts", "fragility_vecs.R")) # helper vecs
source(here::here("scripts", "fragility_funs.R")) # helper funs

# df prep -----------------------------------------------------------------

df <- df_process() # data process

# Figure 2  -----------------------------------------------

# Figure 2 = subset of FI items by PPL ; eFigure 1 = remaining items

legend.title <- "My title"

temp <- df %>%
  select(strain, sex, diet, lifespan_p, score_mean, body_weight, temperature, all_of(index_names)) %>%
  pivot_longer(-c(strain, sex, diet, lifespan_p)) %>%
  group_by(name) %>%
  nest()

temp$legible <- append(c("Frailty Score by PLL", "Body Weight", "Temperature"), index_names_legible)
temp <- temp %>%
  mutate(plot = map2(
    data, legible,
    ~ .x %>%
      mutate(sex2 = ifelse(sex == "m", "Male", "Female")) %>%
      ggplot(., aes(
        linetype = paste0(strain, ", ", sex2),
        color = paste0(strain, ", ", sex2),
        x = lifespan_p,
        y = value
      )) +
      geom_smooth(
        method = "loess",
        na.rm = TRUE, se = T, size = 1, alpha = .2
      ) +
      guides(
        linetype = guide_legend(
          title = NULL,
          nrow = 3,
          override.aes = list(fill = NA),
          size = .2
        ),
        color = guide_legend(
          title = NULL,
          nrow = 3,
          override.aes = list(fill = NA)
        )
      ) +
      labs(title = .y, x = NULL, y = NULL) +
      coord_cartesian(xlim = c(.6, 1), ylim = c(0, 1)) +
      scale_color_npg() +
      theme(
        panel.grid.minor = element_blank(),
        legend.text = element_text(size = 12),
        panel.background = element_blank(),
        axis.ticks.x = element_blank(),
        plot.title = element_text(size = 12),
        legend.key = element_blank()
      )
  ))

temp$plot[[1]] <- temp$plot[[1]] + coord_cartesian(ylim = c(0, .4)) # FI
temp$plot[[2]] <- temp$plot[[2]] + coord_cartesian(ylim = c(20, 50)) # BW
temp$plot[[3]] <- temp$plot[[3]] + coord_cartesian(ylim = c(33, 37)) # Temp
plot_list <- temp$plot

###
# figure 2

temp <-
  temp %>% filter(
    name %in% c(
      "score_mean",
      "body_weight",
      "temperature",
      "body_condition",
      "breathing_rate_depth",
      "coat_condition",
      "dehydration_reduced_skin_turgor",
      "distended_abdomen",
      "head_piloerection",
      "pallor_and_or_cyanosis",
      "tail_stiffening",
      "tremor",
      "tumors"
    )
  )

plot_list <- temp$plot


# extract the legend from one of the plots, rmv from rest
legend <- cowplot::get_legend(plot_list[[1]] + theme(legend.position = "bottom"))
plot_list <- lapply(plot_list, function(x) x + theme(legend.position = "none"))

# add tags - manually b/c of design layout
plot_list[[1]] <- plot_list[[1]] + labs(tag = "A")
plot_list[[2]] <- plot_list[[2]] + labs(tag = "B")
plot_list[[3]] <- plot_list[[3]] + labs(tag = "C")
plot_list[[4]] <- plot_list[[4]] + labs(tag = "D")
plot_list[[5]] <- plot_list[[5]] + labs(tag = "E")
plot_list[[6]] <- plot_list[[6]] + labs(tag = "F")
plot_list[[7]] <- plot_list[[7]] + labs(tag = "G")
plot_list[[8]] <- plot_list[[8]] + labs(tag = "H")
plot_list[[9]] <- plot_list[[9]] + labs(tag = "I")
plot_list[[10]] <- plot_list[[10]] + labs(tag = "J")
plot_list[[11]] <- plot_list[[11]] + labs(tag = "K")
plot_list[[12]] <- plot_list[[12]] + labs(tag = "L")
plot_list[[13]] <- plot_list[[13]] + labs(tag = "M")


names(plot_list) <- temp$name

design <- "
  AABC
  AADE
  FGHI
  JKLM
"
a <- plot_list$score_mean +
  theme(
    plot.title = element_text(size = 12),
    axis.text = element_text(size = 12),
    axis.line = element_line(color = "black"),
    panel.grid.major = element_line(color = rgb(235, 235, 235, 100, maxColorValue = 255), size = 1),
  ) +
  annotate(
    "segment",
    x = .95,
    xend = .95,
    yend = 0.15, y = 0.1,
    colour = "black",
    size = 1,
    arrow = arrow(type = "closed", length = unit(0.13, "inches"))
  )
a
a2 <-
  (a + inset_element(
    legend,
    left = .1,
    bottom = 0.6,
    right = 0.4,
    top = 1,
    align_to = "panel"
  )) + theme(
    plot.background = element_rect(
      colour = "black",
      fill = "white",
      size = 1
    ),
    plot.margin = unit(c(1, 1, 1, 1), "cm")
  )
a2 + plot_list[2:13] + plot_layout(design = design)

ggsave(here::here("results", "Figure_2.pdf"),
  scale = 1,
  width = 270,
  height = 270,
  unit = "mm",
  dpi = 300
)

# clear workspace ---------------------------------------------------------

rm(list = ls())
pacman::p_unload("all")
graphics.off()
# .rs.restartR()
