
# prep vec objects for ordinal FI items


index_names <- c(
  'breathing_rate_depth',
  'coat_condition',
  'piloerection',
  'dermatitis',
  'pallor_and_or_cyanosis',
  'kyphosis',
  'hunched',
  'body_condition',
  'eye_discharge_eyelid_inflammation',
  'changes_to_the_globe',
  'response_to_analgesic',
  'peri_retro_orbital_swelling',
  'nasal_discharge',
  'rectal_prolapse',
  'vaginal_uterine_prolapse',
  'diarrhea',
  'tail_stiffening',
  'vestibular_disturbance',
  'gait_disorders',
  'tremor',
  'activity',
  'response_to_external_stimuli',
  'paralysis',
  'tumors',
  'distended_abdomen',
  'urine',
  'dehydration_reduced_skin_turgor',
  'malocclusions',
  'head_piloerection',
  'thoracic_mass'
)

index_names_legible <-  
  c(
    'Breathing Rate/Depth',
    'Coat Condition',
    'Piloerection',
    'Dermatitis',
    'Pallor/Cyanosis',
    'Kyphosis',
    'Hunched',
    'Body Condition',
    'Eye Discharge/Eyelid Inflammation ',  
    'Changes to Eye Globe',
    'Response to Analgesic', 
    'Peri-retro-orbital Swelling',  
    'Nasal Discharge' ,
    'Rectal Prolapse',
    'Vaginal/Uterine Prolapse',
    'Diarrhea',
    'Tail Stiffening',
    'Vestibular Disturbance',
    'Gait Disorders',
    'Tremor',
    'Activity',
    'Response to External Stimuli',  
    'Paralysis',
    'Tumors',
    'Distended Abdomen',
    'Urine',
    'Dehydration, Skin Turgor',
    'Malocclusions',
    'Head Piloerection',
    'Thoracic Mass'
  )

index_names_fct <-paste0(index_names, '_fct')
index_sum <- paste0(index_names, '_fct_binary')

colors5 <- c("seashell4", "skyblue", "orange", "royalblue4", "firebrick")
