#################################################################################################################
#################################################################################################################
######
######                Title: 12_fragility_eFigure2.R
######
######                Project: Fragility
######
######                Description: Generate SHAP values for 2 XGB models - pre-processors m0 and m3, visualize.
######
######                Author: AL
######
######                Date:  2023-08-16
######
#################################################################################################################
#################################################################################################################

# prep workspace ----------------------------------------------------------

if (!is.null(pacman::p_loaded())) {
  pacman::p_unload("all")
}
rm(list = ls())
graphics.off()
library(groundhog)
pkgs <- c(
  "pacman",
  "here",
  "ggsci",
  "janitor",
  "patchwork",
  "slider",
  "stacks",
  "themis",
  "tidymodels",
  "tidyverse",
  "gridExtra"
)
pkgs <- c(pkgs, "SHAPforxgboost")
groundhog.library(pkgs, "2023-03-27")
source(here::here("scripts", "fragility_vecs.R")) # helper vecs
source(here::here("scripts", "fragility_funs.R")) # helper funs
source(here::here("scripts", "fragility_funs_ml.R")) # ml funs

# Extract model weights ----------------------------------------------------

stack <- readRDS(here::here("results", "fitted_stack.rds"))
coefs <- stacks:::top_coefs(stack)
coefs
coefs <- coefs %>%
  mutate(
    Preprocessor = str_sub(member, 11, 12),
    weight = round(weight, 3)
  ) %>%
  select(-member) %>%
  rowid_to_column(var = "Rank") %>%
  relocate(Rank, Model = type, PP = Preprocessor, Weight = weight) %>%
  mutate(Model = case_when(
    Model == "boost_tree" ~ "XGB",
    Model == "rand_forest" ~ "RF",
    Model == "svm_rbf" ~ "SVM",
    TRUE ~ NA_character_
  ))
supp_fig_6a <- gridExtra::tableGrob(coefs, theme = ttheme_default(base_size = 10), rows = NULL)
supp_fig_6a


# df prep ------------------------------------------------------------------

df <- df_process()
df_ml <- df_process_ml()
df_do <- df_ml %>%
  filter(strain == "J:DO") %>%
  select(-strain)

# generate grouped initial data splits and grouped cv splits --------------

set.seed(20230501)
dat_split <- group_initial_split(data = df_do, group = id)
training_data <- training(dat_split)
testing_data <- testing(dat_split)
cv_split <- rsample::group_vfold_cv(training_data, group = "id", v = 5)

# Feature Engineering -----------------------------------------------------

m0_vars <- c("age_in_weeks", "diet", "sex")
m0_recipe <-
  recipe(training_data) %>%
  update_role(everything()) %>%
  update_role(id, new_role = "ID") %>%
  update_role(collection_date, new_role = "ID2") %>%
  update_role(lifespan_p_95, new_role = "outcome") %>%
  step_rm(all_predictors(), -all_of(m0_vars)) %>%
  step_unorder(all_nominal_predictors()) %>%
  step_dummy(all_nominal_predictors(), one_hot = TRUE) %>%
  step_zv(all_predictors()) %>%
  step_normalize(all_numeric_predictors()) %>%
  themis::step_upsample(lifespan_p_95, seed = 20230327)

m3_recipe <-
  recipe(training_data) %>%
  update_role(everything()) %>%
  update_role(id, new_role = "ID") %>%
  update_role(collection_date, new_role = "ID2") %>%
  update_role(lifespan_p_95, new_role = "outcome") %>%
  step_unorder(all_nominal_predictors()) %>%
  step_dummy(all_nominal_predictors(), one_hot = TRUE) %>%
  step_zv(all_predictors()) %>%
  # concurrent items
  step_pca(
    ends_with(paste0(!!index_names_fct, "_Absent")),
    ends_with(paste0(!!index_names_fct, "_Mild")),
    ends_with(paste0(!!index_names_fct, "_Severe")),
    options = list(center = TRUE, scale. = TRUE),
    prefix = "0d_"
  ) %>%
  # 30-day delta items
  step_pca(
    starts_with(paste0(!!index_names_fct, "_30d")),
    options = list(center = TRUE, scale. = TRUE),
    prefix = "30d_"
  ) %>%
  step_normalize(all_numeric_predictors()) %>%
  themis::step_upsample(lifespan_p_95, seed = 20221028)

# Compute SHAP vals -------------------------------------------------------

shap_xgb_m0 <-
  shap.prep(
    xgb_model = extract_fit_engine(stack$member_fits$m0_xs_xg_1_15), # model
    X_train = bake(prep(m0_recipe),
      has_role("predictor"),
      new_data = testing_data,
      composition = "matrix"
    ) # matrix of engineered training data
  )

shap_xgb_m3 <-
  shap.prep(
    xgb_model = extract_fit_engine(stack$member_fits$m3_xs_xg_1_01), # model
    X_train = bake(prep(m3_recipe),
      has_role("predictor"),
      new_data = testing_data,
      composition = "matrix"
    ) # matrix of engineered training data
  )

system.time({
  shap_int <- shap.prep.interaction(
    xgb_mod = extract_fit_engine(stack$member_fits$m3_xs_xg_1_01),
    X_train = bake(prep(m3_recipe),
      has_role("predictor"),
      new_data = testing_data,
      composition = "matrix"
    ) # matrix of engineered training data
  )
}) # runtime ~= 172


# plot --------------------------------------------------------------------

supp_fig_6b <- shap.plot.summary(
  shap_xgb_m0,my_format=""
) # summary plot
supp_fig_6c <- shap.plot.dependence(
  shap_xgb_m0,
  x = "age_in_weeks"
) # standardized age shows monotonic non-linear behavior
supp_fig_6d <- shap.plot.summary(
  shap_xgb_m3,my_format=""
) 
supp_fig_6e <- shap.plot.dependence(
  shap_xgb_m3,
  x = "score_mean",
  size0 = 1.2,
  smooth = TRUE,
  add_hist = FALSE
) 
supp_fig_6f <- shap.plot.dependence(
  data_long = shap_xgb_m3,
  data_int = shap_int,
  x = "age_in_weeks",
  y = "30d_1",
  add_hist = FALSE
) 

# combine plots -----------------------------------------------------------

# b & d = sina plot
# c & e = partial dependence plot
# f = interaction plot

p <- (wrap_elements(supp_fig_6a) | supp_fig_6b) / (supp_fig_6c | supp_fig_6d) / (supp_fig_6e | supp_fig_6f)
p + plot_annotation(tag_levels = "A")
ggsave(here::here("results", "eFigure_2.pdf"), height = 11, width = 10, units = "in")

# clear workspace ---------------------------------------------------------

rm(list = ls())
pacman::p_unload("all")
graphics.off()
# .rs.restartR()
