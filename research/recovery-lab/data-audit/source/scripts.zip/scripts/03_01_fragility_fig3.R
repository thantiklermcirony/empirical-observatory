#################################################################################################################
#################################################################################################################
######
######                Title: 03_01_fragility_fig3.R
######
######                Project: Fragility
######
######                Description: ML ensemble fit in training set; assessed in test set
######
######                Author: AL
######
######                Date:  2023-08-15
######
#################################################################################################################
#################################################################################################################

# prep workspace ----------------------------------------------------------

if (!is.null(pacman::p_loaded())) {
  pacman::p_unload("all")
}
rm(list = ls())
graphics.off()
library(groundhog)
pkgs <- c(
  "janitor",
  "here",
  "pacman",
  "doParallel",
  "finetune",
  "probably",
  "stacks",
  "themis",
  "tidymodels",
  "tidyverse",
  "lubridate",
  "slider"
)
groundhog.library(pkgs, "2023-03-27")
source(here::here("scripts", "fragility_vecs.R")) # helper vecs
source(here::here("scripts", "fragility_funs.R")) # helper funs
source(here::here("scripts", "fragility_funs_ml.R")) # ml funs

# df prep ------------------------------------------------------------------

df <- df_process() 
df_ml <- df_process_ml() 
df_do <- df_ml %>%
  filter(strain == "J:DO") %>%
  select(-strain)

# generate grouped initial data splits and grouped cv splits --------------

set.seed(20230501)
dat_split <- group_initial_split(data = df_do, group = id)
training_data <- training(dat_split)
testing_data <- testing(dat_split)
cv_split <- rsample::group_vfold_cv(training_data, group = "id", v = 5)


# ML ----------------------------------------------------------------------

# tune workflows
# fit ensemble
# estimate predicted probabilities

tuned_wfs <- ml_binary_fun() # tune wfs; run time ~ 15min

fragility_stack <- stack_fit_fun() # fit ensemble; run time ~ 5min

stack_probs <- stack_test_fun() # test ensemble in test; output = stack_probs_on_do.csv

# generate performance metrics across probability thresholds --------------

thresholds <- seq(.5, .9, by = .1)
stack_probs %>%
  mutate_if(is.character, as.factor) %>%
  select(lifespan_p_95, .pred_Event) %>%
  threshold_perf(., lifespan_p_95, .pred_Event, thresholds) %>%
  select(-.estimator) %>%
  pivot_wider(names_from = .metric, values_from = .estimate) %>%
  write_csv(here::here("results", "stack_thresholds.csv"))

# clear workspace ---------------------------------------------------------

rm(list = ls())
pacman::p_unload("all")
graphics.off()
# .rs.restartR()
