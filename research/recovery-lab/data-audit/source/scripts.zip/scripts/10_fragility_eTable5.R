#################################################################################################################
#################################################################################################################
######
######                Title: 10_fragility_eTable5.R
######
######                Project: Fragility
######
######                Description: Generate eTable5
######
######                Author: AL
######
######                Date:  2023-08-15
######
#################################################################################################################
#################################################################################################################

# prep workspace ----------------------------------------------------------

if (!is.null(pacman::p_loaded())) {
  pacman::p_unload("all")
}
rm(list = ls())
graphics.off()
library(groundhog)
pkgs <- c(
  "tidyverse",
  "broom",
  "here",
  "janitor",
  "pacman"
)
groundhog.library(pkgs, "2023-03-27")
source(here::here("scripts", "fragility_vecs.R")) # helper vecs
source(here::here("scripts", "fragility_funs.R")) # helper funs

# df prep -----------------------------------------------------------------

df <- df_process() 

# eTable 5 ------------------------------------------------------------

temp <- df %>%
  mutate(across(c(where(is.factor), -c(sex, diet)), as.numeric)) %>%
  select(c(
    strain,
    sex,
    diet,
    lifespan_residual,
    age_in_weeks,
    score_mean,
    score_sum,
    body_weight,
    temperature,
    all_of(index_names)
  )) %>%
  pivot_longer(cols = c(
    age_in_weeks,
    score_mean,
    score_sum,
    body_weight,
    temperature,
    all_of(index_names)
  )) %>%
  group_by(strain, sex, diet, name) %>%
  nest()
temp$legible <- rep(c(
  "Age in weeks",
  "FI Score",
  "N Deficits",
  "Body Weight",
  "Temperature",
  index_names_legible
), 7)
temp <- temp %>%
  mutate(
    # calculate
    tidy_cor.test = map(data, ~ tidy(cor.test(.x$value, .x$lifespan_residual))),
    # round
    tidy_cor.test = map(tidy_cor.test, ~ .x %>% mutate_if(is.numeric, ~round(.x, 2))),
    # extract
    r = map_dbl(tidy_cor.test, ~ .x$estimate),
    p = map_chr(tidy_cor.test, ~ ifelse(.x$p.value == 0, "<0.001", format.pval(.x$p.value,2))),
    CI = map_chr(tidy_cor.test, ~ paste0("(", .x$conf.low, ",", .x$conf.high, ")"))
  ) %>%
  ungroup() %>%
  # clean up
  select(-data, -tidy_cor.test, -name) %>%
  mutate(CI = ifelse(CI == "(NA,NA)", "---", CI))

etable_5 <- temp %>%
  filter(!strain == "J:DO") %>%
  select(-strain, -diet, -CI) %>%
  pivot_wider(names_from = sex, values_from = c(r, p), names_sep = " ") %>%
  arrange(desc(abs(`r f`))) %>%
  relocate(legible, contains("f"), contains("m")) 


# export ------------------------------------------------------------------

etable_5 <- write_csv(etable_5, here::here("results", "Supplement_eTable5.csv"), na = "---")

# clear workspace ---------------------------------------------------------

rm(list = ls())
pacman::p_unload("all")
graphics.off()
# .rs.restartR()
