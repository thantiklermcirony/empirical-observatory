"""Observer-conditioned GPx budget from the existing 30-minute prepared state.

This is exact arithmetic on declared interval endpoints. It is neither a new
fitting fixture nor an estimator of biological confidence or survival.
"""
import csv,json,hashlib
from fractions import Fraction as F
from pathlib import Path
from dataclasses import replace
import numpy as np
from model import load_parameters,simulate,diagnostics
from run import numerical_restart,save_trace,dump,csvwrite

ROOT=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def bound(q,total,n,reg,T,gsource):
    if any(x is None for x in [q,total,n,reg,gsource]):return None
    for pair in [q,total,n,reg,gsource]:
        if len(pair)!=2 or not 0<=F(str(pair[0]))<=F(str(pair[1])):raise ValueError('Invalid nonnegative interval')
    if F(str(q[1]))>1:raise ValueError('Fraction exceeds one')
    return F(str(q[1]))*F(str(total[1]))/2+F(str(n[1]))+F(str(reg[1]))*T+F(str(gsource[1]))*T/2

def main():
    p=load_parameters(ROOT/'parameters.json')
    with (ROOT/'results/recovery_finite.csv').open() as f:
        row=next(x for x in csv.DictReader(f) if float(x['time_min'])==30)
    y=np.array([float(row[k]) for k in ['bath_h2o2','cell_h2o2','gsh','gssg','nadph','nadp']])
    state=numerical_restart(p,y);q=float(state[2]/p.g_total);n=float(state[4]);T=20
    observers={
      'fraction_only':{'q':[q,q],'G_total':None,'N':None,'Vreg':None,'Jg':[0,0]},
      'fraction_plus_absolute_pool':{'q':[q,q],'G_total':[p.g_total,p.g_total],'N':[0,p.n_total],'Vreg':[p.v_reg,p.v_reg],'Jg':[0,0]},
      'fraction_pool_and_cofactor':{'q':[q,q],'G_total':[p.g_total,p.g_total],'N':[n,n],'Vreg':[p.v_reg,p.v_reg],'Jg':[0,0]},
      'illustrative_assay_intervals':{'q':[max(0,q-.005),min(1,q+.005)],'G_total':[.98*p.g_total,1.02*p.g_total],
        'N':[max(0,n-.003),n+.003],'Vreg':[.0025,.0035],'Jg':[0,0]},
      'cofactor_with_added_gsh_source':{'q':[q,q],'G_total':[p.g_total,p.g_total],'N':[n,n],'Vreg':[p.v_reg,p.v_reg],'Jg':[.03,.03]},
      'cofactor_without_regeneration_ceiling':{'q':[q,q],'G_total':[p.g_total,p.g_total],'N':[n,n],'Vreg':None,'Jg':[0,0]}}
    rows=[]
    for name,o in observers.items():
        b=bound(o['q'],o['G_total'],o['N'],o['Vreg'],T,o['Jg'])
        for target in [.55,.6,.64,.8]:
            rows.append({'observer':name,'target_gpx_clearance_mM':target,'horizon_min':T,
                'upper_bound_mM':float(b) if b is not None else None,'upper_bound_exact':str(b) if b is not None else None,
                'budget_conclusion':'unresolved' if b is None else ('excluded' if F(str(target))>b else 'not_excluded'),
                'result_kind':'formal_under_premises','status':'unresolved' if b is None else 'established_in_scope'})
    exact_o=observers['fraction_pool_and_cofactor'];exact=bound(exact_o['q'],exact_o['G_total'],exact_o['N'],exact_o['Vreg'],T,exact_o['Jg'])
    future=((0,.15),(5,0));times=np.linspace(0,T,201)
    base=simulate(p,future,times,initial=state);alt=simulate(replace(p,other_clearance=3),future,times,initial=state)
    opened=simulate(replace(p,gsh_source=.03),future,times,initial=state)
    for name,r in [('continuation_finite',base),('continuation_other_clearance',alt),('continuation_open_source',opened)]:save_trace(ROOT/'results'/(name+'.csv'),r)
    assert base['y'][-1,6]<=float(exact)+1e-7
    openbound=bound(*[observers['cofactor_with_added_gsh_source'][k] for k in ['q','G_total','N','Vreg']],T,[.03,.03])
    assert opened['y'][-1,6]<=float(openbound)+1e-7
    assert alt['y'][-1,6]<=float(exact)+1e-7
    total_other=float(alt['y'][-1,6]+alt['y'][-1,12])
    assert total_other>float(exact)
    # Meaningful necessary-premise removal: start with the successful cofactor certificate,
    # remove only its supply ceiling; retain algebraic moiety identity separately.
    assert bound(exact_o['q'],exact_o['G_total'],exact_o['N'],None,T,[0,0]) is None
    targetrows=[x for x in rows if x['target_gpx_clearance_mM']==.6]
    assert next(x for x in targetrows if x['observer']=='fraction_plus_absolute_pool')['budget_conclusion']=='not_excluded'
    assert next(x for x in targetrows if x['observer']=='fraction_pool_and_cofactor')['budget_conclusion']=='excluded'
    csvwrite(ROOT/'results/continuation_table.csv',list(rows[0]),rows)
    result={'prepared_at_absolute_time_min':30,'prepared_state_species_mM':state.tolist(),
      'history_protocol':{'incoming_schedule':[[0,0],[5,.03],[10,0]],'source_trajectory':'results/recovery_finite.csv','sha256':sha(ROOT/'results/recovery_finite.csv')},
      'future_protocol':{'schedule':future,'horizon_min':T,'meaning':'0.15mM incoming pulse5min then washout; budget targets refer only to integrated GPx extent, not total delivered dose or survival'},
      'observer_intervals':observers,'units':{'q':'1','G_total':'mM GSH equivalents','N':'mM NADPH','Vreg':'mM/min','Jg':'mM GSH/min','bound':'mM H2O2 consumed by GPx'},
      'interval_evidence':'Point values from a simulated state, physical pool/rate caps stipulated; assay interval widths illustrative, not measured confidence bounds.',
      'table':rows,'checks':{'all_passed':True,'count':7,
         'finite_GPx_under_bound':float(base['y'][-1,6]),'finite_bound_mM':float(exact),
         'open_source_GPx_under_bound':float(opened['y'][-1,6]),'open_source_bound_mM':float(openbound),
         'other_clearance_GPx_under_bound':float(alt['y'][-1,6]),'total_removal_with_other_pathway_mM':total_other,
         'specificity_counterexample':'Total removal exceeds the GPx budget; budget must not be renamed total antioxidant capacity.',
         'removed_regeneration_ceiling':'Previously established budget becomes unresolved; G+2O balance remains established under closed pool.'},
      'dependencies':{'common':['BIO-STOICH','BIO-NONNEG','BIO-ENV','BIO-KINETICS'],'certificate':['absolute_pool_upper_bound','cofactor_upper_bound','regeneration_rate_upper_bound','gsh_source_upper_bound'],
                      'still_available_without_rate_bound':'Algebraic moiety conservation, given stoichiometry/closed source'},
      'input_hashes':{f:sha(ROOT/f) for f in ['model.py','run.py','parameters.json','continuation.py','results/execution.json','results/recovery_finite.csv']},
      'conclusion_scope':'Necessary exclusion under supplied bounds. Not excluded never means feasible, restored, safe or empirically supported.'}
    dump(ROOT/'results/continuation.json',result)
    print(json.dumps({'cofactor_changes_0_6mM_target':targetrows,'total_other_clearance_mM':total_other}))

if __name__=='__main__':main()
