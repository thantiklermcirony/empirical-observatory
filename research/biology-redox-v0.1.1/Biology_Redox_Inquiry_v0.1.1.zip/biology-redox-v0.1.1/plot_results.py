"""Render saved numerical outputs. No in-browser simulator or invented trajectories."""
from pathlib import Path
import csv,json,os,tempfile
os.environ.setdefault('MPLCONFIGDIR',str(Path(tempfile.gettempdir())/'observatory-biology-matplotlib'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent;R=ROOT/'results'

def read(name):
    with (R/name).open(newline='',encoding='utf8') as f:return list(csv.DictReader(f))
def col(d,k):return np.array([float(x[k]) for x in d])

def main():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':12,
      'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.alpha':.18})
    blue='#136F94';orange='#C06A16';red='#BB3E46';grey='#656D78'
    fig,axs=plt.subplots(2,3,figsize=(15,9),layout='constrained')
    fig.suptitle('A recovered glutathione fraction can conceal lost reserve\nSynthetic redox reference — no biological calibration',fontsize=18,fontweight='bold')
    summary=json.loads((R/'summary.json').read_text())
    d=read('recovery_finite.csv');t=col(d,'time_min')
    ax=axs[0,0];ax.step(t,col(d,'incoming_h2o2_mM')*1000,where='post',color=grey,label='Incoming forcing')
    ax.plot(t,col(d,'bath_h2o2')*1000,color=blue,label='Simulated bath')
    ax.set(xlim=(0,20),xlabel='Time (min)',ylabel='H2O2 (µM)',title='A  Environment and transport');ax.legend(fontsize=9)
    ax=axs[0,1];ax.plot(t,col(d,'gsh')/(col(d,'gsh')+2*col(d,'gssg')),color=blue,label='GSH / total G equivalents')
    ax.plot(t,col(d,'nadph')/(col(d,'nadph')+col(d,'nadp')),'--',color=orange,label='NADPH / total NADP')
    ax.axvline(30,ls=':',color=grey);ax.set(xlim=(0,90),ylim=(-.04,1.08),xlabel='Time (min)',ylabel='Fraction (dimensionless)',title='B  Pool restoration has two clocks');ax.legend(loc='lower right',fontsize=8)
    ax=axs[0,2]
    for file,label,color in [('fresh_challenge.csv','Fresh preparation',grey),('rechallenge_at_30min.csv','Rechallenge at minute 30',red)]:
        x=read(file);ax.plot(col(x,'time_min'),col(x,'cell_h2o2')*1000,label=label,color=color)
    excess=100*(summary['readout_at_30min']['auc_ratio_to_fresh']-1)
    ax.set(xlabel='Time from second challenge (min)',ylabel='Hidden cell H2O2 (µM)',title=f'C  Same challenge, {excess:.0f}% greater AUC');ax.legend(fontsize=8)
    ax=axs[1,0];x=read('wait_ladder.csv');ax.plot(col(x,'wait_after_washout_min'),col(x,'auc_ratio_to_fresh'),'o-',color=red,label='Second / fresh H2O2 AUC')
    ax.axhline(1.1,ls='--',color=grey,label='Declared 10% margin')
    ax.axvline(summary['first_tested_wait_signal_recovered_min'],ls=':',color=blue,label='First tested signal recovery')
    ax.set(xlim=(0,90),xlabel='Wait after washout (min)',ylabel='AUC ratio',title='D  Re-exposure depends on waiting');ax.legend(fontsize=8)
    ax=axs[1,1]
    obs=[x for x in read('synthetic_measurements.csv') if x['truth_mechanism']=='finite' and x['split']=='validation' and x['schedule']=='repeated']
    ax.scatter(col(obs,'time_min'),col(obs,'gsh_mM'),s=13,color=grey,alpha=.7,label='Synthetic observations')
    for mode,color in [('finite',blue),('clamped',orange)]:
        pp=[x for x in read('heldout_predictions.csv') if x['truth_mechanism']=='finite' and x['fitted_mechanism']==mode and x['schedule']=='repeated']
        ax.plot(col(pp,'time_min'),col(pp,'gsh_mM'),color=color,label=mode+' prediction')
    ax.set(xlabel='Time (min)',ylabel='GSH concentration (mM)',title='E  Entire schedule held out');ax.legend(fontsize=8)
    ax=axs[1,2];x=read('parameter_grid.csv')
    groups=[('Both margins',True,True,blue,'o'),('Signal only',True,False,red,'s'),
            ('Repeat only',False,True,orange,'^'),('Neither',False,False,grey,'x')]
    for label,signal,repeat,color,marker in groups:
        subset=[r for r in x if (r['meets_signal_margin']=='True')==signal and (r['meets_repeat_margin']=='True')==repeat]
        ax.scatter(col(subset,'gsh_fraction_at_30min'),col(subset,'second_challenge_auc_ratio'),color=color,marker=marker,s=42,label=f'{label}: {len(subset)}')
    ax.axvline(.995,ls=':',color=blue);ax.axhline(1.1,ls='--',color=grey)
    ax.set(xlabel='GSH fraction at minute 30',ylabel='Second / fresh H2O2 AUC',title='F  27 assumed parameter scenarios')
    ax.legend(fontsize=8,loc='upper left',title='Unweighted scenarios',title_fontsize=8)
    fig.savefig(ROOT/'reference.png',dpi=150)
    fig.savefig(ROOT/'reference.svg')
    plt.close(fig)
    print('Rendered reference.png and reference.svg from saved CSV files')

if __name__=='__main__':main()
