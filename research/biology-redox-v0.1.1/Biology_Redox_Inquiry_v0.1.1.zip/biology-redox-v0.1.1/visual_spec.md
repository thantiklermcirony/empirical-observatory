# Integration specification tied to numerical outputs

The coordinator owns Site changes. This package provides static scientific figures, CSVs and common inquiry records; no browser-side ODE reimplementation is required.

**Question:** “Has this redox subsystem recovered enough for the same challenge?” Show the evidence badge **Synthetic reference; biological validation unresolved** beside the question and retain it in exports.

| View | Source | Display and allowed interpretation |
|---|---|---|
| Environmental input | recovery_finite.csv: time, incoming_h2o2_mM, bath_h2o2 | incoming concentration as steps; predicted bath as a line; actual measurements would require distinct markers |
| Physical reserve | gsh,gssg,nadph,nadp columns | molecular mM and optional G+2O, N+Q; absolute quantities stay visible when fractions are selected |
| Recovered signal | derived G/(G+2O) | label derived fraction, never “cell health”; show the authored 0.995 margin |
| Repeat capacity | fresh_challenge.csv, rechallenge_at_30min.csv, wait_ladder.csv | hidden predicted intracellular H2O2 trajectories and 20-minute AUC in mM·min; show 10% comparison margin as a user-declared target |
| Model contrast | benchmark.json; heldout_predictions.csv; synthetic_measurements.csv | state which mechanism generated the synthetic observations; points are synthetic observations, lines predictions; show train and held-out results together |
| Uncertainty | parameter_grid.csv; measurement_design.json | 27 assumed scenarios, **not** confidence intervals; allow highlighting a parameter combination, not a probability/prevalence interpretation |
| Observer-conditioned continuation | continuation_table.csv and continuation.json | fraction only / absolute pool / additional NADPH / removed rate bound; label each target excluded, not excluded or unresolved; no “safe” label |
| Changed premise | common inquiry cases plus open_gsh_source.csv, sustained_clamped.csv, no_regeneration.csv | recompute with an external runner; show which budget premise ceased to apply, added source amount and changed bound |
| Data readiness | data/retina_audit.json | actual inspected fields, experimental-unit gaps and missing pulse/wait data; no overlay of developmental retina values on synthetic cell curves |
| Next measurement | experiment.md | NADPH assay at a pilot-scaled gap with absolute GSH/GSSG and delivered-input calibration |

Default panels are produced by `plot_results.py` as `reference.png` and `reference.svg`. They show the input, physical restoration, functional prediction, wait ladder, unseen schedule and parameter scenarios. Every visible trajectory comes from saved outputs. `results/summary.json` supplies the numerical annotation, not hard-coded Site marketing copy.

Suggested controls: conditioning dose/duration, washout gap, second challenge, total G pool, NADP pool, regeneration ceiling, observer channels, and explicit additional GSH/clearance source switches. The source and any cross-scale calibration each have a premise ID. A missing calibration disables empirical/fate claims while leaving the dimensionally valid synthetic result available. A missing rate ceiling disables its exclusion bound. A source/code/data hash mismatch marks the corresponding numerical receipt stale until rerun. Do not display a manually relabelled record as a recomputed consequence.

Interactions use `run.py --scenario` with the strict `examples/single_pulse.json` schema and complete physical `parameters.json`. Every advertised protocol field executes, unknown fields are rejected, and changed-input tests verify both result and provenance changes. The default benchmark is a separately named fixed campaign, not a configurable UI in disguise. Show entered units, accepted domain, execution method and scope in an inspectable details pane. Do not put Python paths or implementation controls into the ordinary user journey. The initial figure is a static integration reference, not proof of completed Site interaction or deployment.

The parameter-map legend shows **all four** outcomes under q>=0.995 and repeat/fresh AUC<=1.10: 11 both margins, 7 signal only, 3 repeat only and 6 neither. Counts are unweighted scenarios. A fraction threshold can be too permissive or too conservative for the chosen challenge target.
