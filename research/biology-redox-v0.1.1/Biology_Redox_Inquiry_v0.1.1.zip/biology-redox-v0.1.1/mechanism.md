# Mechanism, units and warranted consequences

Let E and H be bath and cell H2O2, G and O be molecular GSH and GSSG, and N and Q be NADPH and NADP. All are in mM; time is minutes. Volumes are fixed. `rho=Vcell/Vbath` is dimensionless. A flow reactor has prescribed incoming concentration U(t), bath exchange rate kf, and membrane concentration-transfer rate kp.

```
Jp = H G / (phi_h G + phi_g H)       GPx peroxide-consumption extent
Jr = Vgr O N / ((Ko+O)(Kn+N))        GR GSSG-reduction extent
Js = Vreg Q / (Kq+Q)                NADPH regeneration
Jm = kp (E-H)                      membrane transfer per cell volume
Jf = kf (U-E)                      bath exchange per bath volume

E' = Jf - kb E - rho Jm
H' = Jm - Jp - kc H
G' = -2 Jp + 2 Jr + Jg
O' = Jp - Jr
N' = Js - Jr
Q' = Jr - Js
```

At H=G=0 define Jp=0, its continuous extension on the nonnegative quadrant. `phi_h,phi_g` are minutes; `Vgr,Vreg,Jg` are mM/min; `Ko,Kn,Kq` are mM; `kp,kf,kb,kc` are min^-1. All rates and concentrations are nonnegative except the signed transport/exchange fluxes. The GPx form is a quasi-steady effective rate law, not a mass-action elementary reaction or a thermodynamic free-energy calculation. Proton/water buffering, enzyme abundance and the external reducing substrate are chemostatted assumptions. `Js` represents transfer of reducing equivalents from that external substrate; its integral is recorded, so conservation of cofactor molecules is not mistaken for conservation of redox energy.

The default case has Jg=kb=kc=0. In the conventional **clamped** alternative, `Js=Jr`, so N is held at its prepared value by a compensating source. This source is explicitly counted, and need not satisfy the finite model's `Vreg` ceiling. The ordinary four-state kinetic comparator in `validate.py` has the *same physics* as the finite model, eliminating O and Q through total pools; it agrees numerically. The clamped alternative changes physics, while the four-state comparator changes representation. These tests answer different questions.

## Formal consequences under stated premises

1. **Glutathione moieties:** `(G+2O)'=Jg`; with Jg=0, total G is conserved. **Cofactor molecules:** `(N+Q)'=0`. These are exact stoichiometric identities, not fitted patterns.
2. **Reducing-equivalent budget:** with `B=G/2+N`, `B'=Js-Jp+Jg/2`. Hence `integral Jp <= B(0)+integral Js+integral Jg/2` for nonnegative B. The reference's `Js<=Vreg` implies `integral_0^T Jp <= B0+Vreg*T` in a closed G pool. Clearing 0.8 mM by GPx within 20 min is impossible when B0=0.58 and Vreg=0.003, whose ceiling is 0.64 mM. This is a necessary bound, not sufficient feasibility or a cell-death threshold.
3. **Environmental balance:** `(E+rho H)'=Jf-kb E-rho(Jp+kc H)`. The membrane flux cancels only with the correct volume factor. Constant bath concentration cannot be assumed when cells substantially deplete the bath.
4. **Positivity and bounded pools:** at zero E, H, G, O, N or Q the corresponding derivative is nonnegative under these kinetics and nonnegative U. Combined with the closed totals, `0<=G<=Gtot`, `0<=N<=Ntot`. The function Jp has a bounded directional slope on the nonnegative quadrant. The paper-style inwardness reasoning establishes the declared ODE's invariant domain; finite sampled boundary tests are supporting implementation checks, not an automated general proof.
5. **Boundedness does not imply hormesis:** G/Gtot cannot exceed its starting value 1 in the reference closed pool. The model contains no induced beneficial synthesis. A bounded observation or logit transform adds no biochemical benefit law. Redox recovery is not a lifespan inference.

## Observer and time

The directly modelled assay channels are calibrated bath H2O2, GSH, GSSG and NADPH concentrations. The displayed fraction `q=G/(G+2O)` is *derived from molecular concentration assays*, not a claim that fluorescent probe ratio is q. An oxidation-sensitive probe instead needs its own calibration, pH dependence, response kinetics, dynamic range and perturbation model. Likewise, `[GSH]/[GSSG]`, q and the glutathione redox potential are different functions; none is silently substituted for another.

The synthetic fit uses bath H2O2 and GSH with independent Gaussian SD 0.001 and 0.01 mM, conditional identical preparations. Negative noisy observations are allowed by that stipulated likelihood and are not clipped. Real assay censoring, shared calibration error, batch variation and repeated-measure correlations must be fitted/validated separately. Synthetic series are not independent biological replicates.

U is piecewise constant and right-continuous. At every scheduled change the solver is restarted with continuous chemical state; no input jump is integrated across blindly. Exported state times are exact requested times. Default solve_ivp LSODA tolerances are rtol 2e-8 and atol 1e-10 mM; Radau/BDF and a tighter Radau run check convergence. Trajectory negatives at roughly 1e-10 mM are reported numerical error. A challenge restart removes only roundoff, verifies corrections below 1e-8 mM, and reconstructs the declared pools. The physical RHS is never clipped.

## What the reference establishes and leaves open

After the illustrative 0.03 mM incoming pulse at minutes 5–10, q at minute 30 is 0.999777, whereas N/Ntot is 0.126923. A new 0.15 mM, five-minute incoming pulse produces 1.32952 times the fresh-cell 20-minute H2O2 AUC. Thus the declared readout margin can return before the declared challenge-capacity margin. The margins 0.995 and 10% AUC are authored demonstration choices, not physiological limits. Earlier history is not evidence of biological memory unless experiments establish its conditional effect at the matched measured present.

The integrated H2O2 exposure is a chemical functional readout. It has no validated map to protein damage, survival, clonogenic recovery, wellbeing or harm. GR kinetics, NADPH supply, compartment volumes, alternative clearance and molecular pool sizes remain uncalibrated for a named cell. The 27-case nuisance grid is a range of assumed parameter scenarios, not a confidence distribution. Some cases have already recovered both endpoints at 30 min; the disconnect is conditional, not universal.
