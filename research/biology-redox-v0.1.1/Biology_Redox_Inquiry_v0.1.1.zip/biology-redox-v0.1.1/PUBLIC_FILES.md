# Portable distribution content

This is a distinct public-preparation derivative of the accepted scientific v0.1.1 release. `manifest.json` gives the exact included-file allowlist. Publication and new-work licensing status are recorded in `PUBLICATION_HANDOFF.md` and `NOTICES.md`.

The package contains authored scientific code and text, pinned dependency declarations, stipulated inputs, synthetic results and figures, a public-safe provenance snapshot, and the attributed Table S2 extraction. Two unchanged supplements are included under their separately declared CC BY 4.0 and CC BY 2.0 terms; their exact notices remain in `NOTICES.md`. No Aon XML or author figures, private programme manuscripts, other agents' source, installed runtimes, board/session records or credentials are included.

`sources.json` keeps source IDs, inspected hashes, available URLs, licensing and evidential scope, while omitting machine locations and local coordination state. Private consulted sources are explicitly unavailable rather than presented as accessible evidence. They are not required for execution. The sole source-code transformation replaces the private task identity constant in `assemble.py` with null; mathematical and numerical operations are unchanged. Dependent envelopes, exporter hashes and the release manifest are deliberately regenerated, not represented as the original frozen archive.

The synthetic evidence does not establish empirical recovery, clinical safety, mechanism identification or a new biological law. Integrity checks establish file identity and declared linkage only.
