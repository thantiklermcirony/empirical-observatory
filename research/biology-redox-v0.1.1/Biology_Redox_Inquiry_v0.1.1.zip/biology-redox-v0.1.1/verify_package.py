"""Integrity verification of one inquiry bundle; never certifies biological truth."""
import json,hashlib,argparse
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def check_records(records,reader):
    errors=[]
    for path,wanted in records.items():
        try:actual=hashlib.sha256(reader(path)).hexdigest()
        except (OSError,ValueError) as e:errors.append({'path':path,'error':str(e)});continue
        if actual!=wanted:errors.append({'path':path,'error':'SHA256 mismatch: dependent results are stale'})
    return errors

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--self-test',action='store_true');a=parser.parse_args()
    records=json.loads((ROOT/'manifest.json').read_text())['files']
    def read(path):
        p=(ROOT/path).resolve()
        if not p.is_relative_to(ROOT):raise ValueError('Manifest path escapes bundle')
        return p.read_bytes()
    errors=check_records(records,read)
    if errors:raise SystemExit(json.dumps({'valid':False,'errors':errors},indent=2))
    if a.self_test:
        for target in ['model.py','parameters.json','data/retina_table_s2_unpaired.csv','data/retina2023_supplement.pdf','results/summary.json']:
            e=check_records({target:records[target]},lambda path:read(path)+b' altered')
            assert len(e)==1 and 'stale' in e[0]['error']
        print('Five in-memory source/model/data/result mutations rejected; no files changed')
    print(json.dumps({'valid':True,'verified_files':len(records),'meaning':'Integrity only; empirical and mechanism evidence statuses unchanged'}))

if __name__=='__main__':main()
