"""Question-specific common-envelope exporter, not a universal reasoning engine.

Changed source/rate assumptions recompute numerical cases. The local source
manifest is provenance; it is not proof that a biological likelihood is valid.
"""
import json,hashlib,datetime
from pathlib import Path
from dataclasses import replace,asdict
from fractions import Fraction
import numpy as np
from model import Parameters,simulate,diagnostics,load_parameters
from run import dump,save_trace

ROOT=Path(__file__).resolve().parent
TASK=None  # Private task identity omitted from the portable distribution.
FIELDS=('identity','question','system','observer','quantities','operations','constraints',
        'mechanism','premises','execution','results','contrast','next_question','provenance')

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def budget_result(case,p,T=20,target=Fraction(4,5)):
    if case=='clamped':
        return {'id':'GPX-BUDGET','result_kind':'formal_under_premises','status':'unresolved',
         'value':None,'units':'mM peroxide consumed through GPx',
         'reason':'No finite regeneration-rate ceiling is licensed for the compensating clamp source.',
         'depends_on':['BIO-STOICH','BIO-NONNEG','BIO-ACCOUNTING','BIO-REGEN-CEILING'],
         'blocked_by':['BIO-REGEN-CEILING']}
    B=Fraction(str(p.g_total))/2+Fraction(str(p.n_total))
    bound=B+Fraction(str(p.v_reg))*T+Fraction(str(p.gsh_source))*T/2
    excluded=target>bound
    return {'id':'GPX-BUDGET','result_kind':'formal_under_premises','status':'established_in_scope',
       'value':{'upper_bound_exact':str(bound),'upper_bound_mM':float(bound),
         'required_clearance_exact':str(target),'required_clearance_mM':float(target),
         'horizon_min':T,'target_excluded':excluded},
       'units':'mM peroxide consumed through GPx',
       'reason':'Integrated stoichiometry plus nonnegative final reducing reserve; non-exclusion does not prove feasibility.',
       'depends_on':['BIO-STOICH','BIO-NONNEG','BIO-ACCOUNTING','BIO-N-POOL','BIO-REGEN-CEILING',
                     'BIO-G-SOURCE' if p.gsh_source else 'BIO-G-CLOSED'],
       'uncertainty':'Exact arithmetic under stipulated constants; biological constants uncalibrated.'}

def build(case,p):
    if case=='open_gsh_source':p=replace(p,gsh_source=.03)
    mode='clamped' if case=='clamped' else 'finite'
    T=20;times=np.linspace(0,T,201);sched=((0,.2),)
    trajectory=simulate(p,sched,times,mode=mode)
    csv=ROOT/'results'/('case_'+case+'.csv');save_trace(csv,trajectory)
    result=budget_result(case,p)
    result['protocol_id']='budget-protocol'
    result['origin']={'method':'assemble.py exact rational budget','model_sha256':sha(ROOT/'model.py'),
                      'exporter_sha256':sha(ROOT/'assemble.py'),'parameter_sha256':sha(ROOT/'parameters.json'),
                      'effective_parameters':asdict(p),'horizon_min':20,'target_gpx_clearance_mM':.8}
    campaign=json.loads((ROOT/'results'/'execution.json').read_text())
    protocols={'budget-protocol':{'schedule':sched,'horizon_min':T,'sample_interval_min':.1,
                                'mode':mode,'initial_species':[0,0,p.g_total,0,p.n_total,0]}}
    if case=='finite':
        protocols.update({'conditioning-protocol':campaign['protocols']['conditioning'],
            'repeat-challenge-protocol':dict(campaign['protocols']['challenge'],
                preparation='Endpoint at minute30 of conditioning-protocol',
                comparison='fresh-probe-protocol'),
            'fresh-probe-protocol':dict(campaign['protocols']['challenge'],preparation=[0,0,p.g_total,0,p.n_total,0])})
    premises=[
      ('BIO-ACCOUNTING','Common fixed normalization volume and time, and complete reducing-equivalent source/sink accounting apply to all concentration balances','assumed','BIO-INT-02: mathematics and integration independent review; added fluxes or volume changes require a rederived amount ledger'),
      ('BIO-STOICH','GPx consumes two GSH and one H2O2 per GSSG; GR consumes one NADPH per GSSG','assumed','Reed2008 supplementary p9; implemented explicit molecular convention'),
      ('BIO-NONNEG','Species nonnegative; flux laws vanish for missing required substrate','derived','mechanism.md boundary argument; validation.json numerical implementation checks'),
      ('BIO-N-POOL','NADPH+NADP is conserved within the cofactor compartment','assumed','Declared reaction subsystem; not evidence for every cell'),
      ('BIO-G-CLOSED','No GSH synthesis/export or growth dilution over the horizon','rejected' if p.gsh_source else 'assumed','Declared reference boundary'),
      ('BIO-G-SOURCE',f'External GSH source is separately metered at {p.gsh_source}mM/min','assumed' if p.gsh_source else 'missing','Changed-premise case only'),
      ('BIO-REGEN-CEILING',f'NADPH regeneration cannot exceed Vreg={p.v_reg}mM/min','rejected' if mode=='clamped' else 'assumed','Declared synthetic rate-limited source'),
      ('BIO-CLAMP','An external compensating source supplies exactly the GR cofactor demand','assumed' if mode=='clamped' else 'missing','Clamped alternative; its source integral is retained'),
      ('BIO-ENV','Fixed compartment volumes, measured-at-model-boundary forcing, linear transport','assumed','Specified bath/cell balance; biological transport uncalibrated'),
      ('BIO-KINETICS','Effective GPx/GR law and synthetic kinetic constants apply','assumed','2012 law forms plus declared extension; not complete published model'),
      ('BIO-ASSAY','Direct concentration observation with stipulated independent Gaussian error in synthetic fits','assumed','run.py measurement model; actual assay likelihood not validated'),
      ('BIO-CALIBRATION','Named cell, delivered input, volume and paired concentration likelihood are calibrated','missing','Actual retinal/mitochondrial data do not satisfy this gate'),
      ('BIO-FATE','Chemical peroxide AUC predicts durable cell fate under a specified rescue','missing','No such calibration/measurement in this package'),
      ('BIO-QUANTUM-PORT','Quantum yield is calibrated to a physical source rate and biological species','missing','coupling.md agreement with quantum lead')]
    q=[]
    for id,meaning,unit,domain in [('E','bath peroxide','mM','>=0'),('H','cell peroxide','mM','>=0'),
        ('G','molecular GSH','mM','>=0'),('O','molecular GSSG','mM','>=0'),('N','NADPH','mM','>=0'),('Q','NADP','mM','>=0'),
        ('B','reducing-equivalent reserve G/2+N','mM peroxide equivalents','>=0'),('q','G/(G+2O), derived readout','1','[0,1]'),
        ('Jp','GPx reaction extent rate','mM/min','>=0'),('Jm','membrane flux per cell volume','mM/min','real'),
        ('rho','Vcell/Vbath','1','>0'),('U','incoming bath concentration','mM','>=0'),('t','elapsed time','min','>=0')]:
        q.append({'id':id,'meaning':meaning,'units':unit,'domain':domain,'representation':'real'})
    results=[result,
      {'id':'BIO-TRAJECTORY','result_kind':'model_prediction','status':'established_in_scope',
       'protocol_id':'budget-protocol',
       'artifact':str(csv.relative_to(ROOT)).replace('\\','/'),'sha256':sha(csv),
       'origin':{'runner':'assemble.py','runner_sha256':sha(ROOT/'assemble.py'),'model_sha256':sha(ROOT/'model.py'),
                 'effective_parameters':asdict(p),'protocol':protocols['budget-protocol']},
       'value':diagnostics(trajectory,p),'units':'mM; mM/min; min; AUC mM*min',
       'depends_on':['BIO-STOICH','BIO-NONNEG','BIO-N-POOL','BIO-ENV','BIO-KINETICS',
          'BIO-CLAMP' if mode=='clamped' else 'BIO-REGEN-CEILING','BIO-G-SOURCE' if p.gsh_source else 'BIO-G-CLOSED'],
       'uncertainty':'Numerical convergence tested; parameters synthetic; no biological confidence interval.'},
      {'id':'BIO-RECOVERY-EMPIRICAL','result_kind':'empirical_comparison','status':'unresolved','value':None,
       'protocol_id':None,'origin':{'data_readiness_receipt':'data/retina_audit.json','sha256':sha(ROOT/'data/retina_audit.json')},
       'units':'not estimated','blocked_by':['BIO-CALIBRATION'],'depends_on':['BIO-CALIBRATION','BIO-ASSAY'],
       'reason':'Inspected data contain no aligned pulse/wait/NADPH/common-future records.'},
      {'id':'BIO-FATE-TRANSFER','result_kind':'hypothesis_or_analogy','status':'out_of_scope','value':None,
       'protocol_id':None,'origin':{'proposal':'coupling.md','sha256':sha(ROOT/'coupling.md')},
       'depends_on':['BIO-FATE'],'blocked_by':['BIO-FATE'],'reason':'No mapping from chemical exposure to survival/longevity.'}]
    if case=='finite':
        summary=json.loads((ROOT/'results'/'summary.json').read_text())
        results.append({'id':'BIO-REPEAT-CHALLENGE','result_kind':'model_prediction','status':'established_in_scope',
          'protocol_id':'repeat-challenge-protocol','preparation_protocol_id':'conditioning-protocol',
          'comparison_protocol_id':'fresh-probe-protocol',
          'value':summary['readout_at_30min'],'units':'fractions; mM; mM*min',
          'depends_on':['BIO-STOICH','BIO-NONNEG','BIO-N-POOL','BIO-G-CLOSED','BIO-REGEN-CEILING','BIO-ENV','BIO-KINETICS'],
          'artifact':'results/summary.json','sha256':sha(ROOT/'results/summary.json'),
          'origin':{'run_receipt':'results/execution.json','run_receipt_sha256':sha(ROOT/'results/execution.json'),
                    'run_input_hashes':campaign['input_hashes'],'protocols':{k:v for k,v in protocols.items() if k!='budget-protocol'}},
          'uncertainty':'Synthetic point prediction; 27-case parameter range is not a confidence distribution.'})
    return dict(
      identity={'id':'biology-redox-recovery-'+case,'version':'0.1.1','producing_task_id':TASK,
        'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent_id':None if case=='finite' else 'biology-redox-recovery-finite'},
      question={'original':'What measurements establish redox recovery and repeated challenge capacity?',
        'target':'Conditional peroxide-clearance capacity and next discriminating measurement',
        'scope':'Synthetic cellular redox subsystem; actual-data readiness audit',
        'intended_user':'Systems-biology modeller and Observatory integrator'},
      system={'entities':['cell reaction compartment','perfused bath','external NADPH-regeneration substrate reservoir','observer'],
        'boundary':'Fixed volumes, GPx/GR module; no transcription or cell-fate model',
        'coupling_ports':'coupling.md','volume_ratio_cell_to_bath':p.volume_ratio},
      observer={'available_measurements':['bath H2O2','GSH','GSSG','NADPH','NADP'],
        'observation_map':'Direct concentration channels after calibration; q=G/(G+2O) is derived, not a fluorescence ratio',
        'clock':'minutes, common zero, full stimulus history retained',
        'preparation':[0,0,p.g_total,0,p.n_total,0],
        'noise':'Synthetic bath/GSH Gaussian SD0.001/0.01mM; real likelihood unresolved',
        'experimental_unit':'Synthetic independent measurement series; actual retina destructive aliquots without linking IDs',
        'actions':['apply input','washout','wait','repeat challenge','destructive chemical assay'],
        'measurement_effect':'Chemical assays destroy aliquots; do not continue that same cell record after sampling'},
      quantities=q,
      operations=[{'id':'input-schedule','input':'U(t)','output':'continuous species and extent trajectory',
        'state_space':'nonnegative species; declared pools','admissibility':'finite nonnegative forcing; strictly ordered timing',
        'protocol_catalog':protocols,'composition':'Ordered nonautonomous ODE propagation; constant-input segments form flows. No scalar UHL composition assumed.',
        'kind':'process'},
        {'id':'concentration-assay','input':'matched physical aliquot','output':'record plus calibration/provenance','kind':'outcome_recording_instrument','duration':'must be calibrated'}],
      constraints={'stoichiometry':'G+2O derivative=Jg; N+Q constant; B derivative=Js-Jp+Jg/2',
        'environment_balance':'(E+rho H) derivative=Jf-kb E-rho(Jp+kc H)',
        'rate_ceiling_present':mode=='finite','positivity':'inward boundary fluxes','units_reference':'mechanism.md'},
      mechanism={'id':'finite-gpx-gr' if mode=='finite' else 'clamped-gpx-gr','equations':'mechanism.md',
        'implementation':'model.py','parameters':asdict(p),'protocols':protocols,
        'source_status':'Reduced effective law forms with explicit added cofactor/bath dynamics; not published-model reproduction',
        'calibration':'synthetic values; biological gate failed'},
      premises=[{'id':i,'statement':s,'evidence_status':e,'source':src,'scope':'this reaction subsystem'} for i,s,e,src in premises],
      execution={'method_id':'scipy.solve_ivp.LSODA','version':'1.18.1','rtol':2e-8,'atol':1e-10,
        'command':'python assemble.py','dependency_steps':['load frozen reference evidence','apply case-specific premise change','recompute trajectory','evaluate exact rational budget','export common record'],
        'needed_premises_by_result':{r['id']:r.get('depends_on',[]) for r in results},
        'input_hashes':{str(f.relative_to(ROOT)).replace('\\','/'):sha(f) for f in [ROOT/'model.py',ROOT/'assemble.py',ROOT/'parameters.json',ROOT/'sources.json']},
        'formal_method':'Exact Fraction arithmetic and independently checked stoichiometric identities; not ODE proof by the shared rational engine'},
      results=results,
      contrast={'case':case,'alternatives':['finite','open_gsh_source','clamped','missing_calibration'],
        'changed_assumption':{'finite':'reference','open_gsh_source':'metered GSH source added; closed-G premise removed',
                             'clamped':'unbounded compensating NADPH source replaces rate ceiling',
                             'missing_calibration':'existing transfer gate, not a newly removed-premise experiment; same model dynamics and uncalibrated empirical status'}[case],
        'execution':'Actual case-specific ODE and budget recomputation; empirical gate is explicit policy/dependency status, not a wet-lab test'},
      next_question={'authorship':'biology lead, authored','question':'Does an absolute NADPH measurement and supply perturbation resolve a recovered-GSH mismatch under a held-out challenge?',
        'protocol':'experiment.md','remaining_uncertainty':'Cell-specific kinetics, pool/volume/assay calibration and alternative clearance'},
      provenance={'source_manifest':'sources.json','code_data_manifest':'manifest.json',
        'citations':['https://doi.org/10.1085/jgp.201210772','https://doi.org/10.1186/1742-4682-5-8','https://doi.org/10.1038/s41598-023-37938-9'],
        'observations':'data/retina_audit.json; actual data never used for synthetic fit',
        'licensing':'NOTICES.md','revision_states':'Local isolated package only; central/GitHub/live Site not modified or asserted equivalent'})

def main():
    receipt=json.loads((ROOT/'results'/'execution.json').read_text())
    for file,h in receipt['input_hashes'].items():
        if sha(ROOT/file)!=h:raise ValueError('Stale numerical receipt for '+file+'; rerun run.py')
    p=load_parameters(ROOT/'parameters.json')
    packages={case:build(case,p) for case in ['finite','open_gsh_source','clamped','missing_calibration']}
    for case,package in packages.items():
        if not all(k in package for k in FIELDS):raise ValueError('Missing shared field')
        dump(ROOT/'cases'/(case+'.json'),package)
    dump(ROOT/'inquiry.json',packages['finite'])
    # Separate common record for the observer-conditioned continuation, with its
    # own originating protocol, intervals, premise-removal case and receipt.
    import copy
    c=json.loads((ROOT/'results/continuation.json').read_text())
    for file,h in c['input_hashes'].items():
        if sha(ROOT/file)!=h:raise ValueError('Stale continuation receipt for '+file+'; rerun continuation.py')
    continuation=copy.deepcopy(packages['finite'])
    continuation['identity']['id']='biology-observer-conditioned-continuation'
    continuation['identity']['parent_id']=packages['finite']['identity']['id']
    continuation['question']['target']='Which GPx-clearance targets can each declared observer exclude from the same prepared state?'
    continuation['mechanism']['protocols']={'preparation':c['history_protocol'],'future':c['future_protocol']}
    continuation['operations'][0]['protocol_catalog']=continuation['mechanism']['protocols']
    continuation['observer']['interval_cases']=c['observer_intervals']
    continuation['observer']['preparation']=c['prepared_state_species_mM']
    continuation['observer']['interval_status']=c['interval_evidence']
    continuation['constraints']['rate_ceiling_present']='Observer-case specific: see Vreg interval; null blocks that bound.'
    continuation['mechanism']['parameter_scope']='Physical constants describe the reference preparation and forward checks; certificate cases use their own explicit interval bounds.'
    continuation['premises']=[x for x in continuation['premises'] if x['id'] in ['BIO-STOICH','BIO-NONNEG','BIO-ACCOUNTING','BIO-G-CLOSED']]
    continuation['premises'][-1]['scope']='Only BIO-CONT-MOIETY and observer cases whose Jg bound is [0,0]; not assumed for the added-source case.'
    additional=['BIO-Q-BOUND','BIO-GTOTAL-BOUND','BIO-NADPH-BOUND','BIO-REGEN-BOUND','BIO-GSOURCE-BOUND']
    for id,key in zip(additional,['q','G_total','N','Vreg','Jg']):
        continuation['premises'].append({'id':id,'statement':'Declared '+key+' interval is a valid bound within the named observer case',
          'evidence_status':'assumed','source':'results/continuation.json observer_intervals; missing entries block that row',
          'scope':'Stipulated simulated-point/interval input, not a measured biological confidence bound'})
    newresults=[]
    for i,row in enumerate(c['table']):
        o=c['observer_intervals'][row['observer']]
        blockers=[id for id,key in zip(additional,['q','G_total','N','Vreg','Jg']) if o[key] is None]
        newresults.append({'id':'BIO-CONT-'+str(i+1),'protocol_id':'future','preparation_protocol_id':'preparation',
          'result_kind':'formal_under_premises','status':row['status'],'value':row,
          'units':'mM GPx-consumed H2O2 over20min','depends_on':['BIO-STOICH','BIO-NONNEG','BIO-ACCOUNTING',*additional],
          'blocked_by':blockers,'observer_case':row['observer'],'parameter_intervals':o,
          'origin':{'artifact':'results/continuation.json','sha256':sha(ROOT/'results/continuation.json'),
                    'input_hashes':c['input_hashes'],'protocols':continuation['mechanism']['protocols']},
          'uncertainty':c['interval_evidence'],'scope':c['conclusion_scope']})
    newresults.append({'id':'BIO-CONT-MOIETY','result_kind':'formal_under_premises','status':'established_in_scope',
       'value':'(G+2O) derivative=0 when Jg=0, including when regeneration rate has no supplied upper bound',
       'depends_on':['BIO-STOICH','BIO-G-CLOSED','BIO-ACCOUNTING'],'units':'mM/min','protocol_id':None,
       'origin':{'artifact':'results/validation.json','sha256':sha(ROOT/'results/validation.json')}})
    continuation['results']=newresults
    continuation['contrast']={'case':'observer-bound-and-premise-removal',
      'action':'Add the absolute cofactor observation, add a source, or remove the previously supplied regeneration ceiling',
      'execution':'Bound function re-executed for every observer/target; three forward trajectories re-executed in continuation.py',
      'specificity_counterexample':c['checks']['specificity_counterexample'],
      'calibration':'Remains absent in every case; no fabricated previously calibrated parent'}
    continuation['execution']['method_id']='Python Fraction arithmetic plus SciPy trajectory checks'
    continuation['execution']['command']='python continuation.py && python assemble.py'
    continuation['execution']['input_hashes']={**c['input_hashes'],'assemble.py':sha(ROOT/'assemble.py'),'sources.json':sha(ROOT/'sources.json')}
    continuation['execution']['needed_premises_by_result']={r['id']:r['depends_on'] for r in newresults}
    continuation['execution']['dependency_steps']=['load the identified30min prepared state','select declared observer intervals','recompute necessary bound','recompute three future mechanisms','check GPx specificity','export per-conclusion receipt']
    dump(ROOT/'continuation_inquiry.json',continuation)
    # Specific executed contrast checks, not authored status labels alone.
    base=packages['finite']['results'][0]['value'];opened=packages['open_gsh_source']['results'][0]['value']
    assert base['target_excluded'] and not opened['target_excluded']
    assert packages['clamped']['results'][0]['status']=='unresolved'
    assert packages['missing_calibration']['results'][1]['status']=='established_in_scope'
    assert packages['missing_calibration']['results'][2]['status']=='unresolved'
    dump(ROOT/'results'/'contrast_validation.json',{'all_passed':True,'checks':5,
      'finite_bound_mM':base['upper_bound_mM'],'open_source_bound_mM':opened['upper_bound_mM'],
      'clamp_bound_status':'unresolved','missing_calibration':'simulation preserved; empirical conclusion unresolved',
      'executed_cases':list(packages)})
    print('Exported four recomputed common inquiry cases; five contrast checks passed')

if __name__=='__main__':main()
