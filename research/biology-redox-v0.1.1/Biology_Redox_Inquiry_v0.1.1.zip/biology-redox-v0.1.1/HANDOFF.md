Portable-distribution note: the corrected scientific v0.1.1 package has independently passed its bounded integration review. This derivative removes private metadata and regenerates dependent envelopes; it does not claim deployed-engine or empirical acceptance. `PUBLICATION_HANDOFF.md` records this separate packaging check. The account below is the specialist release history.

See CORRECTION.md for the separately tested BIO-INT-02 dependency correction.

# Biology handoff — v0.1.1

The isolated package answers a practical question: which observation and supply assumptions justify a claim about recovery of peroxide-handling capacity? It combines ordinary GPx/GR chemistry, an explicit bath, finite molecular reserves, an observer-conditioned necessary bound, reciprocal synthetic mechanism comparisons, and an actual source-table audit. This is a useful integration of known methods, not a new redox law or an empirical recovery discovery.

The default synthetic preparation at minute 30 has GSH fraction 0.999777 and NADPH fraction 0.126923. A repeated challenge gives 1.32952 times the fresh intracellular peroxide AUC. A 27-case sensitivity grid shows all four combinations of the declared signal and repeat-response margins, so the selected gap or signal threshold is not universal.

The main new connection is `continuation_inquiry.json`: 24 observer/target conclusions and one unaffected moiety result. For a 0.6 mM GPx-clearance target over 20 min, q plus the absolute glutathione pool and a total NADP-pool bound gives a 0.639889 mM ceiling, which does not exclude the target. Adding the simulated absolute NADPH value tightens the ceiling to 0.570043 mM and excludes it. Missing the previously supplied regeneration ceiling blocks the certificate; closed-pool moiety conservation still follows. An added GSH source changes the bound. Alternative peroxide removal can exceed the GPx bound without violating it. Non-exclusion never establishes feasibility.

The imported retinal supplement reproduces 126 printed values and all 22 mean/SD groups. Recovery validation fails because the destructive developmental samples lack pulse/wait/rechallenge input histories, cofactor records, assay-volume calibration, and identifiers supporting analyte pairing. These data were never fitted to the synthetic cell. `experiment.md` specifies the discriminating next action: calibrated absolute GSH/GSSG and NADPH measurements plus a held-out repeat challenge and supply perturbation.

## Review and checks

The coordinator independently reran an earlier numerical revision: all 24 then-existing validation checks passed and four parsed result files matched exactly. The review identified ignored protocol fields, mixed result/protocol provenance, stale numeric premise text, an incorrectly attributed HOG exclusion rationale, and omitted sensitivity categories. This release repairs those findings; their corrections have local regression and provenance checks. Final release acceptance by the coordinator is a separate integration step.

The release has 25 mechanism/solver checks, five executable-scenario checks, seven continuation checks, five recomputed contrast checks, 26 provenance-link checks, and five integrity mutation checks. The ordinary independently transcribed reduced ODE agrees to 6.89e-11 mM. Numerical checks are not a theorem about empirical cells. Source hashes identify consulted versions rather than independently attesting their truth.

## Integration boundary

Use the five case envelopes (`inquiry.json` duplicates `cases/finite.json`) and the continuation envelope with their per-result dependencies, originating protocols and hashes. Suggested visible order is question, observation, physical supply assumptions, excluded/not-excluded/unresolved consequence, changed premise, and next measurement. `visual_spec.md` maps each view to actual files; `reference.png` and `reference.svg` are reproducible figures. `run.py --scenario` executes supported custom inputs; the default benchmark is explicitly fixed.

The quantum lead's product-time-density convolution is accepted as a dimensional interface specification in `coupling.md`. Absolute pair births, physical time, product stoichiometry and optical/chemical calibration remain missing; no quantitative quantum-to-cell transfer is admitted. Cell-to-tissue composition requires measured volumes, transport, heterogeneity and an endpoint map.

No central checkout, shared Site, public GitHub or deployment was changed by this task. The package is frozen for local review and integration; publication terms and shared schema normalization remain with the coordinator. See `PUBLIC_FILES.md` for candidate public content and `README.md` for commands. Preserve the frozen manifest before re-execution; rerun in an owned review copy.
