# BIO-INT-02 — v0.1.1 correction

The independent mathematics and integration reviews found a real dependency omission in v0.1.0: its concentration bounds assumed a common fixed volume and complete source/sink accounting without attaching that obligation to each result. v0.1.1 adds the stable `BIO-ACCOUNTING` premise to all four base GPx budgets, all 24 continuation bounds and the concentration moiety identity. The abstract bounds do not gain unnecessary kinetic-law premises.

`accounting_validation.py` checks all 29 dependencies, the distinct regeneration-only removal, and an explicit shrinking-volume countermodel. With V(t)=exp(-t/10) litres, GSH amount 1−0.04t mmol and GPx amount flux 0.02 mmol/min for 20 min, the integrated concentration-normalized GPx rate is about 1.278 mM, exceeding the incorrectly retained 0.5 mM concentration ceiling. The amount ledger remains valid: 0.4 mmol consumed is below its 0.5 mmol reserve. Fixed normalization is therefore a substantive premise, not bookkeeping decoration.

Numerical model, physical parameters, synthetic observations and original scientific conclusions are unchanged. Exported inquiry records, per-result dependencies and their hashes are regenerated. The original frozen v0.1.0 remains intact. The growing v0.2 anatomy platform uses the corresponding narrower `BIO-VOLUME`, `BIO-LEDGER` and matched-unit obligations.
