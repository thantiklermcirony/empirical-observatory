# Scale and mechanism coupling contract

The adapter exposes a redox reaction subsystem, not a complete cell. A similarly named variable at another scale is not an admissible connection without a measured map.

| Port | Quantity and timing | Evidence needed before connection |
|---|---|---|
| Environment → cell | H2O2 concentration at cell boundary, mM; sample clock in minutes; piecewise input plus measured transport delay | Delivered concentration, mixing, membrane permeability, cell/bath volumes; drift and assay calibration |
| Cell → environment | signed H2O2 transfer `Jm`, mM/min **per cell volume** | Multiply by actual cell volume to get amount/time; use cell number/density and bath volume to aggregate |
| Metabolic supply → redox pool | Js, mM NADPH equivalents/min; source budget integral; NADP acceptor pool | Enzyme/substrate flux, redox stoichiometry, compartment specificity, alternative NADPH sinks; no automatic identification with total ATP or “energy” |
| Cell → observer | G, O, N, Q and E; predicted raw measurement via calibrated map | Assay recovery, calibration, measurement delay, pH, extraction dilution, censoring, sample and replicate hierarchy |
| Cell population → tissue | amount flux sum or distribution of cellular states | Cell volumes, heterogeneous parameters, extracellular diffusion/consumption, interfaces and geometry; nonlinear mean response is not response at mean state |
| Tissue → organism | separately measured functional/fate endpoint | Physiological bridge and validation in the relevant organism/context; no current map from H2O2 AUC to lifespan, wellbeing or organ function |
| Controller → environment | permitted incoming concentration/flow schedule and bounded supply actuator | Actual actuator limits, dose/energy costs, observation latency and calibration; a TAO extension must face tuned conventional control at equal costs |

Feedback is explicit: the bath equation includes `-rho*Jm`. For a tissue discretization replace this term by properly volume-weighted local uptake and diffusion; the fixed bath and closed G certificates then require rechecking. A cell-volume change contributes dilution terms. GSH synthesis/export changes `(G+2O)'`; shared NADPH demands subtract from B'. The exact moiety algebra survives only with its correct added fluxes.

## Quantum interface agreed with the quantum lead

The initial quantum reference reports a dimensionless singlet reaction yield PhiS, per prepared radical-pair ensemble and specified readout window, along with explicit reaction sinks. Its initial `k=omega=1` example used dimensionless time; it was not a cryptochrome calibration. Subsequent physical solver development remains owned by the quantum lead.

A prospective port is:

`J_product(t) = nu × R_pair(t) × PhiS(environment, preparation, window)`.

Here R_pair must be a calibrated pair-generation concentration rate (mM/min) for the declared compartment; nu is measured product stoichiometry. If the quantum response is not fast compared with biological forcing, replace the instantaneous formula by an explicit reaction-history kernel/state coupling. Avoid counting one radical-pair event both as a new input and as part of an existing source. Propagate uncertainty and shared-parameter covariance, not independent error bars by default. A signed difference between two yields is a contrast, not an absolute nonnegative source term.

The 2021 CRY4 Figure 2 workbook inspected by the quantum lead contains absorbance-related response curves, not automatically absolute reaction yields. Optical path length, extinction coefficients, contributing species, excitation dose, concentration, timing and reference subtraction are needed for a chemical observation map. Absorbance percentage is neither PhiS nor a GSH concentration. The present biology package admits **no quantitative quantum-to-redox coupling**. Its status is unresolved, with the quantum lead owning spin kinetics/likelihood and biology owning downstream stoichiometry and assay calibration.

The quantum lead's more precise stationary-environment proposal is accepted as an interface specification: let `b(t)` be pair births in mM/min and `fS(a)` the singlet-product time density per prepared pair in 1/min. Then `J_product(t)=nu*integral_0^infinity b(t-a) fS(a) da`, and `PhiS=integral fS(a) da`. A constant source at steady state gives `nu*b*PhiS`. Time-dependent source multiplication requires a separation-of-timescales approximation; environment feedback during pair evolution needs a history-conditioned kernel. Dimensionless solver time requires an independently calibrated physical time scale before this integral can supply a cellular flux. The reference does not execute this uncalibrated coupling.

Required conventional alternatives include field-independent chemistry, plausible field-dependent phenomenological responses and calibrated rate/dephasing limits, using the same measured conditions and fitting information. No current result establishes a quantum contribution to cellular adaptation.

## Programme connections that can be tested next

1. Combine the necessary B budget with diagnostic latency: a measurement can arrive too late to inform a feasible exposure/supply action. The budget constraint is formal; a meaningful action-error bound requires real record likelihoods and actuator/fate costs. The mathematical lead's action-sufficiency results do not supply those biological inputs.
2. Use absolute pool and cofactor assays to test whether q plus one added channel predicts a held-out challenge within declared margins. This is an identifiable measurement question; calling q an arctanh coordinate cannot restore missing pool information.
3. Extend the conservation ledger to populations with measured volumes and transport. The resulting assay-location question is useful only after validating the transport mechanism, not by rendering many copies of the same simulated cell.
