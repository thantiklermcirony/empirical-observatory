"""Changed input/seed/horizon and rejection regression; no inert advertised fields."""
import tempfile,json,copy
from pathlib import Path
from scenario import execute
from model import load_parameters
ROOT=Path(__file__).resolve().parent

def main():
    cases=[]
    with tempfile.TemporaryDirectory(prefix='biology-protocol-') as temp:
        w=Path(temp);source=json.loads((ROOT/'examples/single_pulse.json').read_text())
        def run(name,s):
            f=w/(name+'.json');f.write_text(json.dumps(s));return execute(ROOT/'parameters.json',f,w/name)
        a=run('a',source)
        s=copy.deepcopy(source);s['schedule'][1][1]=.06;b=run('dose',s)
        assert b['diagnostics']['cell_h2o2_auc_mM_min']>a['diagnostics']['cell_h2o2_auc_mM_min']
        assert a['input_hashes']['scenario_sha256']!=b['input_hashes']['scenario_sha256']
        assert a['artifacts']['trajectory.csv']!=b['artifacts']['trajectory.csv']
        cases.append({'check':'dose_changes_physics_and_provenance','passed':True,'before_auc':a['diagnostics']['cell_h2o2_auc_mM_min'],'after_auc':b['diagnostics']['cell_h2o2_auc_mM_min']})
        s=copy.deepcopy(source);s['seed']+=1;c=run('seed',s)
        assert c['artifacts']['trajectory.csv']==a['artifacts']['trajectory.csv'] and c['artifacts']['synthetic_observations.csv']!=a['artifacts']['synthetic_observations.csv']
        cases.append({'check':'seed_changes_only_synthetic_noise_and_provenance','passed':True})
        s=copy.deepcopy(source);s['horizon_min']=40;s['sample_interval_min']=.5;d=run('time',s)
        assert len((w/'time'/'trajectory.csv').read_text().splitlines())==82
        cases.append({'check':'horizon_and_sample_interval_execute','passed':True})
        s=copy.deepcopy(source);s['unimplemented_control']=1
        try:run('bad',s)
        except ValueError:pass
        else:raise AssertionError('Unknown scenario field ignored')
        cases.append({'check':'unknown_scenario_field_rejected','passed':True})
        for key,val in [('schedule',[[0,0]]),('horizon_min',10),('random_seed',1)]:
            bad=json.loads((ROOT/'parameters.json').read_text());bad[key]=val
            file=w/'badparams.json';file.write_text(json.dumps(bad))
            try:load_parameters(file)
            except ValueError:pass
            else:raise AssertionError('Inert legacy parameter field accepted')
        cases.append({'check':'legacy_inert_parameter_fields_rejected','passed':True})
    (ROOT/'results'/'scenario_validation.json').write_text(json.dumps({'all_passed':True,'checks':cases},indent=2)+'\n')
    print('Five scenario/configuration checks passed')
if __name__=='__main__':main()
