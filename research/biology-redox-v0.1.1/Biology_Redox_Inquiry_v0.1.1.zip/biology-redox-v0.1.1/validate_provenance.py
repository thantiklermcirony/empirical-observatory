"""Validate current local input, artifact and per-result dependency links."""
from pathlib import Path
import json,hashlib
root=Path(__file__).resolve().parent
def read(p):return json.loads((root/p).read_text(encoding='utf8'))
def sha(p):return hashlib.sha256((root/p).read_bytes()).hexdigest()
checks=[]
def check(name,ok):
 assert ok,name
 checks.append({'name':name,'passed':True})
for p in ['results/execution.json','results/continuation.json']:
 d=read(p)
 check(p+' input hashes',all(sha(f)==v for f,v in d['input_hashes'].items()))
fields=set('identity question system observer quantities operations constraints mechanism premises execution results contrast next_question provenance'.split())
for p in [Path('inquiry.json'),Path('continuation_inquiry.json'),*[Path('cases')/p.name for p in (root/'cases').glob('*.json')]]:
 d=read(p);check(str(p)+' common fields',set(d)==fields)
 pre={x['id'] for x in d['premises']};protocols=d['mechanism']['protocols']
 for r in d['results']:
  assert set(r.get('depends_on',[]))<=pre,(p,r['id'])
  for key in ['protocol_id','preparation_protocol_id','comparison_protocol_id']:
   assert r.get(key) is None or r[key] in protocols,(p,r['id'],key)
  if 'artifact' in r:assert sha(r['artifact'])==r['sha256']
  o=r.get('origin',{})
  for key in ['artifact','data_readiness_receipt','proposal']:
   if key in o:assert sha(o[key])==o['sha256']
  if 'run_receipt' in o:assert sha(o['run_receipt'])==o['run_receipt_sha256']
  for f,h in o.get('input_hashes',{}).items():assert sha(f)==h
 check(str(p)+' premise protocol artifact links',True)
 check(str(p)+' execution hashes',all(sha(f)==h for f,h in d['execution']['input_hashes'].items()))
c=read('continuation_inquiry.json')
removed=[r for r in c['results'] if r.get('observer_case')=='cofactor_without_regeneration_ceiling']
check('removed rate bound blocks exactly its four target rows',len(removed)==4 and all(r['status']=='unresolved' and r['blocked_by']==['BIO-REGEN-BOUND'] for r in removed))
check('moiety survives removal',c['results'][-1]['status']=='established_in_scope' and 'BIO-REGEN-BOUND' not in c['results'][-1]['depends_on'])
s=read('results/custom_example/execution.json')
check('custom scenario input hashes',s['input_hashes']['scenario_sha256']==sha('examples/single_pulse.json') and s['input_hashes']['parameters_sha256']==sha('parameters.json') and s['input_hashes']['scenario.py']==sha('scenario.py') and s['input_hashes']['model.py']==sha('model.py'))
check('custom scenario artifact hashes',all(sha('results/custom_example/'+f)==h for f,h in s['artifacts'].items()))
check('bundled source hashes',all(x.get('bundled_path') is None or sha(x['bundled_path'])==x['sha256'] for x in read('sources.json')['sources']))
check('all numerical validation passed',read('results/validation.json')['all_passed'] and read('results/scenario_validation.json')['all_passed'] and read('results/continuation.json')['checks']['all_passed'] and read('results/contrast_validation.json')['all_passed'])
report={'all_passed':True,'scope':'Final source, execution, result and protocol linkage audit; not empirical validation','checks':checks,'count':len(checks)}
(root/'results/final_provenance_check.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps({'all_passed':True,'count':len(checks)}))
