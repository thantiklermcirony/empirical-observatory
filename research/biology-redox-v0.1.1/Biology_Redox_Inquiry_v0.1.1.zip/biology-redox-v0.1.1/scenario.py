"""Executable, strictly checked custom scenario interface for the redox adapter."""
import json,hashlib,csv,platform
from pathlib import Path
import numpy as np
import scipy
from model import load_parameters,simulate,diagnostics,NAMES

FIELDS={'schema_version','name','schedule','horizon_min','sample_interval_min','seed','mode','observation_noise_sd_mM'}

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def execute(parameters_path,scenario_path,out):
    p=load_parameters(parameters_path);s=json.loads(scenario_path.read_text(encoding='utf8'))
    if set(s)!=FIELDS or s['schema_version']!=1:raise ValueError('Unknown/missing scenario fields or schema version')
    h,dt=s['horizon_min'],s['sample_interval_min']
    if not all(isinstance(x,(int,float)) and np.isfinite(x) and x>0 for x in [h,dt]) or h/dt>100000:
        raise ValueError('Positive finite horizon/interval and at most100000 intervals required')
    seed=s['seed'];noise=np.asarray(s['observation_noise_sd_mM'])
    if type(seed)!=int or not 0<=seed<2**32:raise ValueError('Seed must be uint32 integer')
    if noise.shape!=(2,) or not np.all(np.isfinite(noise)) or np.any(noise<=0):raise ValueError('Two positive observation SDs required: bath,GSH in mM')
    ts=np.r_[np.arange(0,h,dt),h]
    r=simulate(p,s['schedule'],ts,mode=s['mode'])
    obs=r['y'][:,[0,2]]+np.random.default_rng(seed).normal(size=(len(ts),2))*noise
    out.mkdir(parents=True,exist_ok=True)
    with (out/'trajectory.csv').open('w',newline='',encoding='utf8') as f:
        w=csv.writer(f);w.writerow(['time_min','incoming_h2o2_mM',*NAMES]);w.writerows([[t,u,*y] for t,u,y in zip(ts,r['incoming'],r['y'])])
    with (out/'synthetic_observations.csv').open('w',newline='',encoding='utf8') as f:
        w=csv.writer(f);w.writerow(['time_min','bath_h2o2_mM','gsh_mM']);w.writerows([[t,*y] for t,y in zip(ts,obs)])
    root=Path(__file__).resolve().parent
    result={'schema_version':1,'scenario':s,'status':'established_in_scope','result_kind':'model_prediction',
      'scope':'Synthetic reference under declared kinetics; observation rows are generated Gaussian measurements, not biological records',
      'diagnostics':diagnostics(r,p),'state_preparation':[0,0,p.g_total,0,p.n_total,0],
      'input_hashes':{'scenario_sha256':digest(scenario_path),'parameters_sha256':digest(parameters_path),
                      'model.py':digest(root/'model.py'),'scenario.py':digest(root/'scenario.py')},
      'artifacts':{x:digest(out/x) for x in ['trajectory.csv','synthetic_observations.csv']},
      'runtime':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__},
      'observation':'Direct bath/GSH mM channels with configured independent Gaussian SD; no censoring; actual calibration missing'}
    (out/'execution.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf8')
    return result
