"""BIO-INT-02 dependency regression and a variable-volume countermodel."""
from pathlib import Path
import json,math,hashlib
ROOT=Path(__file__).resolve().parent
def main():
    read=lambda p:json.loads((ROOT/p).read_text())
    results=[read('cases/'+c+'.json')['results'][0] for c in ['finite','open_gsh_source','clamped','missing_calibration']]+read('continuation_inquiry.json')['results']
    assert len(results)==29
    for r in results:
        assert 'BIO-ACCOUNTING' in r['depends_on'],r['id']
        missing=set(r['depends_on'])-({'BIO-ACCOUNTING'}^set(r['depends_on']))
        assert 'BIO-ACCOUNTING' in missing
    cont=read('continuation_inquiry.json')
    moiety=next(r for r in cont['results'] if r['id']=='BIO-CONT-MOIETY')
    assert 'BIO-REGEN-BOUND' not in moiety['depends_on'] and 'BIO-G-CLOSED' in moiety['depends_on']
    removed=[r for r in cont['results'] if r.get('observer_case')=='cofactor_without_regeneration_ceiling']
    assert len(removed)==4 and all(r['status']=='unresolved' and r['blocked_by']==['BIO-REGEN-BOUND'] for r in removed)
    # V(t)=exp(-t/10)L; G amount=1-.04t mmol, GPx amount rate=.02mmol/min.
    # G amount stays >=.2 mmol through20min. Integral Jp(concentration rate)
    # is .2(exp(2)-1)mM, exceeding initial concentration reserve .5mM.
    # Amount consumed .4mmol still obeys initial amount reserve .5mmol.
    false_concentration_extent=.2*math.expm1(2)
    assert false_concentration_extent>.5 and .02*20<=.5 and 1-.04*20>0
    receipt=dict(all_passed=True,bound_and_moiety_dependencies_checked=29,volume_removal='all29 concentration conclusions blocked by their required BIO-ACCOUNTING premise',regeneration_removal='four budget rows blocked; moiety retained under closed fixed accounting',counterexample=dict(volume_litres='exp(-t/10)',gsh_amount_mmol='1-.04t',duration_min=20,gpx_amount_rate_mmol_per_min=.02,integrated_concentration_extent_mM=false_concentration_extent,invalid_fixed_volume_ceiling_mM=.5,actual_gpx_amount_mmol=.4,valid_amount_ceiling_mmol=.5),input_hashes={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ['assemble.py','accounting_validation.py','continuation_inquiry.json']})
    (ROOT/'results/accounting_validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'all_passed':True,'concentration_results':29,'variable_volume_counterexample':false_concentration_extent}))
if __name__=='__main__':main()
