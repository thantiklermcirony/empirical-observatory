"""Independent balance/coordinate/solver and invalidation checks."""
import json, itertools
from dataclasses import replace
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.integrate import solve_ivp
from model import Parameters, simulate, rhs, diagnostics
from run import dump, numerical_restart, challenge

ROOT=Path(__file__).resolve().parent

def conventional_reduced(p,schedule,times):
    """Ordinary four-species ODE, independently transcribed in pool coordinates.

    This is the strong conventional equivalent, not the changed-physics clamp.
    """
    out=np.empty((len(times),4));y=np.array([0.,0.,p.g_total,p.n_total]);out[0]=y
    def f(t,y,u):
        e,h,g,n=y;o=(p.g_total-g)/2;q=p.n_total-n
        jp=h*g/(p.phi_h*g+p.phi_g*h) if h or g else 0.
        jr=p.v_gr*(o/(p.k_gssg+o))*(n/(p.k_nadph+n))
        js=p.v_reg*q/(p.k_nadp+q)
        m=p.permeability*(e-h)
        return [p.bath_exchange*(u-e)-p.bath_decay*e-p.volume_ratio*m,
                m-jp-p.other_clearance*h,-2*jp+2*jr,js-jr]
    for (a,u),b in zip(schedule,[x[0] for x in schedule[1:]]+[times[-1]]):
        sol=solve_ivp(f,(a,b),y,args=(u,),method='DOP853',rtol=1e-10,atol=1e-12,dense_output=True)
        if not sol.success:raise RuntimeError(sol.message)
        idx=(times>a)&(times<=b);out[idx]=sol.sol(times[idx]).T;y=sol.y[:,-1]
    return out

def main():
    checks=[]
    def check(name,ok,detail):
        checks.append({'name':name,'passed':bool(ok),'detail':detail})
        if not ok:raise AssertionError(name+': '+str(detail))
    p=Parameters();t=np.linspace(0,90,361);sched=((0,0),(5,.03),(10,0),(30,.15),(35,0))
    # Columns: GPx, GR, regeneration. Rows: H2O2, GSH, GSSG, NADPH, NADP.
    S=sp.Matrix([[-1,0,0],[-2,2,0],[1,-1,0],[0,-1,1],[0,1,-1]])
    g=sp.Matrix([[0,1,2,0,0]]);n=sp.Matrix([[0,0,0,1,1]]);b=sp.Matrix([[0,sp.Rational(1,2),0,1,0]])
    check('exact_G_and_N_stoichiometry',g*S==sp.zeros(1,3) and n*S==sp.zeros(1,3),{'G':str(g*S),'N':str(n*S)})
    check('exact_reducing_budget',b*S==sp.Matrix([[-1,0,1]]),str(b*S))
    C,T=sp.symbols('C T',positive=True)
    dimensions=[C*C/(T*C),(C/T)*C*C/(C*C),(C/T)*C/C,(1/T)*C]
    check('kinetic_and_transport_dimensions',all(sp.simplify(d-C/T)==0 for d in dimensions),
          'GPx, GR, regeneration and membrane transport each have concentration/time; rho is dimensionless; both bath and cell balances use the appropriate volume normalization.')
    bound=sp.Rational(1,2)+sp.Rational(8,100)+sp.Rational(3,1000)*20
    check('exact_capacity_exclusion',bound==sp.Rational(16,25) and bound<sp.Rational(4,5),str(bound))
    # Boundary evidence samples supplement (do not replace) analytical inwardness proof.
    rng=np.random.default_rng(117)
    min_boundary=0.
    for _ in range(100):
        y=np.zeros(14);y[:6]=rng.uniform(0,.5,6)
        for idx in range(6):
            z=y.copy();z[idx]=0;min_boundary=min(min_boundary,rhs(0,z,p,.1,'finite')[idx])
    check('sampled_boundary_inwardness',min_boundary>=0,min_boundary)
    runs={m:simulate(p,sched,t,method=m) for m in ['LSODA','Radau','BDF']}
    for m,r in runs.items():
        d=diagnostics(r,p)
        check(m+'_mass_balance',max(d[k] for k in d if 'max_error' in k)<1e-7,d)
        check(m+'_positivity_with_numerical_tolerance',d['min_species_mM']>=-1e-8,d['min_species_mM'])
    ref=simulate(p,sched,t,method='Radau',rtol=1e-10,atol=1e-12)
    for m,r in runs.items():
        e=float(np.max(np.abs(r['y'][:,:6]-ref['y'][:,:6])))
        check(m+'_tight_solver_convergence',e<3e-7,{'max_species_difference_mM':e})
    ordinary=conventional_reduced(p,sched,t)
    e=float(np.max(np.abs(ordinary-ref['y'][:,[0,1,2,4]])));ordinary_error=e
    check('ordinary_kinetic_comparator_equivalence',e<3e-7,{'max_difference_mM':e,'claim':'Same mechanism, same prediction; no representation superiority'})
    zero=simulate(p,((0,0),),t)
    e=float(np.max(np.abs(zero['y'][:,:6]-zero['y'][0,:6])))
    check('zero_challenge_exact_rest',e<1e-12,e)
    shut=simulate(replace(p,permeability=0),sched,t)
    check('impermeable_cell_limit',np.max(np.abs(shut['y'][:,1:6]-shut['y'][0,1:6]))<1e-12,'Bath forcing cannot enter cell')
    no=simulate(replace(p,v_reg=0),sched,t)
    check('no_regeneration_budget',no['y'][-1,6]<=p.g_total/2+p.n_total+1e-8,float(no['y'][-1,6]))
    opened=simulate(replace(p,gsh_source=.03),sched,t)
    check('open_pool_changes_conservation',abs(opened['y'][-1,2]+2*opened['y'][-1,3]-p.g_total-.03*t[-1])<1e-7,
          'Old constant-G premise must be removed; updated source ledger conserves balance')
    c=simulate(p,sched,t,mode='clamped')
    check('clamp_requires_external_supply',c['y'][-1,8]>p.v_reg*t[-1],{'clamp_supply_mM':float(c['y'][-1,8]),'finite_rate_ceiling_mM':p.v_reg*t[-1]})
    # Expected failures are handled; neither malformed inputs nor missing physics receive a result.
    for name,kw in [('negative_input',{'schedule':((0,-1),)}),('bad_time',{'times':np.array([0,2,1])}),
                    ('wrong_pool',{'initial':[0,0,2,0,.08,0]}),('missing_mechanism',{'mode':'quantum'})]:
        try:simulate(**kw)
        except ValueError:check(name+'_rejected',True,'ValueError as expected')
        else:check(name+'_rejected',False,'Unexpected successful execution')
    # Literal legacy printed-vector-field counterexample, no clipping added.
    boundary=sp.Rational(1)*100/(5+100)-sp.Rational(2)
    check('legacy_outward_boundary_counterexample',boundary<0,{'Gdot_at_zero':str(boundary),'units':'uM/min when Vtotal=1; V=1,beta=2,Gmax=100,KM=5','scope':'Printed vector field requires additional boundary semantics'})
    dump(ROOT/'results'/'validation.json',{'all_passed':True,'check_count':len(checks),'checks':checks,
         'scope':'Algebra and finite numerical checks for this reference; not a general ODE proof or empirical validation'})
    print(json.dumps({'all_passed':True,'check_count':len(checks),'equivalent_ordinary_model_max_error_mM':ordinary_error}))

if __name__=='__main__':main()
