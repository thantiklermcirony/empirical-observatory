# Next discriminating experiment

**Decision to resolve:** after peroxide washout and an apparently recovered GSH fraction, is repeat-challenge peroxide handling still limited by NADPH supply? This is a prospective protocol specification, not an executed experiment, safety recommendation or established dose regimen. The numeric timings below come from the synthetic reference and must be scaled by a pilot in a named cell preparation.

## Minimal sequence

1. In a reconstituted GPx/GR/cofactor system, verify reaction stoichiometry, concentration-assay calibration, delivered input timing and the regeneration law. This inexpensive biochemical stage can reject the adapter before cell work; it does not validate membrane transport or cell fate.
2. In a defined cell preparation and fixed culture conditions, pilot a sublethal conditioning pulse and washout. Measure actual inlet/outlet H2O2, flow/volume and mixing delay; programmed dosing is not delivered concentration. Confirm that cell loss, growth, export and glutathione synthesis are negligible over the proposed closed-pool horizon, or switch to the open-pool equations.
3. Compare fresh/sham history against conditioning then washout. Randomize whole independent culture preparations to gaps spanning observed GSH-fraction and NADPH restoration, rather than selecting only a favourable gap. Synthetic starting ladder: 10,20,40,60 minutes after washout. At each gap apply the same second challenge to separate matched aliquots. Keep no-second-challenge controls.
4. Before rechallenge, assay absolute GSH/GSSG and NADPH/NADP from rapidly quenched matched destructive aliquots. Record cell counts, volume/protein conversion, extraction recovery, calibration lot, blanks, dilution and limits of quantification. Do not pair different assays by row number. At both challenges record a validated H2O2 channel over the full exposure and recovery window.
5. Add a perturbation that changes NADPH regeneration with measured target engagement, plus its solvent/control condition. Such a perturbation can affect other pathways; record specificity and fit those alternatives. A clamp-like result may instead require another peroxide-clearance pathway or altered transport. Those explanations remain competitors.

## Measurement plan

| Channel | Timing and unit | What it resolves |
|---|---|---|
| Delivered bath H2O2 | inlet/outlet time series, µM and seconds/minutes; known flow and bath volume | Exposure alignment, uptake versus external loss |
| GSH and GSSG | matched quenched aliquots before conditioning, washout, each gap and after rechallenge; molecular concentration plus raw instrument values | Absolute pool, fraction and stoichiometric convention |
| NADPH and NADP | same nominal times with sample IDs connecting preparations and aliquots | Hidden reduced cofactor and regeneration ceiling |
| Calibrated H2O2 response | full second-challenge trajectory | Clearance or intracellular exposure; not automatically damage |
| Separate fate assay, if later required | prospectively specified long-term endpoint | Whether chemical recovery predicts durable biological recovery; absent from current reference |

The reference predicts a minute-30 GSH difference of only about 0.000223 mM from fresh, but an NADPH difference of about 0.06985 mM. Under *assumed* per-sample SDs 0.01 and 0.005 mM, the second is much more discriminating. `results/measurement_design.json` reports these expected differences and their scale relative to independent measurement error. This is a candidate channel/time, not an optimal design or a power calculation. Pilot precision, preparation variation and effect sizes must set the final allocation; no fabricated animal or culture sample-size justification is supplied.

## Analysis locked before confirmatory data

Use common observation maps and assay-noise models for finite-cofactor, clamped-cofactor and conventional additional-clearance models. Fit to complete calibration preparations; hold out entire preparations and at least one dose/gap or supply perturbation. Never split neighbouring time points at random. All preprocessing, baseline windows, exclusions and limits of quantification are fixed using calibration data. Do not force a recovered endpoint through normalization.

Declare an experimental unit hierarchy: independent culture/batch, condition, well, cell if relevant, destructive aliquot and technical assay replicate. Repeated readings of one well are not new independent cultures. Begin with batch effects and correlated trajectories unless calibration justifies independent residuals. A likelihood for a derived ratio must propagate correlated numerator/denominator errors; the current simple Gaussian concentration likelihood does not establish it.

Choose outcome margins in physically meaningful units before confirmatory measurement: degree of fraction matching, minimum meaningful clearance/AUC difference and permissible residual mismatch. Estimate differences with uncertainty at the independent-preparation level. A common-future difference after matching q alone establishes failure of q as a predictor only within that declared battery; it does not identify NADPH unless additional measurements/interventions exclude alternatives. Lack of difference supports only the tested horizon and margins, and may be inconclusive at insufficient precision.

**Reject or narrow the proposed mechanism** if the predicted cofactor deficit is absent, restored N fails to restore the challenge response, altered transport or non-GPx clearance explains the result, or open-pool synthesis/export invalidates the conserved-pool assumption. A negative result is informative. There is no requirement to find hormesis, hidden memory, a fold, a longevity benefit or an Observatory advantage.
