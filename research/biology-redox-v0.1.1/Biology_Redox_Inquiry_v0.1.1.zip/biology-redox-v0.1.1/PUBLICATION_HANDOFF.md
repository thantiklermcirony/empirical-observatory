# Publication handoff — biology v0.1.1 portable distribution 1

Prepared for `empirical-observatory/research/biology-redox-v0.1.1`. This folder is the complete upload candidate; copy its files with their relative paths. No public repository, Site, domain source or board was changed by this packaging task.

**Release terms confirmed:** Newly authored project code and documentation: MIT, copyright (c) 2026 Daniel John Murray, following the target repository terms selected by the release coordinator. Third-party source data, supplements, dependencies and manuscript materials retain their own terms; see LICENSE and NOTICES.md.

The corrected scientific release was independently accepted for local integration within its synthetic, fixed-premise scope. Its archive SHA256 is `a070d55b0574f9327215587680d7586588ebd8e8c397afdaead32bf97cd90c9a`; original manifest SHA256 is `54c184014ace197d7020ae0c584516ef5f60f087813f4f2cb3b81a94752dd78b`. This is a deliberately distinct metadata derivative, not a claim that the original frozen bytes are unchanged.

## Exact content and changes

`manifest.json` is the upload allowlist and SHA256 inventory for every other file in this folder. The manifest itself is also required; no self-hash is embedded. `PORTABLE_CHANGES.json` compares every original file and identifies additions. The original source still matches all 74 accepted manifest entries.

Thirteen original files changed: `sources.json`, the exporter `assemble.py`, six regenerated inquiry envelopes, the accounting receipt, and four release/provenance documents. Thirty-eight machine source locations and local coordination state are omitted; inspected source IDs, hashes, available URLs and scope remain. Private sources are explicitly unavailable to the public and are not execution dependencies. The exporter now emits a null task identity. Its syntax tree is otherwise identical. Envelope changes are limited to that identity, actual regeneration timestamps and current exporter/source hashes. The accounting receipt changes only its input hashes.

**Scientific core hash changes: none.** All 61 other original files are byte-identical, including model, run/scenario/continuation/numerical validation code, inputs, numerical trajectories, stored fits, actual-data extraction, continuation bounds, proof/mechanism text and figures. Model assumptions and BIO-ACCOUNTING dependencies remain unchanged. Necessary-bound non-exclusion still does not establish feasibility or recovery.

The two unchanged author supplements remain attributed under their declared CC BY 4.0 and CC BY 2.0 terms. No Aon XML/figures, private manuscript, installed dependency, local runtime or coordination record is distributed. See `NOTICES.md`; the supplement licence does not license the newly authored package.

## Replayed portable checks

Using the original Python 3.12.14 Windows environment, commands executed from this package folder were:

```text
python -B validate.py
python -B test_scenario.py
python -B continuation.py
python -B assemble.py
python -B accounting_validation.py
python -B validate_provenance.py
```

They passed 25 mechanism checks, five scenario regressions, the seven-check continuation, five contrasts, 29 accounting dependencies with a shrinking-volume counterexample, and 26 provenance checks. `PORTABILITY_RECEIPT.json` records commands, exits, outputs and local-log hashes. Stored fitting campaigns, sensitivity results and figures were retained without refitting; `README.md` supplies their full regeneration commands. Fresh installation and other operating systems were not tested.

Check a frozen download before regeneration:

```text
python -B verify_package.py --self-test
```

This checks the distinct portable manifest and its five in-memory mutation tests. Execute regeneration only in a writable copy: it intentionally changes envelope timestamps and hashes. Do not regenerate a manifest to hide unexpected corruption. Follow the dependency order above and rerun the exporter after deliberate input/provenance changes. Dependency installation is `python -m pip install -r requirements.txt`; optional supplement extraction uses `requirements-research.txt` and the README command. Network is not needed for the supplied-data checks after dependencies are installed.

The portable receipt verifies packaging and supplied-model reproduction, not new empirical biology, external peer review, clinical safety, mechanistic identification or deployed-engine behavior. No packaging or licence-assignment blocker remains. The release owner controls public upload and final consumer-level integration.
