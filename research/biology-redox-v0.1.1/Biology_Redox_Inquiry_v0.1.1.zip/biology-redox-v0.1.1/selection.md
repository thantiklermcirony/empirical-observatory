# Selection and evidence audit

12 September 2026. Scope: an enzymatic redox subsystem in a well-mixed, fixed-volume cell compartment coupled to a perfused bath. The useful question is **whether return of the reduced-glutathione fraction supports re-exposure, and which additional measurement would test that inference**. All cell trajectories and fitted comparisons here are synthetic.

## Decision

Select GPx-mediated peroxide consumption, GR-mediated restoration of GSH, and a finite NADPH/NADP pool with a rate-limited regenerative input. This retains explicit chemical amounts, environmental transport and recovery time without claiming a whole-cell, retinal, mitochondrial or clinical calibration. Reductive restoration of the antioxidant pool is the recovery mechanism; GSSG is not declared an irreversible damage marker. There is no inferred viability, transcriptional adaptation or fitness endpoint.

The implementation uses SciPy `solve_ivp`, not a new integration engine. Its GPx rate-law *form* is the effective-parameter version of Eq. 1 in Aon et al. (2012); its GR form is their Eq. 2. Concentrations and stoichiometric extents are explicit. The source uses fixed/adjustable NADPH; the finite-cofactor dynamics and bath are declared extensions. The constants are synthetic and are not transplanted between cell types. This is a reduced, reparameterized reference, **not reproduction of the authors' complete models or figures**. [Aon et al., primary study](https://doi.org/10.1085/jgp.201210772).

The 2:1 GSH/GSSG molecular stoichiometry is explicit in Reed et al.'s supplementary differential equations, page 9. Their full liver/blood model also includes synthesis, export and degradation; those processes are omitted only in the short-horizon closed-G reference. Their NADPH concentration is fixed at 50 µM. Their steady-state tables are model outputs, and their clinical comparisons are aggregate percentage changes; neither is a peroxide pulse/wait dataset. [Reed et al.](https://doi.org/10.1186/1742-4682-5-8).

## Candidate comparison

| Candidate | Actual inspection | Decision for this question |
|---|---|---|
| GPx/GR redox subsystem | Primary 2012 model equations/tables and full 2008 supplementary equations; finite physical pools and known reaction meanings | Selected as a **synthetic reference** with explicit reduction/extension |
| Retinal GSH dynamics, Dobreva et al. 2023 | Full article, supplementary PDF pages 5–6; 126 printed individual values in 22 strain/day/analyte columns extracted and checked | Genuine measurements; unsuitable for pulse recovery validation |
| Yeast HOG adaptive signalling | Local product review identifies a primary protocol/repository but leaves the actual raw-file, unit, provenance and independent-replication gate unverified | Not selected for this redox question; no HOG benchmark is claimed here |

The HOG source is the authors' [STAR Protocols model and stimulation repository](https://github.com/neuertlab/Jashnsaz_STARProtocols_2021). This run uses the local product review to identify the unresolved import gate and does not claim a new HOG-data inspection. A **different yeast mortality candidate, Duveau**, was stopped in the earlier campaign for insufficient independent holdout design. It must not be attributed to HOG. The earlier MAPK/PhysiCell tool proposals remain leads, not validated alternatives in this package.

## What the acquired retinal data contain

The author supplement's Table S2 was downloaded through the Europe PMC supplementary-file endpoint, visually inspected, and parsed by bounded PDF coordinates. `audit_retina_table.py` extracts `strain`, postnatal day, analyte, printed row index, nmol/mg protein, protein mg/ml, and printed mM. All 22 printed means and sample standard deviations reproduce to within 2e-8 mM. There are 126 individual printed values; **this is not a count of certified independent animals**. GSH and GSSG columns have different lengths and no identifiers that establish pairing. [Dobreva, Camacho & Miranda (2023), supplement](https://www.nature.com/articles/s41598-023-37938-9#Sec25).

The source describes dissection and homogenization of both retinas per euthanized mouse. Control days are PN11,13,15,17,28; rd1 also has PN12. The conversion on supplement page 5 is:

`mM = (nmol / mg protein) × (mg protein / ml homogenate) / 1000`.

That establishes a homogenate concentration. It does not by itself provide cytosolic volume, homogenization dilution, extraction recovery or compartment distribution. Several displayed source columns are rounded; the largest discrepancy recomputing a converted individual value from the displayed input columns is about 7.04e-5 mM. Preserve the printed converted values; do not silently “correct” them. The age series is destructive and cross-sectional. There are no pulse/wait histories, paired common-future challenges or NADPH observations. This rules out using the table to validate the reference's recovery timing. The article describes trying different time-point splits and reporting a best case, including a repeated calibration/validation point for controls; that is not adopted as an independent validation design here.

## Other evidence boundaries

The 2012 study reports Amplex-red peroxide emission from isolated heart mitochondria, in pmol/min/mg protein, and Fig. 2 summarizes two experiments with duplicates. Table 3 mixes emission summaries with fitted inhibitor-response parameters. It does not supply identified longitudinal NADPH/GSH samples for our pulse/wait question. Converting those emission units into intracellular mM/min needs protein-to-compartment-volume evidence. Model-side concentrations cannot supply that missing experimental conversion.

Printed GSH balance conventions differ across source models. The 2012 table and 2023 equations use a unit-coefficient GSH/GSSG interchange; our model explicitly counts molecular GSH and GSSG with coefficients 2 and 1, following Reed's source. Importing a source variable under an identical name would require resolving its equivalent-versus-molecule convention first. No conservation certificate from this implementation is attached to another paper's full model.

## Programme and implementation audit

The controlling integrated design treats boundedness, composition, environment, time, resource and observation as distinct premises. The current-02/03/05/06/07/09/10/11 manuscript openings and relevant redox, closure and viability passages were inspected against the corpus revision notes. Legacy hormesis has an explicit scope correction: benefit requires its adaptive-activation and burden assumptions. Legacy IDA is a typed research hypothesis; the present integral of depletion is an ordinary fixed-reference AUC, not an IDA superiority result. TAO remains a controller proposal; no controller is tested here.

Direct source inspection also found a precise failure in legacy-6754498's printed equations (pages 5–6): at `G=0, e_i=1`, the glutathione derivative is `V Gmax/(KM+Gmax) − beta Vtotal`, negative above the paper's threshold. The printed smooth ODE alone therefore does not make zero an invariant depleted attractor. A projection, substrate-limited drain, stopping rule or other boundary mechanism would change the claim. Mathematics independently confirmed this. Our reference consumes substrate at substrate-dependent rates and records this finding as an affected-premise counterexample, not blanket rejection of redox modelling.

The central code was read only. `RecoveryLab` renders a recovery-evidence record; `CellExplorer`/`CellRiskFlight` render transcriptomic transfer/risk comparisons. `HumanConditionLab` contains illustrative rhythms and cross-scale links. `lib/engine/temporal-state.ts` implements a different mortality/repair model; `tao.ts` implements a synthetic bounded reactor. The rational `integrated-inquiry` runner does not implement redox kinetics. These are integration targets, not a reason to rebuild their interfaces or pretend they already contain a calibrated cell solver. GitHub and live-site parity was not claimed or used; local files and their hashes identify the audit state.

## Data-readiness verdict

**No acquired dataset supports empirical validation of this pulse-recovery question.** The result is a reproducible reference, an actual-data audit and a prospective measurement specification. The next experiment must jointly record delivered peroxide, absolute GSH/GSSG, NADPH/NADP, the exposure/wait/challenge timeline, independent experimental units and a separately calibrated functional endpoint. A response-only curve or a fitted parameter table cannot substitute for those observations. See `experiment.md`.
