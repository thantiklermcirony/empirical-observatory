"""Reduced glutathione reference; synthetic parameters, not a calibrated cell.

Concentrations: mM; time: min. GPx flux counts peroxide/GSSG, NOT GSH.
SciPy integrates explicit mass balances, splitting every input discontinuity.
"""
from dataclasses import dataclass, asdict, replace
import numpy as np
from scipy.integrate import solve_ivp
import json


@dataclass(frozen=True)
class Parameters:
    g_total: float = 1.0
    n_total: float = 0.08
    phi_h: float = 0.15
    phi_g: float = 1.5
    v_gr: float = 0.12
    k_gssg: float = 0.04
    k_nadph: float = 0.015
    v_reg: float = 0.003
    k_nadp: float = 0.015
    permeability: float = 1.0
    volume_ratio: float = 0.02
    bath_exchange: float = 2.0
    bath_decay: float = 0.0
    other_clearance: float = 0.0
    # Optional open-pool source J_GSH. Separate scenario, not silent clipping.
    gsh_source: float = 0.0

def load_parameters(path):
    config=json.loads(path.read_text(encoding='utf8'))
    allowed={'evidence_status','time_unit','concentration_unit','parameters'}
    if set(config)!=allowed:
        raise ValueError('Unsupported/missing parameter fields; protocols belong in an explicit --scenario file')
    if config['time_unit']!='min' or config['concentration_unit']!='mM':
        raise ValueError('Only explicit min and mM are supported; convert before import')
    if set(config['parameters'])!=set(asdict(Parameters())):
        raise ValueError('Every supported physical parameter must be declared; unknown parameters are rejected')
    return Parameters(**config['parameters'])


# Explicit species plus reaction-extent ledgers.
NAMES = ('bath_h2o2', 'cell_h2o2', 'gsh', 'gssg', 'nadph', 'nadp',
         'extent_gpx', 'extent_gr', 'extent_reg', 'extent_membrane',
         'extent_bath_feed', 'extent_bath_loss', 'extent_other', 'extent_gsh_source')


def validate(p, schedule, times, initial):
    if not all(np.isfinite(v) and v >= 0 for v in asdict(p).values()):
        raise ValueError('All parameters must be finite and nonnegative')
    if min(p.phi_h, p.phi_g, p.k_gssg, p.k_nadph, p.k_nadp,
           p.g_total, p.n_total, p.volume_ratio) <= 0:
        raise ValueError('Pools, volume ratio and kinetic denominators must be positive')
    if len(times) < 2 or times[0] != 0 or np.any(np.diff(times) <= 0):
        raise ValueError('Times must start at zero and strictly increase')
    if not schedule or schedule[0][0] != 0:
        raise ValueError('Schedule needs an input value at time zero')
    starts = [x[0] for x in schedule]
    if any(not np.isfinite(x) or x < 0 for pair in schedule for x in pair):
        raise ValueError('Schedule values must be finite and nonnegative')
    if any(a >= b for a,b in zip(starts, starts[1:])) or starts[-1] > times[-1]:
        raise ValueError('Input change times must be ordered and within the horizon')
    if initial is not None:
        a = np.asarray(initial)
        if a.shape != (6,) or np.any(a < 0) or not np.all(np.isfinite(a)):
            raise ValueError('Initial species must be six nonnegative finite concentrations')
        if not np.isclose(a[2]+2*a[3],p.g_total) or not np.isclose(a[4]+a[5],p.n_total):
            raise ValueError('Initial species do not match declared total pools')


def fluxes(y, p, incoming, mode='finite'):
    e,h,g,o,n,q = y[:6]
    # No state clipping: positivity is a mechanism property checked numerically.
    den = p.phi_h*g+p.phi_g*h
    gpx = h*g/den if den != 0 else 0.0
    gr = p.v_gr*o*n/((p.k_gssg+o)*(p.k_nadph+n))
    reg = p.v_reg*q/(p.k_nadp+q) if mode == 'finite' else gr
    membrane = p.permeability*(e-h)
    feed = p.bath_exchange*(incoming-e)
    bathloss = p.bath_decay*e
    other = p.other_clearance*h
    return np.array([gpx,gr,reg,membrane,feed,bathloss,other,p.gsh_source])


def rhs(t,y,p,incoming,mode):
    j,r,s,m,f,l,c,gsource = fluxes(y,p,incoming,mode)
    return np.array([f-l-p.volume_ratio*m, m-j-c,
                     -2*j+2*r+gsource, j-r, -r+s, r-s,
                     j,r,s,m,f,l,c,gsource])


def simulate(p=Parameters(), schedule=((0,0),(5,.2),(10,0)),
             times=None, initial=None, mode='finite', method='LSODA',
             rtol=2e-8, atol=1e-10):
    if mode not in ('finite','clamped'):
        raise ValueError('Unsupported mechanism')
    times=np.asarray(np.linspace(0,120,481) if times is None else times,float)
    validate(p,schedule,times,initial)
    y=np.zeros(len(NAMES))
    y[:6] = [0,0,p.g_total,0,p.n_total,0] if initial is None else initial
    # Clamped comparator has an explicit compensating cofactor supply = GR flux.
    # Thus it uses a reservoir with no declared rate ceiling, not a free source
    # masquerading as finite metabolism; its supply ledger is retained.
    out=np.full((len(times),len(NAMES)),np.nan)
    out[0]=y
    ends=[s[0] for s in schedule[1:]]+[times[-1]]
    evaluations=0
    for (a,u), b in zip(schedule, ends):
        if b == a: continue
        sol=solve_ivp(rhs,(a,b),y,args=(p,u,mode),method=method,
                      rtol=rtol,atol=atol,dense_output=True)
        if not sol.success:raise RuntimeError(sol.message)
        ix=(times>a)&(times<=b)
        out[ix]=sol.sol(times[ix]).T
        y=sol.y[:,-1];evaluations+=sol.nfev
    if not np.all(np.isfinite(out)):raise RuntimeError('Unfilled or nonfinite trajectory')
    return {'time':times,'y':out,'nfev':evaluations,'mode':mode,
            'incoming':np.array([input_at(t,schedule) for t in times])}


def input_at(t,schedule):
    return next(v for a,v in reversed(schedule) if a<=t)


def observables(run):
    y=run['y'];g=y[:,2];o=y[:,3]
    return {'bath_h2o2_mM':y[:,0], 'gsh_mM':g,'gssg_mM':o,
            'reduced_glutathione_fraction':g/(g+2*o),
            'total_glutathione_mM_equivalents':g+2*o,
            'nadph_mM':y[:,4], 'nadp_mM':y[:,5]}


def diagnostics(run,p):
    y=run['y'];g0=y[0,2]+2*y[0,3];n0=y[0,4]+y[0,5]
    B=y[:,2]/2+y[:,4]
    # Per bath volume, E + Vcell/Vbath*H accounts for membrane exchange.
    env=y[:,0]+p.volume_ratio*y[:,1]
    envrhs=env[0]+y[:,10]-y[:,11]-p.volume_ratio*(y[:,6]+y[:,12])
    return {'min_species_mM':float(y[:,:6].min()),
            'g_balance_max_error_mM':float(np.max(np.abs(y[:,2]+2*y[:,3]-g0-y[:,13]))),
            'n_balance_max_error_mM':float(np.max(np.abs(y[:,4]+y[:,5]-n0))),
            'reducing_budget_max_error_mM':float(np.max(np.abs(B-B[0]-y[:,8]+y[:,6]-y[:,13]/2))),
            'environment_balance_max_error_mM':float(np.max(np.abs(env-envrhs))),
            'total_gpx_clearance_mM':float(y[-1,6]),
            'total_regeneration_mM':float(y[-1,8]),
            'initial_reducing_budget_mM':float(B[0]),
            'final_reducing_budget_mM':float(B[-1]),
            'cell_h2o2_auc_mM_min':float(np.trapezoid(y[:,1],run['time']))}
