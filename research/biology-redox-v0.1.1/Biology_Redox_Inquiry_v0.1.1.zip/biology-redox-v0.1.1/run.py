"""Reproduce synthetic comparisons and protocol predictions; no biological fits."""
import argparse, csv, hashlib, json, platform, time
from pathlib import Path
from dataclasses import asdict, replace
import numpy as np
import scipy
from scipy.optimize import least_squares
from model import Parameters, NAMES, simulate, diagnostics, load_parameters

ROOT=Path(__file__).resolve().parent
SEED=20260912

def dump(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n',encoding='utf8')

def csvwrite(path,fields,rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

def save_trace(path,r):
    rows=[dict(time_min=float(t),incoming_h2o2_mM=float(u),**dict(zip(NAMES,map(float,y))))
          for t,u,y in zip(r['time'],r['incoming'],r['y'])]
    csvwrite(path,['time_min','incoming_h2o2_mM',*NAMES],rows)

def challenge(p,initial=None,amplitude=.15,mode='finite'):
    t=np.linspace(0,20,201)
    r=simulate(p,((0,amplitude),(5,0)),t,initial=initial,mode=mode)
    return r,diagnostics(r,p)['cell_h2o2_auc_mM_min']

def numerical_restart(p,state):
    """Remove only solver roundoff when restarting; never repair a physical input."""
    s=state.copy();s[:2]=np.maximum(s[:2],0)
    s[2]=np.clip(s[2],0,p.g_total);s[3]=(p.g_total-s[2])/2
    s[4]=np.clip(s[4],0,p.n_total);s[5]=p.n_total-s[4]
    if np.max(np.abs(s-state))>1e-8:raise ValueError('Restart correction exceeds numerical tolerance')
    return s

def predictions(out,p):
    t=np.linspace(0,160,641)
    schedule=((0,0),(5,.03),(10,0))
    r=simulate(p,schedule,t);c=simulate(p,schedule,t,mode='clamped')
    save_trace(out/'recovery_finite.csv',r);save_trace(out/'recovery_clamped.csv',c)
    fresh,af=challenge(p)
    rows=[]
    for wait in [0,2,5,10,20,30,40,50,60,80,120,150]:
        state=r['y'][np.where(np.isclose(t,10+wait))[0][0],:6]
        rr,a=challenge(p,numerical_restart(p,state))
        row={'wait_after_washout_min':wait,'gsh_fraction':float(state[2]/p.g_total),
             'nadph_fraction':float(state[4]/p.n_total),
             'reducing_budget_mM':float(state[2]/2+state[4]),
             'repeat_challenge_cell_h2o2_auc_mM_min':a,
             'fresh_challenge_cell_h2o2_auc_mM_min':af,
             'auc_ratio_to_fresh':a/af,
             'signal_recovered_criterion':bool(state[2]/p.g_total>=.995),
             'repeat_capacity_recovered_criterion':bool(a/af<=1.10)}
        rows.append(row)
        if wait==20:save_trace(out/'rechallenge_at_30min.csv',rr)
    save_trace(out/'fresh_challenge.csv',fresh)
    csvwrite(out/'wait_ladder.csv',list(rows[0]),rows)
    # Same observed fraction at two different absolute pool scales.
    matched=[]
    for scale in [.3,1.0,2.0]:
        pp=replace(p,g_total=scale)
        rr,auc=challenge(pp,initial=[0,0,.99*scale,.005*scale,.04,.04])
        matched.append({'g_total_mM_equivalents':scale,'observed_reduced_fraction':.99,
                        'initial_budget_mM':.495*scale+.04,'challenge_auc_mM_min':auc})
    # Necessary budget exclusion. Clearing >=.8mM in 20min via GPx alone is impossible
    # if B0=.58 and Vreg=.003 => ceiling .64. Other clearance changes total-removal claims.
    target=.8;horizon=20;bound=p.g_total/2+p.n_total+p.v_reg*horizon
    finite=simulate(p,((0,.2),(20,0)),np.linspace(0,40,401))
    clamped=simulate(p,((0,.2),(20,0)),np.linspace(0,40,401),mode='clamped')
    openpool=simulate(replace(p,gsh_source=.03),((0,.2),(20,0)),np.linspace(0,40,401))
    noreg=simulate(replace(p,v_reg=0),((0,0),(5,.03),(10,0)),t)
    alt=simulate(replace(p,other_clearance=3),((0,.2),(20,0)),np.linspace(0,40,401))
    for name,x in [('sustained_finite',finite),('sustained_clamped',clamped),
                   ('open_gsh_source',openpool),('no_regeneration',noreg),('alternative_clearance',alt)]:
        save_trace(out/(name+'.csv'),x)
    summary={
      'result_kind':'model_prediction','evidence':'synthetic_not_empirical',
      'question':'When can an apparently recovered glutathione readout license repeat challenge?',
      'readout_at_30min':next(x for x in rows if x['wait_after_washout_min']==20),
      'first_tested_wait_signal_recovered_min':next((x['wait_after_washout_min'] for x in rows if x['signal_recovered_criterion']),None),
      'first_tested_wait_capacity_recovered_min':next((x['wait_after_washout_min'] for x in rows if x['repeat_capacity_recovered_criterion']),None),
      'criteria_scope':'Synthetic .995 fraction and 1.10 relative AUC are declared demonstration margins, not validated biological safety cutoffs. First tested wait is not an optimized continuous minimum.',
      'equal_ratio_different_pool':matched,
      'budget_exclusion':{'required_gpx_clearance_mM':target,'horizon_min':horizon,
           'upper_bound_mM':bound,'excluded_under_premises':bool(target>bound),
           'scope':'Necessary capacity bound, not a survival theorem or guaranteed clearance. Closed G pool, finite initial cofactor, regeneration rate ceiling, GPx-specific target.'},
      'scenario_diagnostics':{name:diagnostics(x,pp) for name,x,pp in
            [('recovery',r,p),('sustained_finite',finite,p),('sustained_clamped',clamped,p),
             ('open_gsh_source',openpool,replace(p,gsh_source=.03)),
             ('no_regeneration',noreg,replace(p,v_reg=0)),
             ('alternative_clearance',alt,replace(p,other_clearance=3))]},
      'hormesis':'No beneficial rise above fresh reduced-pool baseline is forced. This reference has no induced synthesis, transcription, fitness, damage-to-fate or longevity mechanism.',
    }
    dump(out/'summary.json',summary)
    return summary

# Fixed before fitting. Two whole training schedules and two unseen schedules;
# three independent synthetic measurement series per schedule; no row random split.
TRAIN={'mild':[(0,0),(5,.01),(10,0)],'moderate':[(0,0),(5,.03),(10,0)]}
TEST={'repeated':[(0,0),(5,.03),(10,0),(30,.15),(35,0)],
      'long_low':[(0,0),(5,.02),(25,0)]}
SAMPLE=np.array([0,5,6,8,10,12,15,20,25,30,32,35,40,50,60.])
SIGMA=np.array([.001,.01]) # bath peroxide and GSH mM; stipulated known SD.

def measure(r):return r['y'][:,[0,2]]

def fit_model(data,mode,p,seed=SEED):
    names=['phi_h','v_gr','v_reg'] if mode=='finite' else ['phi_h','v_gr','k_gssg']
    lo=np.log([.03,.01,.0003] if mode=='finite' else [.03,.01,.002])
    hi=np.log([1,.6,.03] if mode=='finite' else [1,.6,.4])
    starts=np.random.default_rng(seed).uniform(.15,.85,(4,3))
    calls=0
    def residual(z):
        nonlocal calls
        calls+=1
        pp=replace(p,**dict(zip(names,np.exp(z))))
        return np.concatenate([((measure(simulate(pp,sched,SAMPLE,mode=mode,rtol=1e-7,atol=1e-9))[None,:,:]-data[name])/SIGMA).ravel()
                               for name,sched in TRAIN.items()])
    fits=[]
    for s in starts:
        f=least_squares(residual,lo+s*(hi-lo),bounds=(lo,hi),max_nfev=100,
                        ftol=1e-7,xtol=1e-7,gtol=1e-7,diff_step=1e-4)
        fits.append(f)
    f=min(fits,key=lambda x:np.sum(x.fun*x.fun));sv=np.linalg.svd(f.jac,compute_uv=False)
    pp=replace(p,**dict(zip(names,np.exp(f.x))))
    covariance=np.linalg.pinv(f.jac.T@f.jac)
    report={'fitted_parameters':dict(zip(names,map(float,np.exp(f.x)))),
       'train_chi_square':float(np.sum(f.fun*f.fun)),'fitted_parameter_count':3,
       'residual_count':len(f.fun),'starts':4,'max_nfev_per_start':100,
       'actual_residual_calls':calls,'optimizer_success':bool(f.success),
       'start_chi_squares':[float(np.sum(x.fun*x.fun)) for x in fits],
       'jacobian_singular_values':sv.tolist(),
       'jacobian_condition_number':float(sv[0]/sv[-1]),
       'log_parameter_se_local':np.sqrt(np.diag(covariance)).tolist(),
       'local_uncertainty_scope':'Conditional Gaussian linearization with stipulated known noise; not structural identifiability or biological confidence.',
       'active_bounds':f.active_mask.tolist(),
       'interior_linearization_valid':bool(not np.any(f.active_mask)),
       'uncertainty_warning':'If active_bounds is nonzero, symmetric local standard errors are not valid confidence intervals; no parameter interval or model evidence is asserted.'}
    return pp,report

def benchmark(out,p):
    allresults={}
    obsrows=[];predrows=[]
    for truth in ['finite','clamped']:
        rng=np.random.default_rng(SEED+(truth=='clamped'))
        observed={}
        for split,schedules in [('train',TRAIN),('validation',TEST)]:
            for name,sched in schedules.items():
                clean=measure(simulate(p,sched,SAMPLE,mode=truth))
                observed[name]=clean[None,:,:]+rng.normal(size=(3,*clean.shape))*SIGMA
                for rep in range(3):
                    for i,t in enumerate(SAMPLE):
                        obsrows.append(dict(truth_mechanism=truth,split=split,schedule=name,
                         synthetic_experiment_id=f'{truth}-{name}-{rep+1}',time_min=float(t),
                         bath_h2o2_mM=float(observed[name][rep,i,0]),gsh_mM=float(observed[name][rep,i,1])))
        truthreports={}
        for fitted in ['finite','clamped']:
            pp,rep=fit_model(observed,fitted,p)
            rep['heldout']={}
            for name,sched in TEST.items():
                pred=measure(simulate(pp,sched,SAMPLE,mode=fitted))
                resid=(pred[None,:,:]-observed[name])/SIGMA
                rep['heldout'][name]={'chi_square':float(np.sum(resid**2)),
                   'mean_squared_standardized_error':float(np.mean(resid**2)),
                   'gsh_rmse_mM':float(np.sqrt(np.mean((pred[None,:,1]-observed[name][:,:,1])**2))),
                   'bath_h2o2_rmse_mM':float(np.sqrt(np.mean((pred[None,:,0]-observed[name][:,:,0])**2))),
                   'units':'standardized error dimensionless; RMSE mM'}
                for i,t in enumerate(SAMPLE):predrows.append(dict(truth_mechanism=truth,fitted_mechanism=fitted,schedule=name,time_min=float(t),bath_h2o2_mM=float(pred[i,0]),gsh_mM=float(pred[i,1])))
            truthreports[fitted]=rep
        allresults[truth]=truthreports
    csvwrite(out/'synthetic_measurements.csv',list(obsrows[0]),obsrows)
    csvwrite(out/'heldout_predictions.csv',list(predrows[0]),predrows)
    dump(out/'benchmark.json',{'seed':SEED,'result_kind':'model_prediction',
       'evidence':'Two synthetic truth mechanisms. Reciprocal stress test, not empirical model selection or evidence that an Observatory coordinate outperforms ordinary kinetics.',
       'observation_noise':{'family':'independent additive Gaussian','sd_mM':SIGMA.tolist(),'channels':['bath_h2o2','gsh'],'known_noise':True,'biological_variability':False,'censoring':False},
       'split_unit':'whole intervention schedules; no neighbouring-time-point split',
       'fairness':'Same 3 fitted parameters, 4 starts, optimizer tolerances, residual evaluations cap, measurements and noise. Mechanism-specific third parameter differs; equal count alone does not equalize model flexibility. All other constants stipulated. Finite uses explicit cofactor dynamics; clamped uses compensated cofactor supply.',
       'results':allresults})
    return allresults

def main():
    a=argparse.ArgumentParser();a.add_argument('--out',type=Path,default=ROOT/'results')
    a.add_argument('--scenario',type=Path,help='Execute this explicit protocol instead of the fixed reference campaign')
    a.add_argument('--parameters',type=Path,default=ROOT/'parameters.json')
    a.add_argument('--skip-fit',action='store_true');args=a.parse_args()
    if args.scenario:
        from scenario import execute
        print(json.dumps(execute(args.parameters,args.scenario,args.out)['diagnostics']))
        return
    if args.parameters.resolve()!=(ROOT/'parameters.json').resolve():
        raise ValueError('Custom parameter paths require --scenario; fixed campaign reads package parameters.json')
    args.out.mkdir(parents=True,exist_ok=True)
    p=load_parameters(ROOT/'parameters.json');start=time.perf_counter()
    s=predictions(args.out,p)
    print('Recovery example:',json.dumps(s['readout_at_30min']),flush=True)
    if not args.skip_fit:
        b=benchmark(args.out,p)
        print('Reciprocal comparison complete',flush=True)
    dump(args.out/'execution.json',{'python':platform.python_version(),'numpy':np.__version__,
       'scipy':scipy.__version__,'solver':'solve_ivp LSODA; input breakpoints split exactly',
       'default_rtol':2e-8,'default_atol_mM':1e-10,'seed':SEED,
       'protocols':{'conditioning':{'schedule':[[0,0],[5,.03],[10,0]],'horizon_min':160,'grid_interval_min':.25},
         'challenge':{'schedule':[[0,.15],[5,0]],'horizon_min':20,'grid_interval_min':.1,
            'initial_state':'Fresh default or named endpoint of conditioning; numerical restart <=1e-8mM'},
         'wait_ladder_after_washout_min':[0,2,5,10,20,30,40,50,60,80,120,150],
         'training':TRAIN,'validation':TEST,'sample_times_min':SAMPLE.tolist(),
         'synthetic_seed':SEED,'reference_narrative':'Fixed reference campaign, explicitly implemented in run.py; use --scenario for arbitrary supported protocols'},
       'wall_time_seconds':time.perf_counter()-start,'parameters':asdict(p),
       'input_hashes':{f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in ['model.py','run.py','parameters.json']}})

if __name__=='__main__':main()
