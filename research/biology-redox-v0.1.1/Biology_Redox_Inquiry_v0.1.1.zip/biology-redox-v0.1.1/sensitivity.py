"""Explicit parameter-scenario range and one extra measurement; not confidence bands."""
import itertools,json
from pathlib import Path
from dataclasses import replace
import numpy as np
from model import Parameters,simulate
from run import challenge,numerical_restart,csvwrite,dump

ROOT=Path(__file__).resolve().parent

def main():
    rows=[];base=Parameters(**json.loads((ROOT/'parameters.json').read_text())['parameters']);ts=np.arange(0,161,dtype=float)
    for g,n,regen in itertools.product([.5,1.,2.],[.04,.08,.16],[.0015,.003,.006]):
        p=replace(base,g_total=g,n_total=n,v_reg=regen)
        r=simulate(p,((0,0),(5,.03),(10,0)),ts)
        state=numerical_restart(p,r['y'][30,:6]);rr,after=challenge(p,state);fresh,af=challenge(p)
        rows.append({'g_total_mM':g,'n_total_mM':n,'v_reg_mM_per_min':regen,
          'gsh_fraction_at_30min':state[2]/g,'nadph_fraction_at_30min':state[4]/n,
          'second_challenge_auc_ratio':after/af,'meets_signal_margin':bool(state[2]/g>=.995),
          'meets_repeat_margin':bool(after/af<=1.10)})
    csvwrite(ROOT/'results'/'parameter_grid.csv',list(rows[0]),rows)
    normal=simulate(base,((0,0),(5,.03),(10,0)),ts)
    changed=normal['y'][30,:6]
    gdiff=base.g_total-changed[2];ndiff=base.n_total-changed[4]
    # Compare two independent calibrated measurements, each with stipulated SD.
    report={'design_kind':'authored_single_time_measurement_contrast',
      'time_after_initial_start_min':30,'extra_measurement':'NADPH concentration on a matched destructive aliquot',
      'expected_difference_mM':{'gsh':float(gdiff),'nadph':float(ndiff)},
      'stipulated_per_sample_sd_mM':{'gsh':.01,'nadph':.005},
      'expected_difference_over_independent_difference_sd':{'gsh':float(gdiff/(np.sqrt(2)*.01)),'nadph':float(ndiff/(np.sqrt(2)*.005))},
      'scope':'Known synthetic means and assumed assay SD. Not a power calculation, optimized experimental design, established assay precision, or biological result.',
      'grid':{'count':len(rows),'design':'3x3x3 Cartesian nuisance scenarios, no probability weights',
        'second_challenge_auc_ratio_min':min(x['second_challenge_auc_ratio'] for x in rows),
        'second_challenge_auc_ratio_max':max(x['second_challenge_auc_ratio'] for x in rows),
        'signal_recovered_but_repeat_not_recovered_count':sum(x['meets_signal_margin'] and not x['meets_repeat_margin'] for x in rows),
        'both_recovered_count':sum(x['meets_signal_margin'] and x['meets_repeat_margin'] for x in rows),
        'neither_recovered_count':sum(not x['meets_signal_margin'] and not x['meets_repeat_margin'] for x in rows),
        'repeat_margin_met_without_signal_margin_count':sum(not x['meets_signal_margin'] and x['meets_repeat_margin'] for x in rows),
        'meaning':'Sampled parameter range, not confidence or prevalence. A fixed 30min gap is not universally discriminating.'}}
    dump(ROOT/'results'/'measurement_design.json',report)
    print(json.dumps(report['grid']))

if __name__=='__main__':main()
