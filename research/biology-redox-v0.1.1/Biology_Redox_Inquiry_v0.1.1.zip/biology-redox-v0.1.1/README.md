# Redox recovery inquiry — v0.1.1, portable distribution 1

This is a distinct portable derivative of the independently accepted corrected scientific package. See `PUBLICATION_HANDOFF.md`, `PORTABLE_CHANGES.json` and `NOTICES.md` for packaging changes, checks and release terms. Scientific code, constants and supplied numerical results are retained; only the exporter's private task identifier is removed from code.

**Built and tested:** a coupled bath/cell GPx–GR reference with finite glutathione and NADPH pools, conventional comparisons, actual-data audit and a next-experiment plan. **The biological predictions are synthetic; no empirical recovery claim is established.**

The useful finding is conditional: returning to the same reduced-glutathione fraction can occur before recovery of the ability to handle another peroxide challenge. The same conclusion follows from ordinary kinetic equations; this is established chemistry and modelling joined into an inspectable inquiry, not a newly discovered law.

## Results

At minute 30 after the stipulated conditioning pulse, the GSH fraction is **99.978%**, but NADPH is **12.692%** of its initial pool. An identical five-minute challenge then produces **32.95% greater intracellular H2O2 AUC** than in a fresh preparation. The declared fraction margin is first met at a tested washout gap of 20 min; the declared repeat-challenge margin at 40 min. These are synthetic choices, not validated biological or safety cutoffs.

The exact reducing budget is `B=GSH/2+NADPH`, with `B'=regeneration−GPx clearance` for the closed pool. With B0=0.58 mM and regeneration at most 0.003 mM/min, **0.8 mM clearance through GPx within 20 min is excluded by a 0.64 mM ceiling**. An added GSH source changes that ceiling to 0.94 mM; this removes the exclusion without proving the target feasible. A NADPH clamp removes the stipulated finite-rate ceiling. Both altered cases are numerically recomputed.

The reciprocal synthetic comparison used three fitted parameters per family, four starts, identical concentration observations/noise and whole held-out schedules. Its repeated-challenge mean squared standardized errors were:

| Synthetic truth | Finite-cofactor fit | Clamped-cofactor fit |
|---|---:|---:|
| Finite cofactor | 1.060 | 379.198 |
| Clamped cofactor | 399.482 | 1.155 |

For clamped truth, the finite model fit training data slightly better and still failed the held-out challenge. This is a concrete warning against mechanism inference from fit error. The wrong-family bounds and conditional local uncertainty are reported; these values are neither clinical performance nor proof of a statistically identified biological mechanism.

A 27-case parameter grid contains seven minute-30 examples with a recovered fraction but unrecovered repeat response, eleven with both recovered, six with neither recovered and three meeting only the repeat-response margin. These counts describe assumed scenarios, not biological prevalence. A fixed gap does not work universally.

The most practical output is `results/continuation_table.csv`: **what the observer can exclude** for the same prepared state. With q and total G known but N only bounded by its total pool, a 0.6 mM GPx target over 20 min is not excluded (ceiling about 0.63989 mM). Supplying the simulated absolute NADPH value tightens the ceiling to about 0.57004 mM and excludes that target. This is exact conditional accounting, not proof that a non-excluded target is feasible. Removing the regeneration bound makes the certificate unresolved while leaving moiety conservation available.

## Evidence and limitations

The 2023 retinal supplement yielded **126 printed values across 22 groups**; every printed mean and sample SD reproduced within 2e-8 mM. Its fields, units and rows are retained. They are destructive samples across postnatal ages, with no pulse/wait experiment, NADPH observation or identifiers supporting cross-analyte pairing. This is a successful table reproduction and a **failed recovery-data-readiness gate**, not an empirical test of this model. [Primary retinal study](https://doi.org/10.1038/s41598-023-37938-9).

The ordinary independent four-state kinetic transcription agrees with the six-species reference to about **6.9e-11 mM**. Algebra, dimensional consistency, positivity, two conserved pools, reducing budget, environment balance, three stiff solvers, a tighter solver, limiting cases and expected input failures are checked. The former legacy redox zero-boundary problem is reproduced as a source-specific counterexample.

There is no fitted named-cell calibration, damage-to-fate map, NRF2 induction model, quantum-to-cell flux calibration, TAO controller result or longevity claim. The next useful experiment is an absolute cofactor measurement and a calibrated repeat challenge, described in `experiment.md`.

## Reproduce

Tested with Python **3.12.14** on Windows. Run commands from this directory. Install into a virtual environment outside the deliverable, then:

```text
python -m pip install -r requirements.txt
python run.py
python validate.py
python sensitivity.py
python continuation.py
python plot_results.py
python assemble.py
python test_scenario.py
python validate_provenance.py
python accounting_validation.py
```

`run.py` takes about 17-31 seconds on this machine including both fitting experiments. Its default is a fixed reference campaign whose complete implemented protocols and seed are exported in `results/execution.json`. `--skip-fit` regenerates reference trajectories quickly; plotting the comparison still requires the supplied or regenerated fit files. `--out` redirects output, but downstream reference exporters consume this package's `results/` directory. `parameters.json` declares **physical parameters only**: unknown fields such as schedule/horizon/random_seed are rejected, not ignored. Model protocols use the separate executable interface below. After intentional edits, rerun dependent steps before issuing a new manifest/version. Never regenerate a hash manifest merely to pass an unexpected integrity failure.

To change a protocol, edit a copy of `examples/single_pulse.json`, whose schedule, horizon, sample interval, mode, seed and synthetic-noise fields all execute:

```text
python run.py --scenario examples/single_pulse.json --out results/custom_example
```

An optional `--parameters path/to/parameters.json` selects another complete physical configuration with `--scenario`. Results include the actual protocol, preparation, input hashes, continuous species/extents and generated observation rows. The scenario test verifies that changing dose changes dynamics and provenance, changing the seed changes generated noise while preserving dynamics, timing fields change sampling, and unknown/inert fields fail explicitly. Custom scenarios do not silently overwrite the fixed benchmark or claim a fitting result.

The supplied frozen bundle can be checked before any rerun:

```text
python verify_package.py --self-test
```

This verifies file hashes and five in-memory tamper cases. It does not prove scientific validity. Reruns can change timestamps, solver roundoff or plotting metadata and will no longer match the original frozen file manifest; compare scientific values/tolerances and issue a new version deliberately.

Optional offline repetition of the actual-data audit uses the included unchanged author supplement:

```text
python -m pip install -r requirements-research.txt
python audit_retina_table.py --pdf data/retina2023_supplement.pdf
```

The supplied PDF crop coordinates preserve printed rows; they do not invent animal IDs. No paper or measurement download is needed for the default reproduction. Source and dependency notices are in `NOTICES.md`.

## Package map

- `inquiry.json` and `cases/`: shared 14-field contract, per-result premises, values, scope and status.
- `model.py`, `run.py`, `scenario.py`, `validate.py`, `sensitivity.py`, `continuation.py`, `assemble.py`: executable mechanism, strict scenario interface, comparisons, checks, observer-conditioned budgets and recomputed contrasts.
- `results/`: numerical receipts, trajectories, synthetic observations, held-out predictions and measurement design.
- `data/`: audited printed values, audit receipt and licensed unchanged author supplements.
- `reference.png` / `reference.svg`: reproducible six-panel scientific figure.
- `selection.md`, `mechanism.md`, `experiment.md`: selection, derivation and next test.
- `coupling.md`, `visual_spec.md`: cell/environment/scale and quantum interface obligations, integration instructions.
- `sources.json`, `manifest.json`: portable source/version snapshot and this derivative's frozen file hashes. Non-bundled private citations remain unavailable to public readers; no private source is required to execute the included checks.

The central checkout, GitHub and live Site were not changed. The coordinator receives this isolated version for independent review and integration. Scientific ownership remains explicit: biology owns mechanism/assays, mathematics owns imported formal certificates, quantum owns spin models, and the coordinator owns shared engine/Site behaviour.
