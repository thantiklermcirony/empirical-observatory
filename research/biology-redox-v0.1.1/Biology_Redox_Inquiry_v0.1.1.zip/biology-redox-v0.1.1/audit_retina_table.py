"""Inspect published values, NOT a recovery dataset or calibrated cell pool.

Usage: python audit_retina_table.py --pdf path/to/41598_2023_37938_MOESM1_ESM.pdf
Optional research dependency pdfplumber (see requirements-research.txt).
"""
import argparse, csv, hashlib, json, re
from pathlib import Path
import numpy as np
import pdfplumber

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--pdf',type=Path,required=True)
    parser.add_argument('--out',type=Path,default=Path(__file__).resolve().parent/'data')
    a=parser.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    rows=[];summaries=[]
    # PDF coordinate rectangles are bounded to numeric entries, not inferred IDs.
    cols={11:(56,134),12:(144,221),13:(230,305),15:(311,395),17:(400,491),28:(498,584)}
    groups=[('control','GSH',235,285,[11,13,15,17,28]),('control','GSSG',299,330,[11,13,15,17,28]),
            ('rd1','GSH',345,419,[11,12,13,15,17,28]),('rd1','GSSG',433,459,[11,12,13,15,17,28])]
    with pdfplumber.open(a.pdf) as pdf:
        page=pdf.pages[5]
        for strain,analyte,y0,y1,days in groups:
            for day in days:
                x0,x1=cols[day]
                txt=page.crop((x0,y0,x1,y1)).extract_text(x_tolerance=.3,y_tolerance=.3)
                vals=[];mean=sd=None;conversion=[]
                for line in txt.splitlines():
                    if 'AVE' in line:mean=float(line.split()[0]);continue
                    if 'SD' in line:sd=float(line.split()[0]);continue
                    cells=line.split()
                    if len(cells)!=3 or not all(re.fullmatch(r'[0-9.]+',x) for x in cells):
                        raise ValueError('Unexpected table row: '+line)
                    specific,protein,conc=map(float,cells);vals.append(conc)
                    conversion.append(abs(specific*protein/1000-conc))
                    rows.append({'strain':strain,'postnatal_day':day,'analyte':analyte,
                      'printed_row_index_within_column':len(vals),'specific_nmol_per_mg_protein':specific,
                      'protein_mg_per_ml':protein,'printed_homogenate_mM':conc,
                      'animal_id':'unavailable','paired_analyte_id':'unavailable','source_pdf_page':6})
                if mean is None or sd is None or len(vals)<2:raise ValueError('Missing values/statistics')
                me=abs(np.mean(vals)-mean);se=abs(np.std(vals,ddof=1)-sd)
                if max(me,se)>2e-8:raise ValueError('Printed mean/SD mismatch: '+repr((strain,analyte,day,me,se)))
                summaries.append({'strain':strain,'analyte':analyte,'postnatal_day':day,'printed_value_count':len(vals),
                    'recomputed_mean_mM':float(np.mean(vals)),'printed_mean_mM':mean,
                    'recomputed_sample_sd_mM':float(np.std(vals,ddof=1)),'printed_sd_mM':sd,
                    'max_conversion_difference_mM':max(conversion)})
    with (a.out/'retina_table_s2_unpaired.csv').open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    report={'source_doi':'10.1038/s41598-023-37938-9','source_pdf_sha256':hashlib.sha256(a.pdf.read_bytes()).hexdigest(),
      'table':'S2','pdf_page':6,'row_count':len(rows),'groups':summaries,
      'admitted_use':'Table reproduction and data-readiness audit only',
      'recovery_validation':'not_supported','reason':'Cross-sectional destructive retinal homogenates across developmental ages; no pulse/wait input, matched challenge, NADPH observation or sample IDs. Rows cannot be assumed paired between analytes; counts are printed values, not certified independent animal counts.',
      'concentration_warning':'Printed mM is nmol/mg times measured homogenate protein mg/ml divided by1000; intracellular volume/dilution recovery is not established by this conversion.',
      'license':'Article/supplement CC BY 4.0 as declared in article; attribute Dobreva, Camacho and Miranda (2023).'}
    (a.out/'retina_audit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
    print(json.dumps({'rows':len(rows),'groups':len(summaries),'means_and_SD_reproduced':True,
                      'max_conversion_difference_mM':max(x['max_conversion_difference_mM'] for x in summaries)}))

if __name__=='__main__':main()
