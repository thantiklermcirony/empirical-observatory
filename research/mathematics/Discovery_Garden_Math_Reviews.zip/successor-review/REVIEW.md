# Discovery Garden 0.2.1 — targeted successor review

The previously reported E04 model-withdrawal error is corrected in the pinned successor. Eight executed cases check source/model withdrawal, separate accounting and supply withdrawal, calibration withdrawal, the off-grid continuous interval, and E01/E03 model-withdrawal regressions.

Removing E04's source or model now suspends the observation, removes active continuous support and the GPx ceiling, withholds numerical candidate predictions and design scores, and supplies no protocol recommendation. Removing only accounting or supply preserves the independently stipulated abstract concentration/readout geometry while withholding the biological ceiling. Calibration withdrawal suspends observation use and certified design. The off-grid interval remains [0.0309, 0.0311] despite containing no rendered marker.

This closes the specific finding in the preserved earlier review. It does not independently accept the complete Discovery Garden application, the projection consumer, event lineage, source-currentness, browser/export behavior or any empirical claim. The five selected pure functions were executed from hash-pinned successor bytes; source files were not edited. See receipt.json and probes.json for exact identities and results.
