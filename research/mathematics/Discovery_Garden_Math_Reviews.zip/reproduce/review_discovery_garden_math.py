from pathlib import Path
from fractions import Fraction as F
import ast,hashlib,json,random

ROOT=Path(__file__).resolve().parent.parent
source=Path('C:/Users/madma/Documents/Codex/2026-09-12/files-pasted-by-the-user-agent/work/living-encyclopedia/discovery-garden-review-v0.2')
out=ROOT/'outputs/discovery-garden-math-review';out.mkdir(exist_ok=True)
payload=(source/'garden.py').read_bytes();data=(source/'data/responses.json').read_bytes()
pins={'garden.py':hashlib.sha256(payload).hexdigest(),'data/responses.json':hashlib.sha256(data).hexdigest()}
assert pins['garden.py']=='a2512693aa2793439ac14a541539aa07ad05ca157c77016d07df677373f48e8a'
tree=ast.parse(payload);selected={'overlap_max','enabled','availability','finite_state','interval_state'}
scope={'F':F};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in selected],type_ignores=[]),'pinned-garden-functions','exec'),scope)
labs={x['id']:x for x in json.loads(data)['labs']}
rng=random.Random(341901)
def sweep(intervals):
    counts={}
    for a,b in intervals:
        counts.setdefault(a,[0,0])[0]+=1;counts.setdefault(b,[0,0])[1]+=1
    live=best=0
    for x,(starts,ends) in sorted(counts.items()):
        live+=starts;best=max(best,live);live-=ends
    return best
for i in range(300):
    intervals=[]
    for j in range(rng.randrange(1,20)):
        a=F(rng.randrange(-20,21),10);b=a+F(rng.randrange(0,15),10);intervals.append((a,b))
    assert scope['overlap_max'](intervals)==sweep(intervals)
assert scope['overlap_max']([(F(0),F(1)),(F(1),F(2)),(F(2),F(3))])==2
assert scope['overlap_max']([(F(0),F(1)),(F(1),F(1)),(F(1),F(2))])==3
finite=[]
for name in ['E01','E03']:
    normal=scope['finite_state'](labs[name],[],{},F(1))
    missing=scope['finite_state'](labs[name],[],{name:{'model':False}},F(1))
    assert all(s['certified'] for s in normal['scores'])
    assert all(not s['certified'] and s['worst_remaining'] is None for s in missing['scores'])
    assert missing['recommended_protocol'] is None
    finite.append({'entry':name,'normal':normal,'model_withdrawn':missing})
baseline=scope['interval_state'](labs['E04'],[],{},F(1))
withdrawn=scope['interval_state'](labs['E04'],[],{'E04':{'model':False}},F(1))
assert withdrawn['status']=='unresolved' and withdrawn['ceiling_exact'] is None
assert withdrawn['recommended_protocol']=='N'
assert any(x['certified'] and x['worst_remaining']=='1/250' for x in withdrawn['scores'])
offgrid=scope['interval_state'](labs['E04'],[{'protocol':'N','value':'31/1000','error':'1/10000','id':'offgrid'}],{},F(1))
assert offgrid['continuous_interval']==['309/10000','311/10000'] and not offgrid['compatible_ids']
assert offgrid['status']=='continuous_family'
assert hashlib.sha256((source/'garden.py').read_bytes()).hexdigest()==pins['garden.py']
receipt={'decision':'geometric_arithmetic_passes_with_E04_model_gate_correction_required','source_hashes':pins,
         'independent_sweep_cases':300,'endpoint_and_chain_cases':2,'offgrid_continuum_preserved':True,
         'scope':'Selected five pure functions from pinned source, not full consumer/lineage/source/PNG acceptance'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
(out/'E04-model-withdrawal.json').write_text(json.dumps({'baseline':baseline,'model_withdrawn':withdrawn,'offgrid':offgrid},indent=2)+'\n',encoding='utf-8')
(out/'finite-probes.json').write_text(json.dumps(finite,indent=2)+'\n',encoding='utf-8')
(out/'REVIEW.md').write_text('''# Discovery Garden0.2 — bounded mathematics review

The requested finite overlap and one-dimensional preimage calculations are correct in their declared scope. One E04 model-dependency correction is required before this review can clear the scientific design projection.

For a finite set of closed intervals, the maximum simultaneous overlap is attained at an endpoint: move any interior maximizer to the largest left endpoint among the intervals containing it. Therefore the endpoint implementation is complete. The review compared it with an independent grouped start/end sweep on300 rational cases, plus a chain whose maximum is2 rather than3 and a three-way closed endpoint intersection. Both E01 and E03 correctly withhold finite design scores and recommendations when their model gate is withdrawn. E03's additional numeric allowance is correctly included in both observation compatibility and candidate prediction intervals; this review does not independently establish the upstream numerical error allowance.

For direct observation of N in a current closed interval of width W, deterministic absolute error e leaves at most min(W,2e). A centered feasible observation attains that maximum. A constant readout leaves W. These scores describe the continuous family, not the number of rendered markers. The off-grid N=0.031±0.0001 example correctly retains [0.0309,0.0311] with zero plotted candidate markers.

The remaining issue is `interval_state`: withdrawing E04's model sets status unresolved and suppresses the GPx ceiling, but still returns certified design scores, N as the recommended protocol, and numeric candidate predictions based on that model. The reproduced model-withdrawn state returns a certified N width1/250mM. The finite-state paths already treat the same model withdrawal as unavailable. `source` and `calibration` alone are used for E04 design certification; the E04 model gate is absent from that condition.

Please either withhold those model-dependent interval/prediction/design values and the proposal on model withdrawal, or explicitly distinguish a separately stipulated abstract support/readout model that remains admitted and whose numeric score is labelled only in that mathematical scope. The current output does neither. Do not automatically add accounting/supply to every abstract interval calculation: those can have different dependencies. The required change is to represent the actual model dependency, not to suppress unrelated results globally.

This review used the five selected pure function definitions from the pinned garden.py bytes and pinned response table. No encyclopedia source was edited. The exact failing state is preserved in E04-model-withdrawal.json. Full event lineage, source-currentness, browser, export and consumer acceptance remain outside scope. Preserve the reviewed freeze and deliver a corrected successor or a scoped patch with regressions.
''',encoding='utf-8')
print(json.dumps(receipt,indent=2))
