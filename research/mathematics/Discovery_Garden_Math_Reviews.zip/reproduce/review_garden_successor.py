from pathlib import Path
from fractions import Fraction as F
import ast, hashlib, json
ROOT=Path(__file__).resolve().parents[1]
SOURCE=Path('C:/Users/madma/Documents/Codex/2026-09-12/files-pasted-by-the-user-agent/outputs/living-encyclopedia/discovery-garden-v0.2.1')
OUT=ROOT/'outputs/discovery-garden-successor-review'
OUT.mkdir(exist_ok=False)
code=(SOURCE/'garden.py').read_bytes(); data=(SOURCE/'data/responses.json').read_bytes()
pins={'garden.py':hashlib.sha256(code).hexdigest(),'data/responses.json':hashlib.sha256(data).hexdigest()}
assert pins=={'garden.py':'692640e03ffdd68f8637e4f69a4cb9e872f9a6627fddddc8f0cbc4574bbd850a','data/responses.json':'06f7792a255ebeab1eb4848e28105682b9632816a5063406ba2d49111401f6ea'}
names={'overlap_max','enabled','availability','finite_state','interval_state'}
scope={'F':F}
exec(compile(ast.Module(body=[n for n in ast.parse(code).body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[]),'pinned-functions','exec'),scope)
labs={x['id']:x for x in json.loads(data)['labs']}
event={'protocol':'N','value':'31/1000','error':'1/10000','id':'offgrid'}
results={}
for gate in ['model','source','accounting','supply','calibration']:
    s=scope['interval_state'](labs['E04'],[event],{'E04':{gate:False}},F(1))
    if gate in ['source','model']:
        assert s['continuous_interval'] is None and s['ceiling_exact'] is None
        assert s['recommended_protocol'] is None and not s['active_observations']
        assert s['suspended_observations']==['offgrid']
        assert all(not p['certified'] and p['worst_remaining'] is None for p in s['scores'])
        assert all(all(v is None for v in c['predictions'].values()) for c in s['candidates'])
    elif gate in ['accounting','supply']:
        assert s['ceiling_exact'] is None and s['continuous_interval']==['309/10000','311/10000']
        assert all(p['certified'] for p in s['scores'])
    else:
        assert not s['active_observations'] and s['suspended_observations']==['offgrid']
        assert s['recommended_protocol'] is None and all(not p['certified'] for p in s['scores'])
    results[gate]=s
normal=scope['interval_state'](labs['E04'],[event],{},F(1))
assert normal['continuous_interval']==['309/10000','311/10000'] and not normal['compatible_ids']
results['normal_offgrid']=normal
for name in ['E01','E03']:
    s=scope['finite_state'](labs[name],[],{name:{'model':False}},F(1))
    assert s['recommended_protocol'] is None and all(not p['certified'] for p in s['scores'])
    results[name+'-model-withdrawn']=s
assert hashlib.sha256((SOURCE/'garden.py').read_bytes()).hexdigest()==pins['garden.py']
receipt={'decision':'targeted_E04_model_withdrawal_correction_passes','source_hashes':pins,'executed_cases':len(results),'scope':'Pure-function projection regression; no full application, event, source-currentness, export or empirical acceptance'}
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
(OUT/'probes.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf8')
(OUT/'REVIEW.md').write_text('''# Discovery Garden 0.2.1 — targeted successor review

The previously reported E04 model-withdrawal error is corrected in the pinned successor. Eight executed cases check source/model withdrawal, separate accounting and supply withdrawal, calibration withdrawal, the off-grid continuous interval, and E01/E03 model-withdrawal regressions.

Removing E04's source or model now suspends the observation, removes active continuous support and the GPx ceiling, withholds numerical candidate predictions and design scores, and supplies no protocol recommendation. Removing only accounting or supply preserves the independently stipulated abstract concentration/readout geometry while withholding the biological ceiling. Calibration withdrawal suspends observation use and certified design. The off-grid interval remains [0.0309, 0.0311] despite containing no rendered marker.

This closes the specific finding in the preserved earlier review. It does not independently accept the complete Discovery Garden application, the projection consumer, event lineage, source-currentness, browser/export behavior or any empirical claim. The five selected pure functions were executed from hash-pinned successor bytes; source files were not edited. See receipt.json and probes.json for exact identities and results.
''',encoding='utf8')
print(json.dumps(receipt,indent=2))
