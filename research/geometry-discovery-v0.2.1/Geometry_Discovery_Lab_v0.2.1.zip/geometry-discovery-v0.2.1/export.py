"""Emit existing Observatory contract and a file-openable, standalone explorer."""
from pathlib import Path
import json
from campaign import ROOT, VERSION, digest, dump
from obligations import REQUIRED, contrasts

FIELDS='identity question system observer quantities operations constraints mechanism premises execution results contrast next_question provenance'.split()


def package(which):
    q=which=='quantum'
    artifact=f'results/{which}.json'
    raw=json.loads((ROOT/artifact).read_text())
    formal=['M-BALL','M-AFFINE','M-READOUT'] if q else ['M-COMPACT-BOX','M-LINEAR-TARGET','M-COVERING-BINS']
    extra=['Q-MATCHED-PREPARATION','Q-ACCESSIBLE-AXIS','Q-NOISE-MODEL'] if q else ['BIO-VOLUME','BIO-LEDGER','BIO-NONNEG','BIO-SUPPLY','BIO-UNIT-MAP','BIO-MATCHED-UNIT','BIO-ASSAY-CALIBRATION']
    units='dimensionless yield' if q else 'mM peroxide-equivalent budget ceiling'
    result_key='quantum_measurement_proposal' if q else 'biological_measurement_proposal'
    value={
      'identity':dict(id='GDL-'+which.upper(),version=VERSION,created_date='2026-09-12',producing_task_id='mathematics',parent=dict(id='theory-atlas',scientific_version='0.1.0',relation='additive branch upgrade; no frozen claims replaced')),
      'question':dict(original='Which remaining observation would be most useful to the programme?',target='Minimize the worst remaining width of a specified target under a declared measurement menu.',scope='Synthetic geometry fixtures',intended_user='Domain lead and Observatory inquiry UI'),
      'system':dict(entities='Qubit preparation ball' if q else 'Resource stock rectangle transported from GSH/GSSG/NADPH amounts',boundary='Fixed synthetic model family',environment='No fitted experimental data',coupling_interfaces='BRANCH_CONNECTIONS.json'),
      'observer':dict(map='M r=y, with M=(0,0,1)' if q else 'Exact q=G/(G+2O), followed by a declared absolute assay bin',noise='Existing readouts exact; finite quantum noise shown separately as a bounded-error example' if q else 'Finite covering assay bins, no additional noise',clock='No elapsed-time inference from readouts',memory='One new measurement after the existing observation',experimental_unit='Exchangeable fresh prepared ensembles' if q else 'Exchangeable fresh aliquots; no continuation of a destroyed specimen',physical_effects='Not modeled; real measurements require domain review'),
      'quantities':[dict(id='state',representation='real vector',meaning='r=(x,y,z), norm<=1' if q else '(T,N) in [.2,1] x [0,.08]',unit='1' if q else 'mM'),dict(id='target',representation='scalar interval',meaning='a+v dot r' if q else 'qT/2+N+.06; a ceiling on GPx extent, not the extent itself',unit=units),dict(id='cost',representation='positive scalar',meaning='Explicit abstract ranking weight',unit='abstract cost')],
      'operations':[dict(id='refine',input='Feasible fibre and candidate observation',output='Nonempty refined fibre or inconsistency',duration='Not represented',order='Old readout then one new readout',composition='Intersection only for compatible observations of the same state; no disturbance-free physical composition inferred')],
      'constraints':dict(domain='Unit Euclidean ball with affine equalities' if q else 'Closed rational bounded polytope',conservation='Not part of abstract ball geometry' if q else 'Biological interpretation requires fixed volume, nonnegative reserve, complete ledger and source ceiling',nonempty_required=True),
      'mechanism':dict(method='SVD null-space projection and analytic support formula' if q else 'Exact rational vertex enumeration and exhaustive covering-bin minimax',solver='geometry.py',reference='PROOFS.md',alternatives='Countermodels expose missing geometry or accounting premises; no domain propagation solver is duplicated.'),
      'premises':[dict(id=p,state='assumed',scope='Stipulated geometry fixture',source='PROOFS.md and campaign.py') for p in formal]+[dict(id=p,state='missing',scope='Physical interpretation/experimental use',source='Requires domain-owned calibration or reviewed model binding') for p in extra],
      'execution':dict(method_id='geometry-discovery-lab',version=VERSION,command='python -B run_all.py',input_hashes={n:digest(ROOT/n) for n in ['geometry.py','campaign.py','obligations.py','export.py']},arithmetic='float64; SVD tolerance 1e-10' if q else 'exact fractions',dependencies='Declared per result; central trusted admission not performed'),
      'results':[dict(id='GDL-'+which.upper()+'-WIDTHS',result_kind='formal_under_premises',status='established_in_scope',depends_on=formal,artifact=artifact,sha256=digest(ROOT/artifact),selector='cases[*].before and cases[*].ranked',value=dict(case_count=len(raw['cases'])),units=units,uncertainty='Numerical instance checks plus supplied analytic proof' if q else 'Exact continuous bounds within stipulated rational model'),dict(id='GDL-'+which.upper()+'-EXPERIMENT',result_kind='hypothesis_or_analogy',status='unresolved',depends_on=sorted(REQUIRED[result_key]),blocked_by=extra,artifact='results/questions.json',sha256=digest(ROOT/'results/questions.json'),units='proposed experiment',value=None)],
      'contrast':dict(artifact='results/obligations.json',counterexamples='results/countermodels.json',failure='Remove physical premises: abstract geometry survives while physical interpretation is unresolved. Remove geometric premises: associated theorem use is blocked.'),
      'next_question':dict(origin='automatically_generated_from_authored_model_and_candidate_menu',artifact='results/questions.json',selection='Within-domain guaranteed width reduction per declared cost; no cross-unit global score',open_obligation='Domain validation of access, noise, preparation and coupling'),
      'provenance':dict(model_origin='Authored synthetic fixture',data_origin='synthetic',empirical_receipt=None,citations=[dict(title='Convex Optimization lecture slides',url='https://web.stanford.edu/~boyd/cvxbook/bv_cvxslides.pdf',locations='Convex sets chapter',accessed='2026-09-12')],local_version=VERSION,github_status='not published',site_status='not deployed',licensing='Original code/docs MIT; no third-party source text bundled',observation_unit='Stipulated ensemble/aliquot; see observer')
    }
    assert set(value)==set(FIELDS)
    return value


def main():
    dump(ROOT/'results/obligations.json',contrasts())
    for which in ['quantum','biology']:dump(ROOT/f'packages/{which}.json',package(which))
    files=['summary','quantum','biology','questions','countermodels','obligations']
    data={k:json.loads((ROOT/f'results/{k}.json').read_text()) for k in files}
    data['connections']=json.loads((ROOT/'BRANCH_CONNECTIONS.json').read_text())
    text=json.dumps(data,allow_nan=False,separators=(',',':')).replace('</','<\\/')
    template=(ROOT/'explorer.template.html').read_text(encoding='utf-8')
    (ROOT/'explorer.html').write_text(template.replace('__CAMPAIGN_DATA__',text),encoding='utf-8')
    print('Exported two 14-field candidate inquiries, obligation contrasts and standalone explorer')


if __name__=='__main__':main()
