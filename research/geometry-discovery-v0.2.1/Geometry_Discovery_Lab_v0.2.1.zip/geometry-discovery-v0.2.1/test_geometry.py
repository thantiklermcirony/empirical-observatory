"""Scientific validation: independent analytical oracles and adversarial cases."""
import math
import random
import itertools
import unittest
from fractions import Fraction as F
import numpy as np
from geometry import Polytope, ball_fibre, rank_ball_axes, resource_fibre, resource_measurements, rank_bins, dot


class PolytopeTests(unittest.TestCase):
    def test_simplex_oracle(self):
        p=Polytope([(0,1)]*3,[((1,1,1),1)])
        self.assertEqual(set(p.vertices()),{(F(0),F(0),F(0)),(F(1),F(0),F(0)),(F(0),F(1),F(0)),(F(0),F(0),F(1))})
        self.assertEqual(p.bounds((2,-1,3))['width'],4)

    def test_lower_dimensional_fibre(self):
        p=Polytope([(0,1)]*2).intersect((1,1),1,1)
        self.assertEqual(p.bounds((1,-1))['width'],2)
        point=p.intersect((1,0),F(1,3),F(1,3))
        self.assertEqual(point.bounds((3,4))['width'],0)

    def test_empty_is_inconsistent(self):
        p=Polytope([(0,1)]).intersect((1,),2,3)
        with self.assertRaises(ValueError):p.bounds((1,))

    def test_rational_resource_oracles(self):
        for q in [F(i,100) for i in range(101)]:
            p,t,o=resource_fibre(q);bounds=p.bounds(t,o)
            self.assertEqual(bounds['lower'],q/10+F(3,50))
            self.assertEqual(bounds['upper'],q/2+F(7,50))
            self.assertEqual(bounds['width'],F(2,5)*q+F(2,25))
            self.assertTrue(p.contains(bounds['lower_witness']))
            self.assertTrue(p.contains(bounds['upper_witness']))

    def test_design_switch_and_full_bin_cover(self):
        for q in [F(1,20),F(1,5),F(3,4)]:
            p,t,o=resource_fibre(q);ranked=rank_bins(p,t,o,resource_measurements())
            byid={r['id']:r for r in ranked}
            self.assertEqual(byid['absolute_total_pool']['worst_width'],q/20+F(2,25))
            self.assertEqual(byid['nadph_pool']['worst_width'],F(2,5)*q+F(1,100))
            for r in ranked:
                self.assertEqual(len(r['outcomes']),8)
                self.assertTrue(all(x['width']<=p.bounds(t,o)['width'] for x in r['outcomes']))
            if q<F(1,5):self.assertEqual(ranked[0]['id'],'nadph_pool')
            if q>F(1,5):self.assertEqual(ranked[0]['id'],'absolute_total_pool')
            if q==F(1,5):self.assertEqual(ranked[0]['worst_width'],ranked[1]['worst_width'])

    def test_missing_projection_region_rejected(self):
        p,t,o=resource_fibre(F(1,2));m=resource_measurements()[0];m['edges']=m['edges'][1:]
        with self.assertRaises(ValueError):rank_bins(p,t,o,[m])

    def test_invalid_domain_rejected(self):
        with self.assertRaises(ValueError):Polytope([(1,0)])
        with self.assertRaises(ValueError):resource_fibre(F(11,10))
        with self.assertRaises(ValueError):Polytope([(0,1)]).intersect((1,),1,0)

    def test_observation_refinement_and_affine_relabel(self):
        # t'=10t; target coefficient changes by inverse factor.
        p,t,o=resource_fibre(F(3,4));original=p.bounds(t,o)
        relabelled=Polytope([(2,10),(0,F(2,25))]).bounds((F(3,80),1),o)
        self.assertEqual(original['lower'],relabelled['lower'])
        self.assertEqual(original['upper'],relabelled['upper'])
        refined=p.intersect((1,0),F(3,10),F(4,10)).intersect((0,1),F(1,100),F(2,100)).bounds(t,o)
        self.assertEqual(refined['width'],F(19,400))
        self.assertLessEqual(refined['width'],original['width'])


class BallTests(unittest.TestCase):
    def test_review_exact_ball_boundary(self):
        for z in [1+4e-11,np.nextafter(1.0,2.0),-np.nextafter(1.0,2.0)]:
            with self.assertRaisesRegex(ValueError,'outside unit ball'):
                ball_fibre([[0,0,1]],[z],[1,0,0])
        self.assertEqual(ball_fibre([[0,0,1]],[1],[1,0,0])['width'],0)
        inside=ball_fibre([[0,0,1]],[np.nextafter(1.0,0.0)],[1,0,0])
        self.assertGreater(inside['width'],0)
        # A non-axis-aligned exact boundary needs no tolerance or clipping.
        tangent=ball_fibre([[1,2,2]],[3],[1,0,0])
        self.assertEqual(tangent['feasibility']['center_norm_squared_exact'],'1')
        self.assertEqual(tangent['width'],0)

    def test_review_target_scale_preserves_extrema(self):
        for scale in [1e-300,1e-150,1e-30,1e-11,1,1e10,1e150,1e300]:
            out=ball_fibre([],[],[scale,0])
            self.assertEqual(out['lower'],-scale)
            self.assertEqual(out['upper'],scale)
            self.assertEqual(out['width'],out['upper']-out['lower'])
            self.assertEqual(out['lower_witness'],[-1,0])
            self.assertEqual(out['upper_witness'],[1,0])
            self.assertEqual(out['next_axis'],[1,0])
        zero=ball_fibre([],[],[0,0])
        self.assertEqual(zero['width'],0)
        self.assertIsNone(zero['next_axis'])

    def test_review_all_duplicate_integer_axes_and_rescalings(self):
        for axis in itertools.product(range(1,6),repeat=3):
            for multiplier in [1,2,-2,1024]:
                record=rank_ball_axes([axis],[0],[1,0,0],[dict(id='duplicate',axis=[multiplier*x for x in axis],cost=1)])[0]
                self.assertEqual(record['guaranteed_reduction'],0)
                self.assertEqual(record['reduction_per_cost'],0)

    def test_review_unresolvable_offset_is_explicit(self):
        with self.assertRaisesRegex(ArithmeticError,'cannot be resolved'):
            ball_fibre([],[],[1e-30,0],1)

    def test_nonzero_readout_formula(self):
        result=ball_fibre([[0,0,1]],[.8],[0,.25,.1],.5)
        self.assertAlmostEqual(result['width'],.3)
        self.assertAlmostEqual(result['lower'],.43)
        self.assertAlmostEqual(result['upper'],.73)
        self.assertTrue(np.allclose(result['lower_witness'],[0,-.6,.8]))

    def test_zero_readout_quantum_lead_case(self):
        result=ball_fibre([[0,0,1]],[0],[0,.25,.25],.5)
        self.assertAlmostEqual(result['width'],.5)
        self.assertTrue(np.allclose(result['upper_witness'],[0,1,0]))

    def test_general_rotated_and_redundant_rows(self):
        # Independent projection oracle for a single arbitrary vector.
        m=np.array([1.,2.,-2.]);axis=m/3;y=.3;v=np.array([.2,-.1,.15])
        center=y*axis;p=v-(v@axis)*axis
        expected=2*math.sqrt(1-y*y)*np.linalg.norm(p)
        out=ball_fibre([axis,2*axis],[y,2*y],v)
        self.assertAlmostEqual(out['width'],expected)
        self.assertTrue(np.allclose(out['center'],center))
        self.assertEqual(out['rank'],1)

    def test_boundary_empty_and_full_rank(self):
        self.assertAlmostEqual(ball_fibre([[0,0,1]],[1],[1,2,3])['width'],0)
        self.assertAlmostEqual(ball_fibre(np.eye(3),[.1,.2,.3],[1,2,3])['width'],0)
        with self.assertRaises(ValueError):ball_fibre([[0,0,1]],[1.1],[1,2,3])
        with self.assertRaises(ValueError):ball_fibre([[0,0,1],[0,0,1]],[0,1],[1,2,3])
        with self.assertRaises(ValueError):ball_fibre([[0,0,1]],[float('nan')],[1,2,3])

    def test_tolerance_cannot_invent_exact_null_space(self):
        with self.assertRaisesRegex(ValueError,'Ill-conditioned'):
            ball_fibre([[1,0,0],[0,1,0],[0,0,1e-13]],[0,0,0],[0,0,1])
        with self.assertRaisesRegex(ValueError,'Inconsistent exact'):
            ball_fibre([[0,0,1],[0,0,1]],[0,1e-12],[0,0,1])
        with self.assertRaisesRegex(ValueError,'Ill-conditioned candidate'):
            rank_ball_axes([[0,0,1]],[0],[1,0,0],[dict(id='almost_z',axis=[1e-13,0,1],cost=1)])

    def test_random_feasible_states_enclosed_by_extrema(self):
        rng=random.Random(717)
        for _ in range(80):
            z=rng.uniform(-.95,.95);v=np.array([rng.uniform(-1,1) for _ in range(3)])
            out=ball_fibre([[0,0,1]],[z],v)
            for witness in [out['lower_witness'],out['upper_witness']]:
                self.assertLessEqual(np.linalg.norm(witness),1+1e-10)
                self.assertAlmostEqual(witness[2],z)
            for _ in range(25):
                radius=math.sqrt(1-z*z)*math.sqrt(rng.random());angle=rng.random()*2*math.pi
                state=[radius*math.cos(angle),radius*math.sin(angle),z];value=v@state
                self.assertGreaterEqual(value,out['lower']-1e-10)
                self.assertLessEqual(value,out['upper']+1e-10)

    def test_single_extra_axis_and_optimality(self):
        v=[.2,.3,.1];base=ball_fibre([[0,0,1]],[.4],v)
        axis=base['next_axis'];after=ball_fibre([[0,0,1],axis],[.4,.1],v)
        self.assertLess(after['width'],1e-10)
        # A perpendicular unmeasured axis retains other state ambiguity.
        other=np.cross([0,0,1],axis)
        self.assertGreater(ball_fibre([[0,0,1],axis],[.4,.1],other)['width'],1)

    def test_worst_new_outcome_at_center(self):
        v=[.2,.3,.1];z=.4
        ranked=rank_ball_axes([[0,0,1]],[z],v,[dict(id='x',axis=[1,0,0],cost=1)])
        worst=ranked[0]['worst_width']
        for x in [-.8,-.4,0,.4,.8]:
            actual=ball_fibre([[0,0,1],[1,0,0]],[z,x],v)['width']
            self.assertLessEqual(actual,worst+1e-10)
        self.assertAlmostEqual(worst,2*math.sqrt(1-z*z)*.3)

    def test_cost_and_noise_are_not_free_information(self):
        c=[dict(id='x',axis=[1,0,0],cost=1),dict(id='y',axis=[0,1,0],cost=100)]
        self.assertEqual(rank_ball_axes([[0,0,1]],[0],[.2,.3,0],c)[0]['id'],'x')
        with self.assertRaises(ValueError):rank_ball_axes([],[],[1,0,0],[dict(id='bad',axis=[1,0,0],cost=0)])
        # Two states compatible with y readout 0 +/- .05 retain target gap .025.
        self.assertAlmostEqual((.5+.25*.05)-(.5-.25*.05),.025)

    def test_minimax_error_and_noncommuting_invariance(self):
        # An identical readout forces one estimate for both witnesses.
        lo,hi=.25,.75;mid=(lo+hi)/2
        for estimate in [0,.3,.5,.7,1]:self.assertGreaterEqual(max(abs(estimate-lo),abs(estimate-hi)),.25)
        self.assertEqual(max(abs(mid-lo),abs(mid-hi)),.25)
        cross=lambda a,b,c,d:(a-c)*(b-d)/((a-d)*(b-c))
        points=[F(1),F(2),F(3),F(4)];a=lambda x:2*x;b=lambda x:x+1
        self.assertEqual(cross(*points),cross(*[a(b(x)) for x in points]))
        self.assertEqual(cross(*points),cross(*[b(a(x)) for x in points]))
        self.assertNotEqual(a(b(F(1))),b(a(F(1))))


if __name__=='__main__':unittest.main(verbosity=2)
