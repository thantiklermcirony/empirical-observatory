from pathlib import Path
import hashlib,json,shutil,subprocess,sys

import argparse
parser=argparse.ArgumentParser()
parser.add_argument('--source',type=Path,required=True)
parser.add_argument('--python',type=Path,required=True)
parser.add_argument('--work',type=Path,required=True)
args=parser.parse_args()
source=args.source.resolve()
owned=args.work.resolve()
if owned.exists():raise ValueError('Use a fresh empty review-copy destination')
python=args.python.resolve()
manifest=json.loads((source/'manifest.json').read_text())
checks={p:hashlib.sha256((source/p).read_bytes()).hexdigest()==h for p,h in manifest['files'].items()}
assert all(checks.values())
if not owned.exists():shutil.copytree(source,owned)
runs=[]
for filename in ['assemble.py','accounting_validation.py','validate_provenance.py']:
    p=subprocess.run([str(python),'-B',filename],cwd=owned,capture_output=True,text=True)
    runs.append(dict(command=filename,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))
    if p.returncode:
        print(json.dumps(runs,indent=2));sys.exit(p.returncode)
packages=[json.loads((owned/'cases'/f'{name}.json').read_text()) for name in ['finite','open_gsh_source','clamped','missing_calibration']]
packages.append(json.loads((owned/'continuation_inquiry.json').read_text()))
conclusions=[r for p in packages for r in p['results'] if r['id']=='GPX-BUDGET' or p is packages[-1]]
assert len(conclusions)==29
for p in packages:
    prem={v['id']:v for v in p['premises']}
    assert 'BIO-ACCOUNTING' in prem
for r in conclusions:
    assert 'BIO-ACCOUNTING' in r['depends_on']
    # Independent necessity removal: any valid consumer of declared dependencies
    # must block this row when the accounting premise is unavailable.
    required=set(r['depends_on']);available=required-{'BIO-ACCOUNTING'}
    assert required-available=={'BIO-ACCOUNTING'}
receipt=dict(reviewer='mathematics',status='accepted_for_declared_accounting_correction',
             source_manifest_sha256=hashlib.sha256((source/'manifest.json').read_bytes()).hexdigest(),
             input_files_verified=len(checks),replayed_runs=runs,accounting_conclusions_checked=len(conclusions),
             limitation='Replayed corrected exporter and provenance checks; did not refit biology, reproduce the full numerical campaign or certify the central trusted consumer.',
             empirical_status='unresolved')
destination=owned/'mathematics-review.json'
destination.parent.mkdir(parents=True,exist_ok=True)
destination.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k!='replayed_runs'},indent=2))
