"""Reproducible synthetic campaign; never imports live domain solvers or patient data."""
from fractions import Fraction as F
from pathlib import Path
import csv
import hashlib
import json
import math
import platform
import random
import numpy as np
from geometry import ball_fibre, rank_ball_axes, resource_fibre, resource_measurements, rank_bins, dot

ROOT=Path(__file__).resolve().parent
VERSION='0.2.1'


def clean(value):
    if isinstance(value,F): return str(value)
    if isinstance(value,dict): return {k:clean(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)): return [clean(v) for v in value]
    return value


def dump(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(clean(value),indent=2,allow_nan=False)+'\n',encoding='utf-8')


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def quantum_campaign():
    cases=[]
    candidates=[dict(id='x',axis=[1,0,0],cost=1),dict(id='y',axis=[0,1,0],cost=1),dict(id='diagonal',axis=[1,1,0],cost=1)]
    for z in [-.8,-.4,0,.4,.8]:
        for degrees in range(0,180,15):
            theta=math.radians(degrees)
            # A stipulated physical effect: eigenvalues .5 +/- sqrt(.25^2+.1^2).
            v=[.25*math.cos(theta),.25*math.sin(theta),.1]
            base=ball_fibre([[0,0,1]],[z],v,.5)
            ranked=rank_ball_axes([[0,0,1]],[z],v,candidates)
            # Preserve the exact supplied target coefficients; a rounded unit
            # normalization can otherwise introduce a tiny residual direction.
            target_axis=base['projected_target']
            after=ball_fibre([[0,0,1],target_axis],[z,0],v,.5)
            fixed=next(c for c in ranked if c['id']=='x')['worst_width']
            cases.append(dict(id=f'Q-{len(cases)+1:03d}',z=z,angle_degrees=degrees,target=v,offset=.5,
                              before=base,ranked=ranked,best_allowed_width=ranked[0]['worst_width'],
                              fixed_x_width=fixed,uniform_random_expected_width=sum(r['worst_width'] for r in ranked)/len(ranked),
                              unrestricted_target_axis_width=after['width']))
    # Finite-noise analytical example, exact existing z readout and centered y interval.
    noise=[]
    for epsilon in [0,.01,.05,.2,.8,1]:
        rho=.6 # z=.8
        noise.append(dict(epsilon=epsilon,z=.8,target_y=.25,
                          target_width=2*.25*min(rho,epsilon),scope='exact z and bounded error in fresh-ensemble y readout'))
    return dict(cases=cases,noise=noise,scope='Synthetic affine effects, not fitted quantum models',
                mean_best_allowed_width=float(np.mean([c['best_allowed_width'] for c in cases])),
                mean_fixed_x_width=float(np.mean([c['fixed_x_width'] for c in cases])),
                mean_uniform_random_expected_width=float(np.mean([c['uniform_random_expected_width'] for c in cases])))


def biology_campaign():
    cases=[]; observations=[]; rng=random.Random(20260912)
    for q in [F(1,20),F(1,10),F(1,5),F(1,4),F(1,2),F(3,4),F(9,10),F(99,100)]:
        poly,target,offset=resource_fibre(q)
        bounds=poly.bounds(target,offset)
        ranked=rank_bins(poly,target,offset,resource_measurements())
        cases.append(dict(id=f'B-{len(cases)+1:03d}',q=q,before=bounds,ranked=ranked,
                          best_allowed_width=ranked[0]['worst_width'],
                          fixed_total_width=next(r['worst_width'] for r in ranked if r['id']=='absolute_total_pool'),
                          random_expected_width=sum(r['worst_width'] for r in ranked)/2))
        # Off-grid rational states, independent of bin boundaries. Both instruments
        # observe exchangeable fresh aliquots of the same stipulated state.
        for j in range(32):
            total=F(1,5)+F(rng.randrange(1,800000),1000000)
            nadph=F(rng.randrange(1,80000),1000000)
            truth=dot(target,(total,nadph))+offset
            for assay in resource_measurements():
                value=dot(assay['row'],(total,nadph)); edges=assay['edges']
                b=min(len(edges)-2,next((i for i in range(len(edges)-1) if value<edges[i+1]),len(edges)-2))
                child=poly.intersect(assay['row'],edges[b],edges[b+1])
                bound=child.bounds(target,offset)
                observations.append(dict(world=f'B{len(cases)}-W{j+1:02d}',q=q,total=total,nadph=nadph,
                                         true_budget=truth,assay=assay['id'],readout=value,bin=b,
                                         lower=bound['lower'],upper=bound['upper'],width=bound['width'],
                                         truth_enclosed=bound['lower']<=truth<=bound['upper'],
                                         result_kind='model_prediction',data_origin='synthetic'))
    return dict(cases=cases,observations=observations,seed=20260912,
                enclosure_violations=sum(not o['truth_enclosed'] for o in observations),
                mean_best_allowed_width=sum(c['best_allowed_width'] for c in cases)/len(cases),
                mean_fixed_total_width=sum(c['fixed_total_width'] for c in cases)/len(cases),
                mean_uniform_random_expected_width=sum(c['random_expected_width'] for c in cases)/len(cases))


def countermodels():
    # Coordinate change: preserve feasible states/readout/target together, never a raw metric.
    # With fixed z=0 and target .5+.25y, +y/-y differ by .5. Relabel y'=10y:
    # Euclidean witness distance is 20 instead of 2; target becomes .5+.025y'.
    coordinate=dict(id='CM-COORDINATE',original_witness_distance=2,relabeled_witness_distance=20,
                    original_target_width=.5,transported_target_width=.5,
                    failure='Raw Euclidean distance is not invariant under a coordinate relabeling.')
    # A and B both projective, but their ordered compositions disagree.
    order=[]
    for x in [F(0),F(1,4),F(1,2),F(3,4)]:
        a=lambda t:2*t
        b=lambda t:t+1
        order.append(dict(x=x,A_after_B=a(b(x)),B_after_A=b(a(x)),gap=a(b(x))-b(a(x))))
    # One mole-equivalent in a shrinking volume; concentrations are not conserved.
    volume=dict(id='CM-VOLUME',initial_amount=1,final_amount=1,initial_volume=1,final_volume=F(1,2),
                initial_concentration=1,final_concentration=2,
                failure='Closed amounts do not imply constant concentrations under changing volume.')
    # Continuous hypothesis hidden between sparse samples, no noise needed.
    sparse=dict(id='CM-SAMPLED-ENVELOPE',sampled_x=[0,1],sampled_x_times_one_minus_x=[0,0],
                off_grid_x=F(1,2),off_grid_value=F(1,4),
                failure='A sampled range is not an enclosure of a continuous nonlinear image.')
    # Same mean attenuations, distinct second-time response; positive mixture geometry.
    recovery=dict(id='CM-RECOVERY',weights=[F(1,2),F(1,2)],attenuations=[F(1,2),F(1,4)],
                  first_time=F(3,8),second_time=F(5,32),scalar_semigroup_prediction=F(9,64),variance_gap=F(1,64),
                  failure='A scalar linear-amplitude semigroup cannot reproduce this heterogeneous mixture at both times.')
    return [coordinate,dict(id='CM-ORDER',instances=order,failure='Preserving projective structure does not imply commutation.'),volume,sparse,recovery]


def generated_questions(qcamp,bcamp):
    queue=[]
    for case in qcamp['cases']:
        best=case['ranked'][0]
        if case['before']['width']<1e-12:continue
        queue.append(dict(id='NEXT-'+case['id'],branch='quantum',source_case=case['id'],
                          question=f"Is the {best['id']} ensemble readout physically accessible with the stated preparation and noise bounds?",
                          selected_measurement=best['id'],score=best['reduction_per_cost'],score_unit='yield-width reduction / abstract cost',
                          context=dict(readout_z=case['z'],effect_vector=case['target'],effect_offset=case['offset'],
                                       before_width=case['before']['width'],after_worst_width=best['worst_width'],candidate_menu=['x','y','diagonal']),
                          rationale='Maximum guaranteed reduction among the three declared exact axes.',
                          required_before_experiment=['Q-MATCHED-PREPARATION','Q-ACCESSIBLE-AXIS','Q-NOISE-MODEL'],
                          state='generated_proposal',promotion='requires domain review'))
    for case in bcamp['cases']:
        best=case['ranked'][0]
        queue.append(dict(id='NEXT-'+case['id'],branch='biology',source_case=case['id'],
                          question=f"Can {best['id']} be measured on matched preparations at the declared resolution?",
                          selected_measurement=best['id'],score=best['reduction_per_cost'],score_unit='mM budget-width reduction / abstract cost',
                          context=dict(exact_reduced_fraction=case['q'],total_pool_interval_mM=['1/5','1'],nadph_interval_mM=['0','2/25'],
                                       before_width=case['before']['width'],after_worst_width=best['worst_width'],horizon_min=20),
                          rationale='Minimax residual budget width over all covering bins, with equal abstract assay costs.',
                          required_before_experiment=['BIO-VOLUME','BIO-LEDGER','BIO-UNIT-MAP','BIO-MATCHED-UNIT','BIO-ASSAY-CALIBRATION'],
                          state='generated_proposal',promotion='requires domain review'))
    # Scores have different units; only rank within a domain. Never compare biology .1 mM to quantum .1 yield.
    return sorted(queue,key=lambda x:(x['branch'],-float(x['score']),x['id']))


def main():
    qcamp,bcamp=quantum_campaign(),biology_campaign()
    questions=generated_questions(qcamp,bcamp)
    families={}
    for question in questions:
        key=question['branch']+':'+question['selected_measurement']
        family=families.setdefault(key,dict(id=key,branch=question['branch'],question=question['question'],instances=[],
                                          score_unit=question['score_unit'],state='generated_proposal_family'))
        family['instances'].append(question['id'])
    summary=dict(version=VERSION,python=platform.python_version(),numpy=np.__version__,
                 quantum_cases=len(qcamp['cases']),resource_geometries=len(bcamp['cases']),
                 synthetic_measurement_records=len(bcamp['observations']),synthetic_preparations=len(bcamp['observations'])//2,
                 continuous_bin_fibres=sum(len(r['outcomes']) for c in bcamp['cases'] for r in c['ranked']),
                 enclosure_violations=bcamp['enclosure_violations'],
                 quantum_mean_best_width=qcamp['mean_best_allowed_width'],quantum_mean_fixed_width=qcamp['mean_fixed_x_width'],
                 quantum_mean_random_width=qcamp['mean_uniform_random_expected_width'],
                 biology_mean_best_width=bcamp['mean_best_allowed_width'],biology_mean_fixed_width=bcamp['mean_fixed_total_width'],
                 biology_mean_random_width=bcamp['mean_uniform_random_expected_width'],
                 generated_questions=len(qcamp['cases'])+len(bcamp['cases']),
                 unique_measurement_question_families=len(families),
                 claims='Conditional geometry and synthetic data only. No empirical validation or generic adaptive superiority.',
                 input_hashes={p.name:digest(p) for p in [ROOT/'geometry.py',ROOT/'campaign.py']})
    dump(ROOT/'results/quantum.json',qcamp)
    dump(ROOT/'results/biology.json',bcamp)
    dump(ROOT/'results/countermodels.json',countermodels())
    dump(ROOT/'results/questions.json',questions)
    dump(ROOT/'results/question-families.json',list(families.values()))
    dump(ROOT/'results/summary.json',summary)
    with (ROOT/'results/synthetic-observations.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(bcamp['observations'][0]));writer.writeheader()
        writer.writerows(clean(bcamp['observations']))
    print(json.dumps(clean(summary),indent=2))


if __name__=='__main__':main()
