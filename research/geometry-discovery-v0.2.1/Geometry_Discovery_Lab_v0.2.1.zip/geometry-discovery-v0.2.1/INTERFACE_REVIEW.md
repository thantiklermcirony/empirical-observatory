# Cross-branch mathematical obligations

## BIO-INT-02: fixed normalization and complete accounting

The biological v0.1.1 correction was independently replayed in a mathematics-owned copy. All 74 manifest entries matched before replay. `assemble.py`, `accounting_validation.py` and `validate_provenance.py` completed successfully. The stable `BIO-ACCOUNTING` premise occurs in all four base GPX-BUDGET records, 24 continuation bounds and the concentration moiety: 29 affected conclusions. The receipt is `results/biology-011-review.json`.

The correction is accepted for the declared accounting omission. It requires a common fixed normalization volume/time and complete reducing-equivalent source/sink accounting. Removing the regeneration ceiling blocks the four affected budget rows while the closed-moiety conclusion retains its own distinct premises. This review does not refit biology or repeat its full numerical campaign, and does not certify the central consumer.

For amounts g,n and nonnegative GPx extent rate j_p, the ledger gives d(g/2+n)/dt = j_reg-j_p+j_g/2, after including every source/sink required by the model. Integration yields integral j_p <= g(0)/2+n(0)+integral j_reg+.5 integral j_g. Concentrations satisfy this same form only under the admitted common fixed volume. With variable V, x=n/V gives xdot=ndot/V-x Vdot/V; omitting the dilution/concentration term is invalid.

The corrected countermodel has V(t)=exp(-t/10) L, GSH amount 1-.04t mmol, and GPx amount rate .02 mmol/min for 20 minutes. The integrated concentration rate is .2(exp(2)-1)=1.27781122 mM, which violates a falsely retained .5 mM concentration ceiling; the .4 mmol extent still respects the .5 mmol amount reserve. Thus an amount ledger must not be silently reused as a concentration ledger.

The new lab's resource fixtures declare narrower `BIO-VOLUME`, `BIO-LEDGER`, `BIO-UNIT-MAP`, source, nonnegativity and matched-unit obligations. The geometry of compatible stocks remains distinct from achieved reaction extent or viability. The anatomical structure label is not a specimen identity or concentration measurement.

## Q-COUPLING-02: causality, clocks and conservation

Let b(s) be a nonnegative integrable pair birth rate in amount/time, with no pre-existing pairs at t=0. Let S(a) be survival at physical age a, k_i(a) nonnegative product-time densities in 1/time and F_i(a)=integral_0^a k_i(u)du. Require S(a)+sum_i F_i(a)=1 for the complete outcome ledger. For a stationary generator and declared initial birth state:

    live(t) = integral_0^t b(s) S(t-s) ds
    product_i(t) = integral_0^t b(s) F_i(t-s) ds
    flux_i(t) = integral_0^t b(s) k_i(t-s) ds.

Then live+sum_i product_i=integral_0^t b(s)ds by integrating the single-pair ledger. Future births cannot change an earlier value, because the integration uses s<=t. With integrability/regularity sufficient to differentiate, product_i'=flux_i because F_i(0)=0. A pre-existing ensemble adds its own initial-condition term; it cannot be smuggled in as future births.

For dimensionless age tau=a/t0, S_phys(a)=S_dim(a/t0) and k_phys(a)=k_dim(a/t0)/t0. Changing t0 rescales physical timing while leaving the integrated infinite-age yields unchanged, if those integrals exist. Multiplying an infinite-age yield by b(t) gives the stationary asymptotic rate only when the constant-input and settling assumptions justify it; it is not the startup flux in general.

If birth units are concentration/time, the same equations describe concentration-normalized ensemble amounts only under a fixed common volume. A downstream species concentration rate requires the same time units and a declared stoichiometric/product map. The supplied quantum growth implementation names arrays `*_uM`: these are concentration-normalized amounts, not absolute molecular counts. Convert them through a known volume when an amount ledger is needed.

For a time-varying generator, response depends on birth time and observation time separately. Use a two-time propagator S(t,s),F_i(t,s); a stationary age-only convolution is not licensed. No instantaneous change in chemical environment is modeled by changing a kernel parameter without rebuilding the propagation.

Required independent checks: analytic constant-birth/no-mixing limit; zero birth; pulse response against a separately implemented forced-source ODE; complete nonnegative ledger; future-birth invariance; physical-clock scaling; nonzero-initial-ensemble handling or explicit rejection; convergence and error scope; and rejection of a nonstationary generator by an age-only adapter. Grid differences are error diagnostics, not rigorous certified bounds.

The quantum `geometry.py` and `flux.py` implementations were read while in progress. The mathematical support statement agrees with PROOFS GDL-03 and its zero-readout special case passes an independent fixture here. These equations and checks are a mathematical interface review, not a full independent replay or acceptance of the moving quantum release. Freeze/source binding belongs in its later handoff.

## Instrument and postselection obligations

A readout on a fresh matched ensemble may constrain a preparation distribution. An instrument applied to the very system being predicted can change that system; conditioning and state disturbance must be propagated. If a selected Kraus outcome increases a conditional yield, retain its probability and every complementary outcome before making an unconditional comparison. Conditional UHL composition does not replace outcome-mass accounting. The earlier atlas already treats success probability separately.
