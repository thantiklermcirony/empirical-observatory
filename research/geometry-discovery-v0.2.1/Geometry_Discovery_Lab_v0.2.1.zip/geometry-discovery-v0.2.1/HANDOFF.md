# Integration handoff: Geometry Discovery Lab 0.2.1

This additive local release upgrades the mathematical branch from checked atlas claims to target-specific ambiguity, witness and next-measurement generation. Earlier frozen and published atlas files are unchanged.

## Consumer entry points

| Purpose | File | Meaning |
|---|---|---|
| Executable geometry | `geometry.py` | Exact rational compact polytopes; numerical evaluation of analytic observed-ball bounds with exact finite-coordinate rank rejection |
| Existing shared contract | `packages/quantum.json`, `packages/biology.json` | Two candidate inquiries, 14 fields each, with per-result scientific premises and bound artifact hashes |
| Observations and witnesses | `results/quantum.json`, `results/biology.json` | Authored model fixtures and continuous target bounds; resource intervals describe ceilings |
| Research queue | `results/questions.json`, `results/question-families.json` | 68 case-specific proposals in five measurement-question families; context and source case IDs retained |
| Programme routes | `BRANCH_CONNECTIONS.json` | Ten maps with preserved structure, required premises and explicit unsupported transfers |
| User exploration | `explorer.html` | Standalone local consumer; no external network dependencies |
| Biology correction review | `results/biology-011-review.json` | 74 verified inputs and three replayed scripts; 29 accounting-dependent conclusions checked |
| Quantum mathematical review | `INTERFACE_REVIEW.md`, `PROOFS.md` | Causal convolution, clock/amount/volume obligations and generalized nonzero-readout support theorem |

The instance package IDs are `GDL-QUANTUM` and `GDL-BIOLOGY`. Their established results are `GDL-QUANTUM-WIDTHS` and `GDL-BIOLOGY-WIDTHS`; physical experiment records end in `-EXPERIMENT` and remain unresolved. The supplied local obligation map is not a trusted admission service. Integration must verify actual scientific premise values, parent/current-source bindings and the result values it renders.

Biology/anatomy may reference the exact ratio-readout resource fixture and its next-assay switch at q=.2. Selecting an organ does not license `BIO-UNIT-MAP` or empirical calibration. The minimum compatible budget ceiling must not be displayed as a guaranteed lower bound on achieved clearance. The common-volume and full-ledger premise correction is independently accepted here within the stated review scope; central acceptance remains integration-owned.

Quantum may bind a frozen reviewed affine yield effect to the common nonzero-readout kernel. Exact finite-coordinate rank is checked against the SVD threshold, including candidate observations; ill-conditioned exact readouts are rejected rather than creating spurious null spaces. General noisy multi-axis geometry and time-dependent physical kernels remain later work. The zero-centered one-axis noise example is already derived and evaluated.

The Living Encyclopedia branch can use the same queue and connection records as research requests. Each proposal retains the parent case, target, readout context, predicted reduction and experiment obligations. These fields describe a mathematical reason to ask a question; they confer no empirical confidence and are not a new universal schema. This release predates any independently reviewed encyclopedia consumer.

## Acceptance requested from the coordinator

Run `python -B verify_release.py`, copy the release into an owned review directory, then run `python -B run_all.py`. The tests include rational endpoint oracles, random feasible-state enclosure, exact-rank/conditioning failures, malformed/empty observations, finite covering bins and narrow premise removal. The explorer was visually and functionally checked as described in `UI_VERIFICATION.md`.

The main command is fully local and requires only Python and NumPy. Optional independent biology review replay uses `review_biology.py --source <biology-v0.1.1-directory> --python <Python-with-its-dependencies> --work <new-owned-copy-path>`. This does not modify the external frozen biology release. Archive verification and fresh-copy replay are recorded in the separate release receipt.

No shared engine, Site source, anatomical assets or other task workspace was edited. No new GitHub publication or deployment was performed. The full endgame and staged completion criteria are in `PROJECT.md`.
