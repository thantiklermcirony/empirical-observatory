import unittest
from obligations import contrasts, report


class ObligationTests(unittest.TestCase):
    def test_missing_volume_blocks_concentrations_not_geometry(self):
        c=contrasts()['remove_BIO-VOLUME']
        self.assertEqual(c['gpx_extent_upper_bound']['blocked_by'],['BIO-VOLUME'])
        self.assertEqual(c['abstract_resource_width']['status'],'conditional_in_scope')
        self.assertEqual(c['abstract_ball_width']['status'],'conditional_in_scope')

    def test_missing_ledger_and_source(self):
        for p in ['BIO-LEDGER','BIO-SUPPLY']:
            self.assertEqual(contrasts()['remove_'+p]['gpx_extent_upper_bound']['blocked_by'],[p])

    def test_destructive_measurement_does_not_destroy_abstract_bound(self):
        c=contrasts()['remove_BIO-MATCHED-UNIT']
        self.assertEqual(c['biological_measurement_proposal']['status'],'unresolved')
        self.assertEqual(c['gpx_extent_upper_bound']['status'],'conditional_in_scope')

    def test_physical_axis_missing_does_not_erase_theorem(self):
        c=contrasts()['remove_Q-NOISE-MODEL']
        self.assertEqual(c['quantum_measurement_proposal']['status'],'unresolved')
        self.assertEqual(c['abstract_ball_width']['status'],'conditional_in_scope')

    def test_affinity_is_required(self):
        self.assertEqual(contrasts()['remove_M-AFFINE']['abstract_ball_width']['status'],'unresolved')

    def test_no_empirical_promotion_by_spoofed_identifier(self):
        for c in contrasts().values():
            self.assertIn('BIO-EMPIRICAL-RECEIPT',c['organ_or_patient_prediction']['blocked_by'])
        with self.assertRaises(ValueError):report({'invented_truth'})


if __name__=='__main__':unittest.main()
