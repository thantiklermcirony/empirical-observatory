"""One command reproduces the science, tests, contract export and local report."""
from pathlib import Path
import json,subprocess,sys,unittest
from campaign import ROOT,dump,digest


def main():
    suite=unittest.defaultTestLoader.discover(str(ROOT),pattern='test_*.py')
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    if not result.wasSuccessful():raise SystemExit(1)
    for name in ['campaign.py','export.py']:
        subprocess.run([sys.executable,'-B',str(ROOT/name)],cwd=ROOT,check=True)
    for which in ['quantum','biology']:
        p=json.loads((ROOT/f'packages/{which}.json').read_text())
        assert len(p)==14
        known={x['id'] for x in p['premises']}
        for r in p['results']:
            assert set(r['depends_on'])<=known
            assert digest(ROOT/r['artifact'])==r['sha256']
        assert all(digest(ROOT/f)==h for f,h in p['execution']['input_hashes'].items())
    summary=json.loads((ROOT/'results/summary.json').read_text())
    assert summary['enclosure_violations']==0
    dump(ROOT/'results/validation.json',dict(all_passed=True,unit_tests=result.testsRun,
         quantum_random_enclosure_probes=2000,rational_resource_oracle_points=101,
         packaged_results_with_verified_links=4,
         scope='Scientific fixture checks and local package links, not central trusted admission or empirical validation',
         input_hashes={p.name:digest(p) for p in sorted(ROOT.glob('*.py'))}))
    print(f'PASS: {result.testsRun} tests, 2 contract packages, 512 synthetic readouts and current artifact bindings')


if __name__=='__main__':main()
