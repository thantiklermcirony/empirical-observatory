"""Read-only manifest and local scientific artifact verification."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent


def main():
    sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    m=json.loads((ROOT/'manifest.json').read_text())
    actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='manifest.json'}
    assert actual==set(m['files']),'Manifest file set differs'
    for name,h in m['files'].items():assert sha(ROOT/name)==h,name
    for which in ['biology','quantum']:
        p=json.loads((ROOT/f'packages/{which}.json').read_text())
        assert len(p)==14
        for result in p['results']:assert sha(ROOT/result['artifact'])==result['sha256']
        for name,h in p['execution']['input_hashes'].items():assert sha(ROOT/name)==h
    v=json.loads((ROOT/'results/validation.json').read_text())
    assert v['all_passed']
    for name,h in v['input_hashes'].items():assert sha(ROOT/name)==h,name
    print(json.dumps(dict(all_passed=True,manifest_entries=len(actual),packaged_results=4,scope='Read-only file and result-binding checks')))


if __name__=='__main__':main()
