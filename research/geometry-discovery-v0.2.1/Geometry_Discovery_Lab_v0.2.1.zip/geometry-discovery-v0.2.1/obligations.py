"""Domain obligations for this fixture, not a trusted receipt/admission service.

The coordinator retains responsibility for trusted premise values, source freshness,
parent binding and empirical receipts. This module only emits the fixed local map.
"""
REQUIRED={
    'abstract_ball_width':{'M-BALL','M-AFFINE','M-READOUT'},
    'quantum_measurement_proposal':{'M-BALL','M-AFFINE','M-READOUT','Q-MATCHED-PREPARATION','Q-ACCESSIBLE-AXIS','Q-NOISE-MODEL'},
    'abstract_resource_width':{'M-COMPACT-BOX','M-LINEAR-TARGET','M-COVERING-BINS'},
    'gpx_extent_upper_bound':{'M-COMPACT-BOX','M-LINEAR-TARGET','BIO-VOLUME','BIO-LEDGER','BIO-NONNEG','BIO-SUPPLY','BIO-UNIT-MAP'},
    'biological_measurement_proposal':{'M-COMPACT-BOX','M-LINEAR-TARGET','M-COVERING-BINS','BIO-VOLUME','BIO-LEDGER','BIO-NONNEG','BIO-SUPPLY','BIO-UNIT-MAP','BIO-MATCHED-UNIT','BIO-ASSAY-CALIBRATION'},
    'organ_or_patient_prediction':{'BIO-ORGAN-MAP','BIO-EMPIRICAL-RECEIPT'},
}


def report(available):
    """Available means stipulated for a conditional exercise, never empirically true."""
    known=set().union(*REQUIRED.values())
    if set(available)-known:raise ValueError('Unknown obligation identifiers')
    out={}
    for result,requirements in REQUIRED.items():
        missing=sorted(requirements-set(available))
        # The release carries no empirical admission capability, even if a caller
        # supplies an ID purporting to represent an empirical receipt.
        if result=='organ_or_patient_prediction':missing=sorted(set(missing)|{'BIO-EMPIRICAL-RECEIPT'})
        out[result]=dict(depends_on=sorted(requirements),blocked_by=missing,
                         status='unresolved' if missing else 'conditional_in_scope')
    return out


def contrasts():
    base=set().union(*REQUIRED.values())-{'BIO-ORGAN-MAP','BIO-EMPIRICAL-RECEIPT'}
    cases={'synthetic_baseline':report(base)}
    for p in ['BIO-VOLUME','BIO-LEDGER','BIO-SUPPLY','BIO-MATCHED-UNIT','Q-NOISE-MODEL','M-AFFINE']:
        cases['remove_'+p]=report(base-{p})
    cases['empirical_id_spoof']=report(base|{'BIO-ORGAN-MAP','BIO-EMPIRICAL-RECEIPT'})
    return cases
