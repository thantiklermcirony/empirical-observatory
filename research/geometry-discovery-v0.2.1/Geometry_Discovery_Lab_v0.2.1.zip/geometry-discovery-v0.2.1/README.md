# Geometry Discovery Lab 0.2.1

An executable upgrade to the Observatory's mathematical branch. It finds compatible states with maximally different target values, ranks the next measurement and exports reproducible inquiry proposals.

Start with **[the interactive explorer](explorer.html)** or **[the project charter](PROJECT.md)**. The explorer opens as a standalone local file and needs no service or external assets.

## Reproduce

Python 3.10+ and NumPy are required. Tested with Python 3.12.14 / NumPy 2.3.5. `requirements.txt` allows the supported major range; the exact tested version is recorded in `results/summary.json`. There are no network calls, credentials, model API calls or external corpus requirements in the main campaign.

```sh
python -m pip install -r requirements.txt
python -B run_all.py
```

This runs 28 tests, regenerates the synthetic campaign, writes two existing-contract inquiry packages, verifies their artifact links, and rebuilds `explorer.html`. Run in a copied release if preserving its original manifest is important. The separate biology correction review receipt refers to an external frozen release; the main command does not replay that external review.

## Results

| Experiment | Cases | Mean target-directed residual width | Fixed baseline | Uniform random menu expectation |
|---|---:|---:|---:|---:|
| Synthetic affine quantum yields | 60 | 0.10956470 | 0.25528255 (x readout) | 0.25528255 |
| Resource budget ceilings, mM | 8 | 0.0924375 | 0.103375 (total assay) | 0.1501875 |

The quantum fixture selects among x, y and diagonal axes with equal costs. The unrestricted target direction gives zero exact target ambiguity by the theorem; that result depends on allowing that direction. The resource fixture selects between absolute total-pool and NADPH assay bins. This is target-directed one-step selection from authored menus, not learned kinetics or proof of an adaptive policy's superiority. Real measurement access, uncertainty and cost are uncalibrated.

There are 512 synthetic readouts from 256 preparations, 128 continuous bin regions and 68 case-specific proposal instances in **five measurement-question families**. These are not 68 independent discoveries. `results/question-families.json` groups repeats while each instance retains its model context. Zero sampled resource enclosure violations were observed; the bound itself follows from continuous rational geometry, not from that sample count. Questions are ranked only within their units; the programme does not compare a dimensionless yield width directly to mM.

## Files

- `geometry.py`: small bounded rational polytopes, affine ball fibres and measurement ranking.
- `PROOFS.md`: six proof statements, conditions and computational limits.
- `campaign.py`, `results/`: reproducible examples, synthetic observations, witnesses, baselines and question queue.
- `test_geometry.py`, `test_obligations.py`: independent analytic oracles, random feasible-state probes, counterexamples and premise-removal checks.
- `BRANCH_CONNECTIONS.json`: ten implemented or proposed programme connections with explicit maps and obligations.
- `packages/`: two 14-field Observatory candidate packages, not central admission receipts.
- `INTERFACE_REVIEW.md`: the accepted biology accounting correction and mathematical quantum coupling obligations.
- `PROJECT.md`: the long-term project and evidence-based milestones.
- `manifest.json`: hashes of the frozen release's other files, including the independent-review receipt and interactive report.

## Mathematical and empirical status

Resource bounds use exact fractions. Ball results evaluate a supplied analytic proof in float64 with SVD tolerance 1e-10. Exact finite-coordinate rank must agree with numerical rank; ill-conditioned observations and candidates are rejected. Inconsistent exact readout equations are rejected before projection. Physical measurement noise requires an explicit separate model. The polytope kernel requires a finite box, dimensions 1–4 and valid rational inputs. Empty fibres report inconsistency. Sparse samples are never used as a continuous guarantee.

The quantity bounded in the resource explorer is a **budget ceiling**, not actual detoxification or survival. The minimum compatible ceiling does not provide a lower bound on achieved GPx extent. The main geometric fixtures are authored synthetic models. There are no patient data, empirical calibration receipts or new empirical laws in this release.

This is an additive local version. The frozen theory atlas 0.1.0 and its public distribution remain unchanged. The Geometry Discovery Lab itself has not been published to GitHub, admitted into the central engine or deployed to the Observatory Site. Its contract matches the existing interchange format, and central integration remains coordinator-owned.

Original code and prose: MIT; see LICENSE. Third-party papers are linked rather than bundled. Standard convex geometry is background, not claimed as new mathematical priority.

The correction and numerical boundary policy are documented in [CORRECTION.md](CORRECTION.md). The original 0.2.0 release is preserved.
