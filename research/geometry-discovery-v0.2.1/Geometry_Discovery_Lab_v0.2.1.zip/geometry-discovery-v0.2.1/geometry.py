"""Small, auditable geometry kernels. No biological or quantum propagation solver."""
from fractions import Fraction as F
from itertools import combinations
import math
import numpy as np


def dot(a, b):
    return sum(x*y for x, y in zip(a, b))


def solve_exact(rows, rhs):
    n = len(rhs)
    a = [[F(x) for x in row]+[F(y)] for row, y in zip(rows, rhs)]
    for col in range(n):
        pivot = next((i for i in range(col, n) if a[i][col]), None)
        if pivot is None:
            return None
        a[col], a[pivot] = a[pivot], a[col]
        divisor = a[col][col]
        a[col] = [x/divisor for x in a[col]]
        for i in range(n):
            if i != col:
                factor = a[i][col]
                a[i] = [x-factor*y for x, y in zip(a[i], a[col])]
    return tuple(row[-1] for row in a)


def exact_rank(matrix):
    """Rank of the supplied finite float coordinates as exact binary rationals."""
    a=[[F(float(x)) for x in row] for row in matrix]
    if not a:return 0
    rank=0
    for col in range(len(a[0])):
        pivot=next((i for i in range(rank,len(a)) if a[i][col]),None)
        if pivot is None:continue
        a[rank],a[pivot]=a[pivot],a[rank]
        value=a[rank][col]
        a[rank]=[x/value for x in a[rank]]
        for i in range(rank+1,len(a)):
            factor=a[i][col]
            a[i]=[x-factor*y for x,y in zip(a[i],a[rank])]
        rank+=1
        if rank==len(a):break
    return rank


def row_basis(matrix):
    basis=[]; indices=[]
    for i,row in enumerate(matrix):
        candidate=[F(float(x)) for x in row]
        if exact_rank(basis+[candidate])>len(basis):
            basis.append(candidate);indices.append(i)
    return basis,indices


def row_lift(basis, rhs, dimension):
    """Minimum-norm solution for independent exact rows, over rational inputs."""
    if not basis:return [F(0)]*dimension
    gram=[[dot(a,b) for b in basis] for a in basis]
    weights=solve_exact(gram,rhs)
    assert weights is not None
    return [sum(weights[i]*basis[i][j] for i in range(len(basis))) for j in range(dimension)]


def exact_projection(basis, vector):
    row_component=row_lift(basis,[dot(row,vector) for row in basis],len(vector))
    return [x-y for x,y in zip(vector,row_component)]


def scaled_direction(vector):
    """Do not suppress a nonzero target by comparing it to a geometry tolerance."""
    scale=max(map(abs,vector),default=F(0))
    if not scale:return 0.0,None
    ratios=[float(x/scale) for x in vector]
    length=math.hypot(*ratios)
    magnitude=float(scale)*length
    if not math.isfinite(magnitude) or magnitude==0:
        raise ArithmeticError('Projected target magnitude is outside float64 range')
    return magnitude,np.asarray([x/length for x in ratios])


class Polytope:
    """Closed bounded rational polytope, explicitly intersected with a finite box.

    Exhaustive active-set vertex enumeration is suitable only for small dimension.
    Equality constraints are represented by both inequalities. Empty sets are errors
    when requesting bounds; they never masquerade as zero-width knowledge.
    """
    def __init__(self, box, constraints=()):
        self.box = tuple((F(lo), F(hi)) for lo, hi in box)
        self.n = len(box)
        if not 1 <= self.n <= 4 or any(lo > hi for lo, hi in self.box):
            raise ValueError('Require a nonempty finite box in dimensions 1..4')
        base = []
        for i, (lo, hi) in enumerate(self.box):
            row = tuple(F(int(j == i)) for j in range(self.n))
            base.extend([(row, hi), (tuple(-x for x in row), -lo)])
        extra = [(tuple(F(x) for x in a), F(b)) for a, b in constraints]
        if any(len(a) != self.n for a, _ in extra):
            raise ValueError('Constraint dimension mismatch')
        self.extra, self.constraints = extra, base+extra

    def intersect(self, row, lo, hi):
        if F(lo) > F(hi):
            raise ValueError('Reversed measurement interval')
        row = tuple(F(x) for x in row)
        return Polytope(self.box, self.extra+[(row, F(hi)), (tuple(-x for x in row), -F(lo))])

    def contains(self, x):
        return len(x) == self.n and all(dot(a, x) <= b for a, b in self.constraints)

    def vertices(self):
        points = set()
        for active in combinations(self.constraints, self.n):
            point = solve_exact([a for a, _ in active], [b for _, b in active])
            if point is not None and self.contains(point):
                points.add(point)
        return sorted(points)

    def bounds(self, target, offset=0):
        if len(target) != self.n:
            raise ValueError('Target dimension mismatch')
        target, offset = tuple(F(x) for x in target), F(offset)
        vertices = self.vertices()
        if not vertices:
            raise ValueError('Inconsistent observations: empty feasible set')
        ordered = sorted((dot(target, v)+offset, v) for v in vertices)
        return dict(lower=ordered[0][0], upper=ordered[-1][0],
                    width=ordered[-1][0]-ordered[0][0],
                    lower_witness=ordered[0][1], upper_witness=ordered[-1][1],
                    vertex_count=len(vertices))


def ball_fibre(matrix, readout, target, offset=0.0, tolerance=1e-10):
    """Affine target over {r: ||r||<=1, M r=y}. Float64 result, analytic theorem.

    Exact rank of the supplied finite coordinates must agree with SVD rank at
    tolerance*max(1,smax), or the input is rejected as ill-conditioned. A tolerance
    cannot create an exact null space. No experimental precision is inferred.
    """
    v = np.asarray(target, dtype=float)
    if v.ndim != 1 or not len(v) or not np.all(np.isfinite(v)):
        raise ValueError('Finite nonempty target vector required')
    n = len(v)
    raw = np.asarray(matrix, dtype=float)
    m = np.empty((0, n)) if raw.size == 0 else raw
    y = np.asarray(readout, dtype=float)
    if m.ndim != 2 or m.shape[1] != n or y.shape != (len(m),):
        raise ValueError('Observation dimensions mismatch')
    if not np.all(np.isfinite(m)) or not np.all(np.isfinite(y)) or not math.isfinite(offset):
        raise ValueError('Nonfinite geometry')
    if not math.isfinite(tolerance) or tolerance <= 0:
        raise ValueError('Positive finite tolerance required')
    if len(m):
        u, s, vh = np.linalg.svd(m, full_matrices=True)
        rank = int(np.sum(s > tolerance*max(1.0, float(s[0]))))
        structural_rank=exact_rank(m)
        if rank!=structural_rank:
            raise ValueError('Ill-conditioned exact readout: numerical and exact finite-coordinate ranks disagree; supply a justified noise model')
        if exact_rank(np.column_stack((m,y)))!=structural_rank:
            raise ValueError('Inconsistent exact finite-coordinate observation equations')
        null = vh[rank:].T
    else:
        rank, null = 0, np.eye(n)
    basis,indices=row_basis(m)
    center_exact=row_lift(basis,[F(float(y[i])) for i in indices],n)
    norm2_exact=dot(center_exact,center_exact)
    if norm2_exact > 1:
        raise ValueError('Observation lies outside unit ball')
    squared_radius=1-norm2_exact
    radius=math.sqrt(float(squared_radius))
    if squared_radius and radius==0:
        raise ArithmeticError('Nonzero fibre radius is below float64 range')
    center=np.asarray([float(x) for x in center_exact])
    v_exact=[F(float(x)) for x in v]
    projected=exact_projection(basis,v_exact)
    magnitude,axis=scaled_direction(projected)
    p=np.asarray([float(x) for x in projected])
    displacement=radius*axis if axis is not None else np.zeros(n)
    lo, hi = center-displacement, center+displacement
    midpoint=float(F(float(offset))+dot(v_exact,center_exact))
    half=radius*magnitude
    lower,upper=midpoint-half,midpoint+half
    if not all(math.isfinite(x) for x in (lower,upper,half,upper-lower)) or (squared_radius and magnitude and (half==0 or lower==upper)):
        raise ArithmeticError('Nonzero target interval cannot be resolved at this float64 scale/offset')
    return dict(lower=lower, upper=upper,
                width=upper-lower, lower_witness=lo.tolist(), upper_witness=hi.tolist(),
                center=center.tolist(), radius=radius, rank=rank, null_projector=(null@null.T).tolist(),
                projected_target=p.tolist(), next_axis=None if axis is None else axis.tolist(),
                tolerance=tolerance, rank_policy='exact finite-coordinate rank checked against SVD; reject disagreement',
                feasibility=dict(center_exact=[str(x) for x in center_exact],projected_target_exact=[str(x) for x in projected],center_norm_squared_exact=str(norm2_exact),squared_radius_exact=str(squared_radius),policy='exact rational minimum-norm check; no tolerance enlargement'),
                result_kind='formal_under_premises', arithmetic='float64 evaluation of analytic formula')


def rank_ball_axes(matrix, readout, target, candidates):
    """Worst residual target width over all outcomes of each extra exact scalar readout.

    The maximum occurs at the centered outcome. Cost is an explicit abstract unit.
    No same-particle, disturbance-free quantum measurement is implied.
    """
    before = ball_fibre(matrix, readout, target)
    p, rho = np.asarray(before['projected_target']), before['radius']
    original=np.asarray(matrix,dtype=float)
    original=np.empty((0,len(p))) if original.size==0 else original
    records = []
    for c in candidates:
        axis = np.asarray(c['axis'], dtype=float)
        cost = float(c['cost'])
        if axis.shape != p.shape or not np.all(np.isfinite(axis)) or not np.any(axis) or not math.isfinite(cost) or cost <= 0:
            raise ValueError('Finite nonzero accessible axis and positive cost required')
        supplied_axis=axis.copy()
        # Structural rank belongs to the supplied coordinates, before normalization.
        augmented=np.vstack((original,axis))
        structural_rank=exact_rank(augmented)
        scaled=axis/float(np.max(np.abs(axis)))
        axis=scaled/math.hypot(*scaled)
        if structural_rank==before['rank']:
            worst=before['width']
        else:
            singular=np.linalg.svd(np.vstack((original,axis)),compute_uv=False)
            numerical_rank=int(np.sum(singular>1e-10*max(1.0,float(singular[0]))))
            if numerical_rank!=structural_rank:
                raise ValueError('Ill-conditioned candidate readout: exact information cannot be resolved numerically')
            basis,_=row_basis(augmented)
            residual=exact_projection(basis,[F(float(x)) for x in target])
            magnitude,_=scaled_direction(residual)
            worst=2*rho*magnitude
            if not math.isfinite(worst) or (rho and magnitude and worst==0):
                raise ArithmeticError('Residual width is outside float64 range')
        records.append(dict(id=c['id'], axis=axis.tolist(), supplied_axis=supplied_axis.tolist(),cost=cost, worst_width=worst,
                            guaranteed_reduction=max(0.0, before['width']-worst),
                            reduction_per_cost=max(0.0, before['width']-worst)/cost))
    return sorted(records, key=lambda r: (-r['reduction_per_cost'], r['id']))


def resource_fibre(q):
    """Synthetic fixed-volume stocks: T=G+2O in [.2,1] mM, N in [0,.08] mM.

    Exact q=G/T is a stipulated readout. T>0 makes the change of variables valid.
    B=G/2+N+.06 mM is a 20-minute necessary budget ceiling with regeneration .003 mM/min.
    It is not a promised amount of detoxification or a viability probability.
    """
    q = F(q)
    if not 0 <= q <= 1:
        raise ValueError('q must be in [0,1]')
    return Polytope([(F(1,5), F(1)), (0, F(2,25))]), (q/2, F(1)), F(3,50)


def resource_measurements():
    return [dict(id='absolute_total_pool', row=(1,0), edges=[F(1,5)+F(i,10) for i in range(9)], cost=F(1), unit='mM'),
            dict(id='nadph_pool', row=(0,1), edges=[F(i,100) for i in range(9)], cost=F(1), unit='mM')]


def rank_bins(poly, target, offset, candidates):
    before = poly.bounds(target, offset)
    records = []
    for c in candidates:
        edges = [F(x) for x in c['edges']]
        projection = poly.bounds(c['row'])
        if len(edges)<2 or any(x>=y for x,y in zip(edges,edges[1:])) or edges[0]>projection['lower'] or edges[-1]<projection['upper']:
            raise ValueError('Bins must cover the entire continuous projection in increasing order')
        cost = F(c['cost'])
        if cost <= 0:
            raise ValueError('Cost must be positive')
        outcomes=[]
        for i,(lo,hi) in enumerate(zip(edges,edges[1:])):
            child = poly.intersect(c['row'],lo,hi)
            if child.vertices():
                outcomes.append(dict(bin=i, lo=lo, hi=hi, **child.bounds(target,offset)))
        worst = max(o['width'] for o in outcomes)
        records.append(dict(id=c['id'], cost=cost, unit=c['unit'], worst_width=worst,
                            guaranteed_reduction=before['width']-worst,
                            reduction_per_cost=(before['width']-worst)/cost, outcomes=outcomes))
    return sorted(records,key=lambda r:(-r['reduction_per_cost'], r['id']))
