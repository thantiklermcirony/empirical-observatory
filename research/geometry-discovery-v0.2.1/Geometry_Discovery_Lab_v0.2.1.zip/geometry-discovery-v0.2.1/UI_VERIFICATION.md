# Explorer checks

The standalone explorer was served locally and inspected through the Codex browser on 12 September 2026. This was a manual functional and visual check, not an automated cross-browser certification.

- The initial quantum view showed yield interval [.25,.75] and width .5 for z=0 with the y-directed synthetic target.
- Selecting the hidden target readout reduced the width to zero and changed the next question to noise/preparation validation or a different target. The now-redundant target-readout button became disabled.
- At q=.75 the resource view selected total-pool measurement. Bin 5 gave a compatible ceiling interval [.285,.4025] mM and width .1175 mM.
- Removing common fixed-volume/complete-accounting admission changed the physical GPx conclusion to unresolved while retaining the geometric display.
- Programme connection selection updated the map, preserved structure, requirements, unresolved transfer and artifact link. The temporal/quantum supply connection was checked explicitly.
- The campaign view displayed the recorded counts and baseline comparisons, five countermodels and case-linked next questions. A subsequent data update groups the 68 case-specific proposals into five measurement families; it does not change the plotted geometry or comparisons.
- Screenshots of the resource and campaign views showed readable axes and controls with no overlapping content at the tested desktop viewport. Responsive CSS is included; a separate mobile/browser matrix was not tested. The download button is implemented but a downloaded file was not independently inspected in this check.

The explorer uses the frozen campaign data and a small analytic browser implementation for its controls. Python is the authoritative reproducible computation. There is no external API call, patient feed or automatic experimental execution.
