# Project: Geometry Discovery Lab

**The endgame is an Observatory that can turn a gap in understanding into the next experiment needed to close it.** The mathematical branch should supply the tools for doing that across the programme: a precise obstruction, compatible alternatives, a discriminating operation, and a record of what changed when new evidence arrived.

The atlas established which claims survive their assumptions. This upgrade gives the branch a productive next role: generate questions and counterexamples from that structure. It is a versioned research system that can improve its models and experiment proposals through evidence. It is not a claim that an assistant has acquired a private consciousness or rewritten its underlying model.

## Grow from the structure already present

An observation divides a state space into sets of states it cannot distinguish. A requested outcome varies across each such set. That variation gives an explicit limit on what can be inferred, and its extremal states give the strongest disagreement compatible with what was observed. A new observation cuts the set further. A physical intervention can move it, change its shape or invalidate the old observation. A coordinate change merely relabels it when everything is transported consistently.

That is a useful shared language for Bloch preparations, resource pools, hidden recovery modes, action sufficiency and state closure. Their geometry and physics remain distinct. The prime-sieve work needs discrete predicates and exact arithmetic, rather than being forced into a ball or a convex resource set.

## The first working release

Version 0.2 implements six proof statements, exact rational resource polytopes, affine ball fibres, worst-case one-measurement design, five countermodels, two existing-contract packages and a standalone interactive explorer. It produces:

- 60 synthetic quantum-effect geometries, with extremal compatible preparations and ranked accessible axes.
- 8 resource geometries and 128 continuously bounded assay-bin regions.
- 512 simulated readouts from 256 stipulated preparations, all enclosed by the continuous bounds.
- 68 case-specific follow-up proposals in five measurement-question families, ranked within their own units and declared candidate menus. Parameter variants do not count as independent discoveries.
- 10 programme connections, distinguishing implemented geometry from proposed or unsupported transfers.
- 28 scientific tests, including 2,000 random ball-fibre enclosure probes, 101 rational resource oracles and missing-premise contrasts.

The output is intentionally useful beyond a larger catalogue. For equal assay costs, the preferred next resource measurement switches at q=.2. For exact quantum ensemble readouts, the hidden target direction supplies a scalar measurement that resolves this target while other state uncertainty can remain. These are actionable mathematical designs, subject to physical measurement access and calibration.

## The epic project after this foundation

| Stage | Deliverable | Completion criterion | Principal owner |
|---|---|---|---|
| 1. Geometry adapter | Consume actual reviewed domain outputs instead of authored example targets; accept explicit feasible sets, readouts, target and instrument menus through the existing inquiry contract. | Biology and quantum each reproduce one result from the other branch's emitted package without manually rebuilding the mathematics. | Mathematics with domain leads and integration |
| 2. Counterexample workshop | Search for the smallest witness against closure, transport, commutation or an asserted resource ceiling. Retain failed searches without calling them proofs. | Every promoted structural claim has an independently checked proof or bounded certificate; every rejected claim has a reproducible witness and exact premises. | Mathematics |
| 3. Experiment composer | Plan finite sequences of observations and interventions under cost, time, depletion and disturbance. | Beat or tie the best fixed policy and exact small-instance optimum on held-out synthetic tasks; report losses and domain failures. | Mathematics supplies geometry; domain leads own likelihood and dynamics |
| 4. Real evidence loop | Ingest named, calibrated experiments with preparation identity, units, uncertainty and complete outcome accounting. | A preregistered held-out intervention distinguishes two previously compatible mechanisms; receipt and calibration are independently reviewed. | Domain scientists and integration |
| 5. Programme-wide inquiry routing | Ask which branch's measurement most changes a specified cross-branch decision; generate a minimal shared experiment with all interface obligations visible. | At least one cross-branch prediction survives a withheld observation and outperforms each disconnected model under the same declared loss and budget. | All branches, coordinated centrally |

These are acceptance gates, not promised discoveries or a claim that future work is running unattended. The first release is complete locally; later stages need their scientific inputs and ownership.

## Where to aim for the moon

The ultimate branch should act as a compiler from scientific uncertainty to a reproducible investigation. Given “these observations fit both mechanisms; what can separate them before our resource or time budget runs out?”, it should return the compatible state families, a proof of the remaining ambiguity, a feasible experimental design, the cost of learning, the outcome that would falsify each mechanism and the next question for every possible result.

The most valuable eventual output may be a small experiment that several branches independently need. For example, a matched preparation and calibrated absolute stock assay could settle a biological reserve ambiguity, make a quantum-product coupling interpretable and determine whether an action threshold can be reached before a deadline. That is a proposed programme experiment, not an inferred real-organ effect.

The anatomy interface should expose that inquiry in context: selecting a structure opens the actual signal provenance, compatible states, unresolved transfers and next measurement. Geometry must not turn a named organ into fictitious data.

## What the branch learns between releases

The durable learning unit is a versioned record: question, model and observation hashes, premises, prediction interval, experiment or counterexample, independent review, and the consequent revision. `results/questions.json` is the initial generated queue. `results/countermodels.json` stores reusable failure cases. `BRANCH_CONNECTIONS.json` records proposed transfers and their obligations. These are local research records, not hidden model memory.

On each future cycle: prioritize a question that changes a decision; seek a witness before adding complexity; run a discriminating comparison against the strongest available baseline; preserve unsuccessful or contradictory outcomes; and promote only what the new evidence supports. A failed model should create a sharper question, not quietly disappear from the record.

Measure growth through reduced target ambiguity, stronger validated bounds, distinct mechanisms separated, useful out-of-family counterexamples, cost-normalized information from actual instruments, and independently reproduced transfers. Raw record counts are campaign size, not scientific progress. Repeated samples from an unchanged model are not additional empirical evidence.

## Boundaries that preserve usefulness

This release leaves the earlier atlas's classification obligations and initial-dip interval unresolved. It adds no universal physical law, cell-fate calibration or prime theorem. Ball arithmetic is floating-point evaluation of an analytic proof; polytope arithmetic is exact rational enumeration. Noise models, physical instruments and biological kinetics remain domain-owned. The central engine retains trusted admission, source freshness and parent/result binding. The new lab is a local release; the previously published atlas remains unchanged on GitHub.
