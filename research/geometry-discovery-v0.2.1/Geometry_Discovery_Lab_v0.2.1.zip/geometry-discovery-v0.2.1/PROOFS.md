# The geometry of the next question

These are human-readable mathematical proofs with executable instance checks. This release has no proof-assistant kernel and no claim of new priority for standard convex geometry.

## GDL-01: ambiguity is target-dependent

Let K be a nonempty compact set of admissible states, h the observation map, and F={x in K:h(x)=y} a nonempty compact observation fibre. Let f be a continuous scalar target in declared units. Define L=min_F f, U=max_F f and W=U-L. Any deterministic estimate based only on y must use the same number e for every x in F. The triangle inequality gives U-L <= |U-e|+|e-L|, so its worst absolute error is at least W/2. The midpoint (L+U)/2 attains W/2. Extremal states are therefore an explicit indistinguishability witness, not merely a large error bar.

This is worst-case absolute error over a stipulated feasible set. It is neither a confidence interval nor a statistical lower bound under a prior. An empty fibre signals inconsistent observations/model premises; it must not return zero uncertainty. An unbounded target requires a separate treatment.

## GDL-02: refinement and coordinate transport

If a further observation restricts F to a nonempty F', then min_F f <= min_F' f <= max_F' f <= max_F f. Thus W(F')<=W(F). A changed physical state or invalidated observation is not set refinement.

For a bijection psi:K->K', transport both h and f: h'=h o psi^-1 and f'=f o psi^-1. The two fibres have exactly the same target image, hence the same L,U,W. No Euclidean metric needs to survive. Scaling a coordinate by 10 changes raw distances by 10 unless its metric is also transported. A many-to-one map preserves a target only if that target is constant on every collapsed fibre. This is the precise bridge to observer/action sufficiency; a change of chart alone creates no additional observations.

## GDL-03: affine targets on an observed ball

Let F={r in R^n:||r||<=1, Mr=y} and f(r)=a+v^T r. Let r0 be the minimum-norm solution of Mr=y. Existence of F requires consistent equations and ||r0||<=1. The general solution is r=r0+z with z in ker M; r0 is perpendicular to ker M. Thus ||z||<=rho=sqrt(1-||r0||^2). Let p=P_ker(M)v. Then f(r)=a+v^T r0+p^T z. Cauchy–Schwarz yields:

    L = a+v^T r0-rho||p||
    U = a+v^T r0+rho||p||
    W = 2rho||p||.

If p!=0, the two extrema r0 +/- rho p/||p|| attain the bounds. If p=0 or rho=0 the target is already constant. At y=0 this reduces to the quantum branch's proposed formula 2||P v||. The reference z=.8, a=.5, v=(0,.25,.1) yields r±=(0,±.6,.8), L=.43,U=.73,W=.30.

For a qubit this geometry additionally requires the Bloch-ball model and an affine effect. An arbitrary fitted response need not be affine or physically admissible. The campaign's effects have eigenvalues .5 +/- sqrt(.25^2+.1^2), within [0,1]; they are synthetic effects, not fitted reaction mechanisms.

## GDL-04: the best next scalar observation

If p!=0, an exact scalar readout along p/||p|| makes f known on the fibre. It can leave many other target directions unknown. It is optimal for this target among unconstrained exact scalar readouts because no width is negative. Physical access, noise, cost, exchangeable preparations and measurement backaction are additional obligations.

For an allowed axis m, let u=P_ker(M)m. If u=0 it adds no information. Otherwise the component of p still hidden after the new measurement is p'=p-u(p^T u)/||u||^2. The new fibre radius is at most rho, with equality at the centered outcome m^T r0. Therefore the worst target width over all feasible new outcomes is exactly 2rho||p'||. The implemented ranking maximizes (W-W_worst)/cost over the declared finite axis menu. This is a one-step design criterion; it does not claim globally optimal sequential policies.

If instead the centered readout along p/||p|| is known only within ±epsilon, its target width is 2||p|| min(rho,epsilon). For a noncentered interval, intersect that interval with [-rho,rho] first. Repeated noisy trials do not justify shrinking epsilon without a valid error model. Near-dependent numerical observation rows must not be treated as infinitely precise experimental information. The implementation computes the exact rank of the supplied binary float coordinates and rejects disagreement with the SVD rank, including for candidate readouts. It also rejects exact augmented-system inconsistency. It does not silently replace a nearly dependent row with a redundant one.

## GDL-05: exact bounds over continuous resource possibilities

A nonempty bounded polyhedron attains a linear objective at a vertex. At each vertex the active constraint normals span the ambient space: otherwise a nonzero direction orthogonal to all active normals permits both small positive and negative displacements, contradicting extremality. Enumerating all full-rank active sets and retaining feasible solutions therefore finds every vertex, including when opposite inequalities encode affine equalities. `geometry.py` solves these systems with rational arithmetic and begins with an explicit finite box. It supports dimensions 1–4; enumeration is intentionally limited and can be expensive.

In the biological geometry fixture, T=G+2O in [.2,1] mM, N in [0,.08] mM, q=G/T in [0,1] is exact, and the necessary 20-minute resource ceiling is B=qT/2+N+.06 mM. This presumes fixed common volume, complete stoichiometric accounting, nonnegative remaining reserve, no additional glutathione source and regeneration <=.003 mM/min. Thus:

    L = .1q+.06; U=.5q+.14; W=.4q+.08.

The extrema vary initial stocks compatible with the readout. L is the lowest possible *ceiling*, not a guaranteed lower bound on actual detoxification. Actual integrated GPx extent is only bounded above by the applicable B.

An absolute-total assay with bins .1 mM wide has worst remaining width .05q+.08 mM. A NADPH assay with bins .01 mM wide has worst remaining width .4q+.01 mM. With equal costs the first wins exactly when q>.2; the second wins when q<.2, and they tie at .2. Their closed bins cover the entire continuous projection. Shared boundary points are conservatively present in adjacent fibres; the synthetic quantizer assigns them by a declared floor rule, with the final endpoint in the last bin. This does not assume the sampled states exhaust the biology.

## GDL-06: invariants and order are different questions

For A(x)=2x and B(x)=x+1, A(B(x))=2x+2 whereas B(A(x))=2x+1. Both are projective maps preserving the cross-ratio of any four distinct points in their domains. Thus a preserved geometric invariant does not imply operations commute. In a biological sequence an observed order effect may reflect kinetics, depletion or selection; the calculation alone does not identify which.

## Source relation

Affine sets, balls, polytopes and convex optimization are standard; see Boyd, Vandenberghe and Nobel's [author-hosted lecture slides](https://web.stanford.edu/~boyd/cvxbook/bv_cvxslides.pdf), slides 2.2, 2.7 and the surrounding convex-set chapter. Those pages were accessible on 12 September 2026. The full book download timed out in this session. The arguments above are supplied directly rather than presented as quotations or externally machine-checked theorems. Our contribution here is an executable, premise-scoped workflow and branch-specific designs, not a claim to have invented support functions or optimal experimental design. Statistical comparison of experiments and quantum instruments need their own additional theory; no Blackwell theorem is asserted for these set-valued fixtures.
